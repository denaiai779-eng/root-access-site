# Root Access — Brand Guide

> The visual and verbal identity for Root Access Learning OS. Every deliverable — content, code, UI, marketing — follows this guide.

---

## Brand Identity

**Root Access Learning OS** is a homeschool curriculum with a terminal/hacker aesthetic. The brand says: *"Learning is powerful. You have root access to your child's education."*

The vibe: playful-nerdy, not intimidating-technical. The content is warm and human. The packaging is hacker-cool.

### Positioning
- **Market**: De-colonized, culturally inclusive homeschool curriculum
- **Audience**: Parents who want structured, scripted lessons with diverse perspectives
- **Differentiators**: Fully scripted dialogue, de-colonized social studies, Singapore Math, terminal aesthetic, Bug Report assessment system
- **Not**: Christian curriculum. Not "Columbus discovered America." Not generic. Not ugly.

---

## Visual System

### Colors

| Token | Hex | Usage |
|-------|-----|-------|
| **Terminal Black** | `#0D0D0D` | Primary background |
| **Deep Navy** | `#1A1A2E` | Secondary background, card surfaces |
| **Root Green** | `#00FF88` | Primary accent, highlights, CTAs, success states |
| **White** | `#FFFFFF` | Primary text on dark backgrounds |
| **Light Gray** | `#B0B0B0` | Secondary text, metadata, captions |
| **Error Red** | `#FF4444` | Error states, critical warnings |
| **Warning Amber** | `#FFAA00` | Warnings, attention needed |

**Rules:**
- Root Green is NEVER body text (fails contrast on dark backgrounds at small sizes)
- Root Green is for: highlights, borders, accents, headings, interactive elements
- Dark backgrounds for screens, light backgrounds for print
- Print mode: black on white, Root Green accents only (save ink)

### Typography

| Font | Use | Fallback |
|------|-----|----------|
| **Fira Code** | Headings, UI labels, code | `monospace` |
| **IBM Plex Mono** | Body text, lesson content | `monospace` |
| **Patrick Hand** | Student work areas, handwriting | `cursive` |

**Rules:**
- Load all fonts locally (no CDN dependency)
- Minimum body: 16px screen, 12pt print
- Line height: 1.6 body, 1.3 headings
- Never mix fonts within a text block

### Visual Elements
- Terminal cursor (`▊`) as brand mark
- `>` prompt symbol for parent dialogue
- Monospace code-block styling for problem sets
- Cards: 1px Root Green border on Deep Navy background
- No clip art. No cartoons. No stock photos.
- Illustrations: line-art, single color (Root Green or White on dark)

---

## Voice & Tone

### Parent-Facing (lessons, guides)
- Warm and direct. Talk to parents like intelligent adults.
- Confident but not arrogant. "Here's what to say" not "You probably don't know this."
- Practical. Every sentence earns its space.
- Honest. "This topic is hard for most kids. Here's why."
- Second person: "You'll introduce fractions by..."

### Student-Facing (Go-Bag, worksheets)
- Encouraging but not patronizing. "Try this" not "You can do it, champ!"
- Clear and simple. Short sentences. Active voice.
- Curious. "What happens when..." not "The answer is..."
- Second person: "Solve the problem" not "The student will solve..."

### Marketing / External
- Bold and concise. Short declarative sentences.
- Technical metaphors used sparingly. Don't force "debug" into every sentence.
- No edu-speak. Never say "learner outcomes" or "pedagogical framework" externally.

---

## Naming Conventions

### Branded Terms (Always Capitalized)
- **Root Access** — the product
- **Go-Bag** — the student workbook
- **Bug Report** — the error classification system
- **Error 404** — no understanding
- **Error 500** — bad logic
- **Syntax Error** — mechanical mistakes
- **Root Green** — the accent color

### File Naming
- Lowercase with hyphens: `week-01`, `parent-prep.md`
- No spaces in file names
- Week numbers zero-padded: `week-01` through `week-36`

### Code Naming
- Python: `snake_case` functions, `PascalCase` classes
- JavaScript: `camelCase` functions, `PascalCase` components
- CSS: `kebab-case` classes
- Env vars: `SCREAMING_SNAKE_CASE`
