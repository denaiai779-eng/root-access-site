# Week 01 — Homework

*All homework is designed to reinforce what was learned in class — never to introduce new concepts. If your student is struggling with an assignment, that's a signal to revisit the topic during the next lesson, not to push through at home. Homework should take roughly 30 minutes per night (15 min math + 15 min reading/writing). The weekend project is flexible — 30 minutes total, done whenever it fits your family's schedule.*

---

## Wednesday Homework

### Math Practice (15 min)

**Directions**: Complete these four problems in your math notebook. Show your thinking — don't just write the answer. If you get stuck, you can use your place value chart or base-ten blocks.

**1.** Write 45,672 in expanded form.

**2.** What is the value of the 8 in 83,041?

**3.** Write "twelve thousand, five hundred nine" in standard form.

**4.** Compare these two numbers using >, <, or =. Then write one sentence explaining how you decided.

&nbsp;&nbsp;&nbsp;&nbsp;34,891 &nbsp;&nbsp;&#9675;&nbsp;&nbsp; 34,981

---

### Reading/Writing (15 min)

**Journal Prompt**: *Write about a time you had a LOT of energy. What were you doing? How did your body feel? Where were you? What happened with all that energy?*

Write at least 5 sentences. Try to help the reader FEEL what it was like — use details. (This connects to what you're learning about energy in science this week. Scientists study energy too, just a different kind.)

---

## Thursday Homework

### Math Practice (15 min)

**Directions**: Complete these four problems in your math notebook. You may draw a place value chart to help — that's not cheating, it's a tool.

**1.** Draw a place value chart and place the number 7,203 in it. Label each column (thousands, hundreds, tens, ones).

| Ten-Thousands | Thousands | Hundreds | Tens | Ones |
|:---:|:---:|:---:|:---:|:---:|
| &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; | &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; |

**2.** Write this number in standard form:

&nbsp;&nbsp;&nbsp;&nbsp;50,000 + 3,000 + 400 + 60 + 8 = ______________

**3.** Order these three numbers from least to greatest. Write one sentence explaining your reasoning.

&nbsp;&nbsp;&nbsp;&nbsp;12,045&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;12,405&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;12,054

**4.** What number is 1,000 more than 6,892? What number is 1,000 less than 6,892?

---

### Reading/Writing (15 min)

**Writing Prompt**: *Write 3-5 sentences about what you learned about Michigan's geography today. You must include at least 2 specific facts — for example, the name of a Great Lake, a type of landform found in Michigan, or a connection to the Indigenous peoples who have lived on this land.*

This is informative writing — you're teaching your reader something. Pretend you're explaining Michigan's geography to someone who has never been here. What would they need to know?

---

## Friday Homework

### Weekend Project: Michigan Postcard (30 min total, flexible)

**The Assignment**: Create a postcard FROM Michigan to someone you care about — a grandparent, a cousin, a friend who lives in another state, a pen pal, anyone.

**Front of the postcard** (the picture side):
- Draw, paint, or color a picture of a real Michigan landmark or landscape. Ideas: Sleeping Bear Dunes, Mackinac Bridge, Tahquamenon Falls, the Upper Peninsula shoreline, a Great Lakes lighthouse, Pictured Rocks, the Detroit skyline. Pick something real.
- It doesn't have to be perfect — it has to show something specific about Michigan.

**Back of the postcard** (the message side):
- Write a message (at least 5 sentences) to the person you're sending it to. In your message, describe what makes Michigan's geography unique. Your message must include:
  - At least **2 geographic features** of Michigan (Great Lakes, peninsulas, dunes, rivers, forests, etc.)
  - At least **1 Indigenous place name** and what it means. Here are some to choose from:

| Place Name | Origin | Meaning |
|-----------|--------|---------|
| Michigan | Ojibwe: *mishigami* | "great water" or "large lake" |
| Kalamazoo | Potawatomi: *ki-ka-ma-sung* | "boiling water" or "the mirage of a reflecting river" |
| Mackinac | Ojibwe: *mishimikinaak* | "Great Turtle" (the island was thought to resemble a turtle) |
| Saginaw | Ojibwe: *sak-e-nang* | "land of the Sauk people" |
| Washtenaw | Ojibwe: *wash-ten-ong* | "on the river" or "far away" |
| Muskegon | Ottawa: *masquigon* | "marshy river" or "swamp" |

**Format**: Use a piece of cardstock, thick paper, or cardboard cut to roughly 4" x 6" (the size of a real postcard). If you want, you can actually mail it.

---

## Answer Keys

### Wednesday Math

**1.** 45,672 in expanded form:

&nbsp;&nbsp;&nbsp;&nbsp;**40,000 + 5,000 + 600 + 70 + 2**

Each digit is multiplied by its place value: 4 ten-thousands (40,000) + 5 thousands (5,000) + 6 hundreds (600) + 7 tens (70) + 2 ones (2).

**2.** The value of the 8 in 83,041:

&nbsp;&nbsp;&nbsp;&nbsp;**80,000**

The 8 is in the ten-thousands place. Its value is 8 x 10,000 = 80,000. (Common error: student says "8" or "8,000." If they say "8," remind them of the difference between a digit and its value. If they say "8,000," have them count the places from the right — ones, tens, hundreds, thousands, ten-thousands.)

**3.** "Twelve thousand, five hundred nine" in standard form:

&nbsp;&nbsp;&nbsp;&nbsp;**12,509**

Note the 0 in the tens place — there are no tens in this number. "Five hundred nine" means 500 + 9, not 500 + 90. (Common error: student writes 12,590. Remind them: "five hundred nine" has no tens — just five hundreds and nine ones.)

**4.** 34,891 &nbsp;&nbsp;**<**&nbsp;&nbsp; 34,981

Explanation: Both numbers have the same digits in the ten-thousands place (3) and thousands place (4). In the hundreds place, 34,891 has an 8 and 34,981 has a 9. Since 8 < 9, the number 34,891 is less than 34,981.

(Common error: student looks at the entire number and guesses, or compares from right to left instead of left to right. Reinforce: always start comparing from the leftmost digit and move right.)

---

### Thursday Math

**1.** Place value chart for 7,203:

| Ten-Thousands | Thousands | Hundreds | Tens | Ones |
|:---:|:---:|:---:|:---:|:---:|
| 0 | 7 | 2 | 0 | 3 |

Note: The ten-thousands column is 0 (or left blank) because 7,203 is a 4-digit number. The tens column is 0 — there are zero tens in this number. Make sure the student doesn't skip the zero columns.

**2.** 50,000 + 3,000 + 400 + 60 + 8 in standard form:

&nbsp;&nbsp;&nbsp;&nbsp;**53,468**

(Common error: student writes 5,346,8 or forgets proper comma placement. Remind them: commas go every three digits from the right.)

**3.** Least to greatest:

&nbsp;&nbsp;&nbsp;&nbsp;**12,045 &nbsp;&nbsp;&lt;&nbsp;&nbsp; 12,054 &nbsp;&nbsp;&lt;&nbsp;&nbsp; 12,405**

Reasoning: All three numbers have the same ten-thousands digit (1) and thousands digit (2). In the hundreds place: 12,045 has 0, 12,054 has 0, and 12,405 has 4. So 12,405 is the greatest. Between 12,045 and 12,054: both have 0 in the hundreds place, so check tens: 4 vs. 5. Since 4 < 5, 12,045 < 12,054.

(Common error: student puts 12,054 before 12,045 because "54 is bigger than 45." This means they're reading the last two digits as a two-digit number instead of comparing place by place. Walk through the left-to-right strategy.)

**4.**
- 1,000 more than 6,892: **7,892**
- 1,000 less than 6,892: **5,892**

Only the thousands digit changes. Everything else stays the same. (Common error: student changes the wrong digit, or gets confused about "less than." If they struggle, use a place value chart: point to the thousands digit and ask "what's one more? one less?")

---

### Friday Weekend Project — Success Criteria

There's no single right answer for the Michigan Postcard Project. Instead, use these criteria to evaluate the finished product:

- [ ] **Visual**: The front of the postcard shows a recognizable Michigan feature — a real place, landmark, or landscape (not a generic drawing)
- [ ] **Geographic features**: The written message mentions at least 2 specific geographic features of Michigan (e.g., Great Lakes, Upper and Lower Peninsulas, sand dunes, rivers, forests, Straits of Mackinac)
- [ ] **Indigenous place name**: The message includes at least 1 Indigenous place name with its meaning (from the provided table or their own research)
- [ ] **Writing quality**: The message is at least 5 sentences, uses complete sentences, and is clear enough for the reader to learn something about Michigan
- [ ] **Overall effort**: The postcard shows care and thought — it doesn't have to be artistic, but it should show the student engaged with the assignment

**If the student goes above and beyond**: They research an additional Indigenous place name not on the provided list, include more than 2 geographic features, or actually mail the postcard to someone. Celebrate that.

**If the student struggles**: The most common sticking point is the Indigenous place name. Point them to the table in the assignment. Let them pick the one they think is most interesting and help them weave it into their message naturally — for example: "The name Michigan actually comes from the Ojibwe word *mishigami*, which means 'great water.' That makes sense because Michigan is surrounded by four of the five Great Lakes."

---

*Root Access Learning OS — Week 01 of 36*

© 2026 Root Access Learning OS. All rights reserved.
