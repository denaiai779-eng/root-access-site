# Week 01 — Parent Prep

Read this before Wednesday. It covers everything you need to know to teach this week confidently. Budget about 20 minutes to read through it and gather materials.

---

## Math Focus: Place Value (4.NBT.1, 4.NBT.2)

### What You're Teaching

Your student needs to understand that our number system is built on powers of ten. A digit's *position* determines its value — the 3 in 300 isn't "three," it's "three hundred." This week, you'll start with concrete manipulation (base-ten blocks), move to drawing and charting (pictorial), and begin connecting to standard and expanded form (abstract). You won't finish all of that this week — you'll get through concrete and start pictorial.

### The Progression Across Three Days

- **Wednesday**: Introduce place value using base-ten blocks. Build numbers physically. "Show me 2,347 with the blocks." Your student should be able to tell you the value of each digit by pointing to the blocks that represent it.
- **Thursday**: Move from building numbers to reading and writing them. Connect the blocks to written form: standard form (2,347), word form (two thousand three hundred forty-seven), and expanded form (2,000 + 300 + 40 + 7). Have your student practice going back and forth between forms.
- **Friday**: Compare multi-digit numbers using >, =, and <. Use the blocks first — build two numbers side by side and determine which is greater by comparing place values left to right. Then move to written comparisons.

### The Misconception You Need to Watch For

The most common place value error: your student looks at 5,482 and tells you the 5 is worth "five." It's not. It's worth five thousand. This sounds obvious to adults, but kids routinely confuse the *digit* with the *value*. When you ask "What is the value of the 4?" and they say "four" instead of "four hundred," stop and go back to the blocks. Have them physically count out what that 4 represents. Don't let them move to written work until they can consistently tell you the *value*, not just the digit.

Another thing to watch: many students can parrot "the 3 is in the hundreds place" without actually understanding that this means 300. Test this by asking them to prove it with blocks.

### If Your Student Is Ahead

If they're breezing through four-digit numbers and can explain place value clearly, extend to millions. Same concept, bigger numbers. Introduce the pattern: ones-tens-hundreds repeats in each period (ones period, thousands period, millions period). Give them a number like 4,215,783 and ask them to read it and explain the value of each digit. You can also introduce comparing numbers with more digits.

### If Your Student Is Behind

Drop back to two-digit numbers with the blocks. Build 34. "How many tens? How many ones? What is the value of the 3?" Then build to three digits. There is no shame in this — a student who truly understands two-digit place value will pick up four-digit place value fast. A student who's been pushed to four digits without understanding will fake it until fractions and decimals expose the gap. Build the foundation right.

---

## Science Focus: Energy and Speed (4-PS3-1)

### What You're Teaching

The core idea is simple: faster-moving objects have more energy. Your student will observe this directly by rolling toy cars down a ramp at different speeds and measuring the effect on a target object. The standard asks them to "use evidence to construct an explanation," so the goal isn't just to see it happen — it's to explain *why* the box moved farther when the car was going faster.

### Background You Need

You don't need a physics degree for this. Here's what you need to know:

- **Energy** is the ability to cause change. A moving object has energy because it can make things happen — push something, break something, change something.
- **Kinetic energy** is the energy an object has because of its motion. A car sitting still has no kinetic energy. A car rolling has some. A car rolling fast has more.
- **Speed** is how fast an object is moving. Higher ramp = more speed at the bottom = more kinetic energy = target moves farther.
- **Force** is a push or pull. When the car hits the box, it exerts a force on it. More energy means more force means more movement of the box.

You don't need to teach the formula for kinetic energy (that's high school physics). Your student just needs to observe, measure, and explain the relationship: faster = more energy = bigger effect.

### The Ramp Experiment

Set up a ramp using a flat board propped on books. Place a lightweight box (empty cereal box) at the bottom as a target. Roll a toy car down the ramp and measure how far the box moves. Then raise the ramp higher and repeat. Then higher again.

Your student should record three things each time:
1. The height of the ramp (number of books, or inches)
2. What they observed (how fast the car seemed to go, what happened to the box)
3. How far the box moved (measure with a ruler)

After all trials, ask: "What pattern do you see? Why do you think the box moved farther when the ramp was higher?" Guide them toward the explanation: higher ramp = faster car = more energy = box moves farther.

**Common issue**: The car veers off or misses the box. That's fine — rerun the trial. Science involves repeated attempts. If the results are inconsistent, that's a conversation too: "Why might we get different results each time?"

### Key Vocabulary

Introduce these terms on Wednesday and use them consistently all week. Don't just define them — use them in conversation so your student hears them in context.

| Term | Student-Friendly Definition |
|------|---------------------------|
| **Energy** | The ability to make something happen or cause a change |
| **Kinetic energy** | The energy something has because it's moving |
| **Speed** | How fast something is moving |
| **Force** | A push or a pull |

---

## Social Studies Focus: Michigan Geography (4-G1.0.1)

### What You're Teaching

Your student lives in Michigan, so this should feel real and relevant. This week, you're covering the physical geography: peninsulas, the Great Lakes, and the major regions and landforms. The goal is for your student to look at a map of Michigan and be able to identify and describe its major physical features with confidence.

### Background You Need

Michigan is made up of two peninsulas:
- **Lower Peninsula**: Shaped like a mitten. This is where most of the population lives. Relatively flat in the south (farming country), with rolling hills and forests in the north.
- **Upper Peninsula (the U.P.)**: Bordered by Lake Superior to the north and Lake Huron/Lake Michigan to the south. More rugged terrain — forests, waterfalls, and the Porcupine Mountains. Connected to the Lower Peninsula by the Mackinac Bridge.

Michigan is bordered by four of the five Great Lakes:
- **Lake Superior** (north of the U.P.) — the largest freshwater lake by surface area in the world
- **Lake Michigan** (west) — the only Great Lake entirely within the United States
- **Lake Huron** (east of the Lower Peninsula, south of the U.P.)
- **Lake Erie** (southeast corner of the Lower Peninsula)

The one Michigan does *not* touch is **Lake Ontario**.

A helpful mnemonic for all five Great Lakes: **HOMES** (Huron, Ontario, Michigan, Erie, Superior).

Michigan has several distinct regions, but for 4th grade, focus on the broad strokes: the flat agricultural south, the forested and hilly north of the Lower Peninsula, and the rugged, mineral-rich Upper Peninsula. If your student wants to go deeper, let them — but make sure they have the big picture first.

### Key Vocabulary

| Term | Student-Friendly Definition |
|------|---------------------------|
| **Peninsula** | A piece of land surrounded by water on three sides |
| **Great Lakes** | The five large freshwater lakes in the upper Midwest (Superior, Michigan, Huron, Erie, Ontario) |
| **Region** | An area that shares common features (like landforms, climate, or resources) |
| **Landform** | A natural feature of the Earth's surface (mountains, hills, plains, valleys) |
| **Upper Peninsula** | The northern part of Michigan, above the Mackinac Bridge |
| **Lower Peninsula** | The southern part of Michigan, shaped like a mitten |

### Map Work

When your student works with the Michigan map on Thursday, have them:
1. Label the Upper and Lower Peninsulas
2. Label all four Great Lakes that border Michigan (and identify which one doesn't)
3. Mark the Mackinac Bridge
4. Identify at least two landform types they see on the map (plains, hills, etc.)

This is hands-on. Let them color-code, draw, annotate. The map they create becomes a reference they'll use in later weeks.

---

## ELA Integration Points

There is no standalone ELA block this week. Instead, reading, writing, vocabulary, and discussion are built into the science and social studies lessons. Here's where the standards show up:

### Reading (4.RI.1, 4.RI.2, 4.RI.4)
- **Thursday, Social Studies**: Your student will read a short informational text about Michigan's geography. They'll identify the main idea, refer to specific details in the text to support their answers, and work with domain-specific vocabulary (peninsula, landform, region). This covers 4.RI.1, 4.RI.2, and 4.RI.4 in a single natural activity.

### Writing (4.W.2, 4.W.4)
- **Wednesday, Science**: After the ramp experiment, your student will write a short paragraph explaining what they observed and why they think it happened. This is informative writing (4.W.2) — they're explaining a concept using evidence from their experiment. Push for clear, organized writing (4.W.4): What did you do? What happened? Why?
- **Thursday, Social Studies**: Your student will write a short description of Michigan's physical features based on their map work and reading. Again, informative writing with domain-specific vocabulary.

### Speaking and Listening (4.SL.1)
- **Every day**: You and your student are having discussions throughout every lesson. That *is* 4.SL.1. Ask open-ended questions. Wait for real answers. Push them to explain their thinking. "Why do you think the car moved the box farther that time?" is more valuable than "Did the box move farther? Yes or no?"

### Language Conventions (4.L.1–3)
- **Every day, in all writing**: When your student writes, hold them to standard grammar, punctuation, capitalization, and spelling. You don't need a separate grammar worksheet — just don't accept sloppy writing. If they write "the car went relly fast and the box moved alot," that's a teaching moment. Fix it together. This is how conventions become habits, not just test answers.

---

## Materials Checklist

Gather everything below before Wednesday morning. Nothing here is exotic — most of it is already in your house.

### Must Have
- [ ] **Base-ten blocks** (ones, tens, hundreds, thousands) — if you don't own a set, order one now or print a paper version. You'll use these for the first 6+ weeks of math. (Available at any teacher supply store, Amazon, or free printable PDFs online.)
- [ ] **Lined notebook or composition book** — this becomes the math journal for the year. Write "Math" on the front.
- [ ] **Second notebook or loose-leaf paper** — for science and social studies writing.
- [ ] **Markers or dry-erase markers** — 4 colors. Used for the place value chart.
- [ ] **Large paper or whiteboard** — for building a place value chart together.
- [ ] **Toy cars** (2–3, similar size) — Hot Wheels, Matchbox, or any small cars that roll well.
- [ ] **Flat board or stiff cardboard** — about 2–3 feet long, for a ramp. A cutting board, a shelf, a piece of foam board — anything flat and rigid.
- [ ] **Books or blocks** — to prop up the ramp at different heights (3–4 thick books work great).
- [ ] **Empty cereal box or small cardboard box** — the target for the ramp experiment.
- [ ] **Ruler or tape measure** — for measuring how far the target moves.
- [ ] **Physical map of Michigan** — printed or on a screen you can reference. Print two copies if possible (one to mark up). Search "Michigan physical features map" for good options.
- [ ] **Colored pencils** — for map labeling and annotation.
- [ ] **Pencils, eraser, sharpener** — at the workspace, ready to go.

### Nice to Have
- [ ] **Folder or binder with dividers** — one section per subject. Set up on Day 1 to build the organizational habit.
- [ ] **Road atlas or wall map** showing the Great Lakes region — gives your student a zoomed-out view of where Michigan sits.
- [ ] **Whiteboard and markers** for quick math practice — faster than paper for rapid repetition.

---

## Finally: Your Mindset This Week

You are not behind. You are not late. You are starting.

Week 1 is supposed to feel like a lot of setup and not enough "real school." That's because setup *is* real school right now. The routines you build this week — where you sit, how you start each day, how you handle frustration, how you transition between subjects — those routines will carry you through the entire year.

If Wednesday takes twice as long as you planned, that's normal. If your student can't sit still for the full math block, shorten it and come back after a break. If the ramp experiment turns into 30 minutes of just rolling cars for fun, that's fine — they're observing physics. Redirect gently.

You have 36 weeks. This is Week 1. Breathe.

---

*Root Access Learning OS — Week 01 of 36*

© 2026 Root Access Learning OS. All rights reserved.
