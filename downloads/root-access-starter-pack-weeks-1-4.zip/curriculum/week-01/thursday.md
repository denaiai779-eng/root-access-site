# Week 1 — Thursday
## Boot Sequence: Day 2

**Date**: Week 1, Day 4 (Thursday)
**Standards**: 4.NBT.1, 4.NBT.2, 4-G1.0.1, 4.RI.1, 4.RI.2, 4.W.2, 4.SL.1
**Theme**: Boot Sequence — powering up core systems
**Math Mode**: Concrete to PICTORIAL transition (Singapore Math)
**Social Studies Frame**: The land and the people who knew it first

---

## Materials Checklist

Gather these before you start. Everything on this list is used today.

- [ ] Math notebook or lined paper
- [ ] Pencil and eraser
- [ ] Colored pencils (at least 5 colors)
- [ ] Place value blocks from Wednesday (keep nearby as backup — you may need them)
- [ ] Blank white paper (2 sheets — one for math charts, one for Michigan map)
- [ ] Printed outline map of Michigan (optional — student can draw freehand)
- [ ] A reference map of Michigan (pull one up on a phone, tablet, or print one)
- [ ] Ruler (for drawing neat place value charts)
- [ ] Student's hand (for the Michigan mitten trick)

---

## Morning Work (15 minutes)

**Start time**: _____ **End time**: _____

Hand your student their notebook and a pencil. Write or read aloud the following three questions and one journal prompt.

> **Say this**: "Before we start today, let's wake up our brains. Do these three quick problems in your notebook — no blocks, just your brain and your pencil. Then answer the journal question underneath."

### Quick Math Review (8 minutes)

Write these on a whiteboard, sheet of paper, or read them aloud:

**1.** What is the value of the 7 in the number 3,725?

**2.** Write this number in standard form: 2,000 + 400 + 60 + 1

**3.** Which is greater: 4,892 or 4,829? Write your answer using > or <.

#### Morning Work Answer Key

| # | Answer | Notes |
|---|--------|-------|
| 1 | 700 (seven hundred) | The 7 is in the hundreds place, so its value is 700, not 7. |
| 2 | 2,461 | Combine all the parts into one number. |
| 3 | 4,892 > 4,829 | The thousands are the same (4). The hundreds are the same (8). The tens are different: 9 tens vs. 2 tens. 9 > 2, so 4,892 is greater. |

### Journal Prompt (7 minutes)

> **Say this**: "Now the journal question. Write at least three sentences."

**Prompt**: *Have you ever visited one of the Great Lakes or seen a really big body of water? What did it look like? What did it sound like? If you haven't been to one, imagine standing at the edge of a lake so big you can't see the other side. What would that feel like?*

There is no wrong answer here. If your student writes three thoughtful sentences, they are done. If they finish fast, ask them: "What would the water smell like? What would the sand feel like under your feet?"

This connects to today's social studies lesson on Michigan geography.

---

## Block 1: Math (60 minutes)

### Place Value Day 2 — From Blocks to Pictures

**Start time**: _____ **End time**: _____

**Big idea**: We can DRAW what the blocks show us. A place value chart is a tool that organizes any number by the value of each digit.

---

### Launch (10 minutes)

> **Say this**: "Yesterday we used place value blocks to build numbers. You held thousands cubes in your hands, you stacked hundreds flats, you lined up tens rods, and you counted ones cubes. You did great work. But here's the thing — you won't always have blocks in your pocket. You might be at a store looking at a price tag. You might be reading about how far away the moon is. You might be figuring out a score in a game. You won't have blocks, but you'll always have a pencil. So today, we're going to learn how to DRAW what the blocks showed us."

Take out a blank sheet of paper and a ruler. Draw this chart while your student watches:

```
┌──────────────┬──────────────┬──────────────┬──────────────┐
│  Thousands   │  Hundreds    │    Tens      │    Ones      │
├──────────────┼──────────────┼──────────────┼──────────────┤
│              │              │              │              │
│              │              │              │              │
│              │              │              │              │
└──────────────┴──────────────┴──────────────┴──────────────┘
```

> **Say this**: "This is a place value chart. Each column is a place — thousands, hundreds, tens, ones. Instead of holding blocks, we write the digit in the right column. Let me show you."

Write the number **1,536** above the chart. Then fill it in together:

| Thousands | Hundreds | Tens | Ones |
|-----------|----------|------|------|
| 1         | 5        | 3    | 6    |

> **Say this**: "See? The 1 goes in the thousands column because it means 1 thousand. The 5 goes in hundreds because it means 5 hundreds. The 3 means 3 tens. The 6 means 6 ones. This chart does the same job as the blocks — it shows us what each digit is WORTH."

> **Ask**: "What was the value of each digit yesterday when we used the blocks? Can you tell me what the 5 is worth in this number?"

**Listen for**: "500" or "five hundred." If the student says "5," redirect:

> **Say this**: "Five is the digit, but what is its VALUE? It's sitting in the hundreds place. So it's worth 5 hundreds — 500."

---

### Guided Practice (20 minutes)

Work these three problems together. You solve them side by side with your student — you on one paper, they on theirs.

#### Problem 1: Represent and Expand

**Context**: The city of Traverse City, Michigan, has a population of about 15,678 people.

> **Say this**: "Traverse City is a real city in the northwest part of Michigan's Lower Peninsula, right near the big sand dunes and Lake Michigan. About 15,678 people live there. Let's put that number on a place value chart."

**Step 1** — Draw a place value chart with FIVE columns (we need ten-thousands now):

| Ten-Thousands | Thousands | Hundreds | Tens | Ones |
|---------------|-----------|----------|------|------|
| 1             | 5         | 6        | 7    | 8    |

> **Say this**: "Look — we needed a new column! When a number has five digits, we need a ten-thousands place. The 1 is in the ten-thousands place, so it's worth 10,000."

**Step 2** — Write it in expanded form together:

> **Say this**: "Expanded form is when we break the number apart to show what each digit is worth. Watch."

**15,678 = 10,000 + 5,000 + 600 + 70 + 8**

> **Ask**: "Can you read that back to me? Ten thousand plus five thousand plus six hundred plus seventy plus eight."

**Step 3** — Have the student read the number aloud: "Fifteen thousand, six hundred seventy-eight."

---

#### Problem 2: Compare Using Place Value Charts

**Context**: Lake Michigan's shoreline along Michigan is about 1,638 miles. Lake Huron's shoreline along Michigan is about 1,014 miles.

> **Say this**: "Michigan touches four of the five Great Lakes. Lake Michigan and Lake Huron both have long shorelines. Let's figure out which shoreline is longer."

Draw two place value charts, one above the other:

**Lake Michigan: 1,638**

| Thousands | Hundreds | Tens | Ones |
|-----------|----------|------|------|
| 1         | 6        | 3    | 8    |

**Lake Huron: 1,014**

| Thousands | Hundreds | Tens | Ones |
|-----------|----------|------|------|
| 1         | 0        | 1    | 4    |

> **Say this**: "Here's how we compare. We start from the LEFT — from the biggest place. That's the thousands. Lake Michigan has 1 thousand. Lake Huron has 1 thousand. They're the same! So we move right to the hundreds. Lake Michigan has 6 hundreds. Lake Huron has 0 hundreds. Stop right there. 6 hundreds is more than 0 hundreds. We don't even need to check the tens or ones."

Write: **1,638 > 1,014**

> **Say this**: "Lake Michigan's shoreline is longer. We write the open end of the symbol toward the bigger number — like a hungry alligator eating the bigger meal."

> **Ask**: "Which shoreline is longer, and how do you know?"

**Listen for**: The student should reference the hundreds place (6 > 0) as the reason.

---

#### Problem 3: Three Ways to Write a Number

**Context**: The Mackinac Bridge, which connects Michigan's two peninsulas, is about 5,280 feet per mile — and the bridge itself is about 26,372 feet long.

> **Say this**: "The Mackinac Bridge is one of the longest suspension bridges in the world. It connects the Upper Peninsula to the Lower Peninsula, right where Lake Michigan and Lake Huron meet. The bridge is 26,372 feet long. Let's write that number three different ways."

**Standard form**: 26,372

**Expanded form**: 20,000 + 6,000 + 300 + 70 + 2

**Word form**: twenty-six thousand, three hundred seventy-two

> **Say this**: "Notice in word form — we don't say 'twenty-six thousand, three hundred and seventy-two.' In math, we skip the word 'and.' The word 'and' is actually saved for decimals, which you'll learn about later. For now, just remember: no 'and.'"

> **Ask**: "Can you write the number 4,509 in all three forms? Try it in your notebook."

**Answer**:
- Standard: 4,509
- Expanded: 4,000 + 500 + 0 + 9 (or 4,000 + 500 + 9 — both are correct)
- Word: four thousand, five hundred nine

If the student writes "four thousand, five hundred and nine," gently correct:

> **Say this**: "Almost! In math, we leave out the word 'and.' Just 'four thousand, five hundred nine.' It feels weird, but that's the convention."

---

### Independent Practice (20 minutes)

> **Say this**: "Your turn. Five problems, on your own. I'm right here if you get stuck, but try each one before you ask for help. Use your place value chart for every single problem — that's your new tool."

Have the student draw a fresh place value chart at the top of their page for reference.

---

**Problem 1** (Easy — Place Value Chart)

Fill in the place value chart for the number **7,482**.

| Thousands | Hundreds | Tens | Ones |
|-----------|----------|------|------|
| ___       | ___      | ___  | ___  |

---

**Problem 2** (Easy — Word Form)

Write the number **3,056** in word form.

---

**Problem 3** (Medium — Compare and Explain)

Kalamazoo, Michigan has a population of about 72,786 people. Ann Arbor has a population of about 123,851 people. Which city has more people? Write your answer using > or < AND explain in one sentence HOW you know.

---

**Problem 4** (Medium — Expanded to Standard and Word)

A number is written in expanded form: **9,000 + 200 + 40 + 5**

Write it in:
- Standard form: ___
- Word form: ___

---

**Problem 5** (Hard — Number Riddle)

I'm a 4-digit number.
- My ones digit is **3**.
- My thousands digit is **twice** my ones digit.
- My hundreds digit is **0**.
- My tens digit is **5 more** than my ones digit.

What number am I? Write me in standard form, expanded form, and word form.

---

### Independent Practice — Complete Answer Key

**Problem 1**

| Thousands | Hundreds | Tens | Ones |
|-----------|----------|------|------|
| 7         | 4        | 8    | 2    |

*Check that each digit is in the correct column. A common error is reversing the order.*

---

**Problem 2**

**three thousand, fifty-six**

*Watch for*: The student may write "three thousand, zero hundred, fifty-six" or "three thousand and fifty-six." Correct both gently.

- "Zero hundred" — we skip any place that has a zero. We don't say it.
- "And" — remember, no "and" in whole number word form.

---

**Problem 3**

**72,786 < 123,851** (Ann Arbor has more people.)

Explanation should include something like: "123,851 is greater because it has 6 digits and 72,786 only has 5 digits" OR "123,851 has a hundred-thousands digit and 72,786 doesn't, so 123,851 is larger."

*Both explanations are valid. The key idea is that the student recognizes either the digit count or the highest place value as the deciding factor.*

---

**Problem 4**

- Standard form: **9,245**
- Word form: **nine thousand, two hundred forty-five**

*Watch for*: "Nine thousand, two hundred and forty-five" (no "and") or "nine thousand, two hundred forty five" (the hyphen between forty-five is correct but not required at this level — accept either).

---

**Problem 5**

Work through the clues:
- Ones digit: **3** (given)
- Thousands digit: twice the ones digit = 2 x 3 = **6**
- Hundreds digit: **0** (given)
- Tens digit: 5 more than the ones digit = 3 + 5 = **8**

The number is: **6,083**

- Standard form: **6,083**
- Expanded form: **6,000 + 0 + 80 + 3** (or **6,000 + 80 + 3** — both accepted)
- Word form: **six thousand, eighty-three**

*This problem requires multi-step reasoning. If the student gets the digits right but assembles them in the wrong order, have them label each digit with its place name first: "thousands = 6, hundreds = 0, tens = 8, ones = 3" and THEN build the number left to right.*

---

### Beast Academy Challenge (10 minutes)

> **Say this**: "Okay, challenge time. This one is meant to make your brain sweat a little. Take your time."

#### The Digit Architect

You have exactly four digit cards: **2, 5, 0, 8**

Each card can only be used ONCE.

**Part A**: Arrange all four digits to make the LARGEST possible 4-digit number.

**Part B**: Arrange all four digits to make the SMALLEST possible 4-digit number. (Be careful — can a number START with 0?)

**Part C**: How much greater is your largest number than your smallest number? (You can use any method to find the difference — counting up, a number line, or subtraction.)

#### Beast Academy Answer Key

**Part A**: **8,520**

*Strategy*: Put the largest digit in the largest place. 8 in thousands, 5 in hundreds, 2 in tens, 0 in ones.

**Part B**: **2,058**

*This is the tricky part.* The student might say 0,258 — but a number cannot start with 0. That would just be 258, a 3-digit number. So the smallest digit that can go in the thousands place is 2. Then put 0 in hundreds, 5 in tens, 8 in ones. Wait — is 2,058 smaller than 2,085? Yes: 2,058 has 5 tens vs 8 tens, and 5 < 8. So 2,058 is correct. Put 0 in hundreds, then the next smallest digit (5) in tens, and 8 in ones.

**Part C**: 8,520 - 2,058 = **6,462**

*This subtraction is hard for 4th grade — it requires regrouping across a zero. If the student struggles, let them count up from 2,058 to 8,520 using a number line or friendly numbers:*
- *2,058 to 3,000 = 942*
- *3,000 to 8,000 = 5,000*
- *8,000 to 8,520 = 520*
- *942 + 5,000 + 520 = 6,462*

*Accept any correct method.*

---

### Bug Check — Math Troubleshooting

Use these if your student hits a wall during independent practice.

#### Error 404: Student Cannot Fill In the Place Value Chart

The connection between blocks and chart is not clicking yet.

**Fix**: Go back to blocks AND chart, side by side. Build the number **2,345** with physical blocks — 2 thousands cubes, 3 hundreds flats, 4 tens rods, 5 ones cubes. Lay them out left to right, biggest to smallest. Then put the place value chart right next to them. Point to the 2 thousands cubes and say:

> **Say this**: "How many thousands cubes do we have? Two. So we write 2 in the thousands column."

Do this for each place. Repeat with 1,207 (which has a zero — important for them to see that zero means "no blocks in that column, but we still write 0").

#### Error 500: Student Fills In Chart But Cannot Compare Numbers

The student understands place value in isolation but freezes when asked to compare.

**Fix**: Teach the "Start from the Left" rule explicitly.

> **Say this**: "When we compare two numbers, we always start from the LEFT side — the biggest place. We look at the digits in the biggest place first. If one is bigger, we're done. If they're the same, we move one place to the right and check again. We keep going until we find a difference."

Practice with these pairs:
- 3,456 vs. 3,489 (same thousands, same hundreds, different tens: 5 < 8)
- 7,123 vs. 698 (7,123 has a thousands digit, 698 doesn't — 7,123 wins immediately)
- 5,555 vs. 5,555 (they're equal!)

#### Syntax Error: Word Form Confusion

The student writes "four thousand three hundred twenty five" as "4000300205" or "4,325" when asked for word form (mixing up forms), or adds "and."

**Fix**: Practice the conventions step by step.

> **Say this**: "Word form means we write the number using WORDS, not digits. Like writing a check. Let's practice. I'll say a number, you write it in words."

Dictate these:
- 500 — "five hundred"
- 2,030 — "two thousand, thirty" (NOT "two thousand and thirty")
- 8,416 — "eight thousand, four hundred sixteen"

Key rules to reinforce:
1. No "and" in whole numbers.
2. Skip any place with a zero (don't say "zero hundred").
3. Hyphenate numbers 21-99 (twenty-one, thirty-five, etc.) — but accept either hyphenated or not at this level.

---

## Block 2: Social Studies (45 minutes)

### Michigan Geography — The Land and the People Who Knew It First

**Start time**: _____ **End time**: _____

**Standards**: 4-G1.0.1, 4.RI.1, 4.RI.2, 4.W.2, 4.SL.1

---

### Hook (5 minutes)

> **Say this**: "Hold up your right hand. Palm facing you, fingers together, thumb sticking out a little to the side. Now look at it."

Pull up a map of Michigan on a screen or on paper and hold it next to the student's hand.

> **Say this**: "See anything familiar? Michigan's Lower Peninsula looks like a mitten! People in Michigan use their hand as a map all the time — they'll point to a spot on their palm and say, 'I live right about here.' The Upper Peninsula is above your hand, separated by water."

Pause. Let the student compare their hand to the map.

> **Say this**: "Now here's something important. Before anyone drew this shape on a map, before anyone called it 'Michigan,' there were people who already lived here for thousands of years. The Anishinaabe people — that includes the Ojibwe, the Odawa, and the Potawatomi. They're called the People of the Three Fires, and they knew every river, every lake, every hill on this land. In fact, the word 'Michigan' comes from their word 'michi-gami,' which means 'great water' or 'large lake.' The state is named after what the Anishinaabe called the lake. The people named this place."

---

### Lesson (15 minutes)

Read this aloud to your student. Pause at the **[PAUSE]** marks to let the information land and to check for understanding.

> **Say this**: "Let's start with the shape of the state. Michigan has TWO peninsulas — that's a word that means 'almost an island,' a piece of land surrounded by water on three sides. The big mitten-shaped one is the Lower Peninsula, and the one above it is the Upper Peninsula. People who live in the Upper Peninsula call themselves 'Yoopers' — U.P.-ers, get it?"

**[PAUSE]**

> **Ask**: "Can you point to each peninsula on the map?"

> **Say this**: "Now, the water. Michigan is surrounded by FOUR of the five Great Lakes. These are the largest freshwater lakes in the world. Here they are:

> **Lake Superior** — it's the biggest and deepest. It touches the Upper Peninsula on the north side. The Ojibwe called it 'Gichigami,' which also means 'great sea.' You might have heard of the Edmund Fitzgerald shipwreck — that happened on Lake Superior because the storms can be as powerful as ocean storms.

> **Lake Michigan** — the only Great Lake that is entirely inside the United States. It runs along the whole west side of the Lower Peninsula. This is where you'll find the famous Sleeping Bear Dunes — massive sand dunes hundreds of feet high. The Ojibwe story says those dunes are a mother bear waiting for her cubs who were lost crossing the lake.

> **Lake Huron** — it borders Michigan on the east side of the Lower Peninsula and the south side of the Upper Peninsula. It's connected to Lake Michigan at the Straits of Mackinac, right where the Mackinac Bridge crosses. The name 'Mackinac' comes from 'Michilimackinac,' an Anishinaabe word that may mean 'great turtle' because the island there looked like a turtle from the water.

> **Lake Erie** — it touches just the very bottom corner of Michigan, near the city of Detroit. Erie is the shallowest of the Great Lakes."

**[PAUSE]**

> **Say this**: "Here's a way to remember which Great Lakes touch Michigan. Take the word **SHME** — Superior, Huron, Michigan, Erie. Silly word, but it works. Or you can just remember: Michigan touches every Great Lake except Ontario."

**[PAUSE]**

> **Say this**: "Now let's talk about the land itself. Michigan isn't just flat farmland — it has all kinds of landforms:

> **Sand dunes** along the Lake Michigan coast — some of the biggest freshwater dunes in the world. Sleeping Bear Dunes rises 450 feet above the lake. That's taller than a 35-story building.

> **Forests** cover more than half the state. The Upper Peninsula is especially thick with forest — sugar maple, white pine, birch, and hemlock. The white pine is Michigan's state tree. In the 1800s, Michigan was the biggest lumber producer in the country. The forests the Anishinaabe had stewarded for generations were heavily logged during that period.

> **Rivers** — Michigan has more than 36,000 miles of rivers and streams. The Grand River is the longest, running 252 miles through the Lower Peninsula. Rivers were the original highways. The Anishinaabe used birch bark canoes to travel, trade, and fish along these waterways for thousands of years.

> **Wetlands** — Michigan has more than 5.5 million acres of wetlands. These swampy, marshy areas are incredibly important. They filter water, prevent floods, and are home to hundreds of species of birds, fish, and plants. The Anishinaabe harvested wild rice from wetlands — it was a staple food and remains culturally important today."

**[PAUSE]**

> **Say this**: "Here's the big idea I want you to hold on to: geography is not just about shapes on a map. Geography shapes how people LIVE. The Anishinaabe settled near the Great Lakes and rivers because the water gave them everything — fish to eat, waterways to travel on, wild rice to harvest, and trade routes connecting nations across the entire region. They weren't just 'living off the land.' They were scientists, engineers, and geographers. They knew which fish ran in which rivers at which times of year. They managed forests with controlled burns to help certain plants grow. They mapped trade networks that stretched from the Atlantic Ocean to the Great Plains. That knowledge was built over thousands of years. Geography and people — they shape each other."

---

### Activity: Map of Michigan (20 minutes)

> **Say this**: "Now you're going to make your own map of Michigan. Not a traced copy — YOUR map. A geographer's map. You're going to draw it, label it, and add information that matters."

**Instructions for the student:**

1. **Draw the outline of both peninsulas.** Use your hand for the Lower Peninsula shape. The Upper Peninsula is a long, narrow strip above it, tilted slightly. It doesn't have to be perfect — real cartographers made rough maps for centuries.

2. **Label the 4 Great Lakes** in blue: Superior (above the U.P.), Michigan (left of the L.P.), Huron (right of the L.P. and below the U.P.), Erie (bottom right corner).

3. **Mark at least 3 landforms** with small drawings or symbols and labels:
   - Sleeping Bear Dunes (northwest coast of L.P.)
   - The forests of the Upper Peninsula
   - The Grand River (runs east-west through southern L.P.)
   - Wetlands (found throughout, but especially in the eastern U.P.)

4. **Mark a city you know** — if you live in Michigan, mark your city. If not, mark Detroit (southeast corner where Lake Erie meets Lake Huron/St. Clair).

5. **Add Indigenous place names.** Use this reference list to write the Anishinaabe or origin name next to at least TWO English place names:

#### Indigenous Place Name Reference

| English Name | Origin Name | Meaning / Context |
|---|---|---|
| Michigan | Michi-gami (Anishinaabe) | "Great water" or "large lake" |
| Detroit | Waawiyaatanong (Anishinaabe), later d'etroit (French, "the strait") | "Where the water goes around" — describes the river bend |
| Mackinac / Mackinaw | Michilimackinac (Anishinaabe) | Possibly "great turtle" — the island's shape |
| Kalamazoo | Kikalamozoo (Potawatomi) | "Boiling water" — describes the bubbling river |
| Saginaw | Saaginaaw (Ojibwe) | "Land of the Sauk" — another Indigenous nation |
| Muskegon | Masquigon (Ottawa/Odawa) | "Marshy river" or "swampy" |
| Washtenaw | Waashtenong (Ojibwe) | "Far away" or "on the far side" |

> **Say this**: "Take your time. Use colors. Label things clearly. This is YOUR map — a geographer's map of Michigan, with the names the land had first."

Give the student 20 minutes. Check in after 10 minutes to see their progress. If they are struggling with the shape, let them look at a reference map — the goal is labeling and knowledge, not artistic perfection.

---

### Discussion (5 minutes)

When the map is finished, sit together and look at it.

> **Ask**: "Why do you think so many cities in Michigan are near water?"

**Listen for**: connections between water and daily life — drinking, fishing, transportation, trade, farming (irrigation), or energy (water power). Any of these are good answers.

**If the student says a general answer like "because people need water":**

> **Say this**: "Yes! Now think deeper. What SPECIFIC things can you do when you live near water? Can you get food from it? Can you travel on it? Can you trade with people in other places using it?"

**If the student struggles or gives a one-word answer:**

> **Say this**: "Think about what you need water for — drinking, fishing, traveling, growing food. If you were choosing where to build a village thousands of years ago, you didn't have trucks or grocery stores. You needed to be near the things that kept you alive. Water was the most important one. The Anishinaabe knew that. Every major settlement was near water. And look — modern cities are STILL built in those same spots."

> **Ask as a follow-up**: "Can you find a city on your map that ISN'T near water?"

*This is a trick observation — almost every major Michigan city IS near water. Let them discover that.*

---

### Historical Context — A Note for the Parent

This section is for your understanding. You do not need to read it aloud — it informs how you frame the lesson.

The Anishinaabe — the Ojibwe (also called Chippewa), the Odawa (also called Ottawa), and the Potawatomi — are the Three Fires Confederacy. They have lived in the Great Lakes region for thousands of years. Their geographic knowledge was not primitive or incidental. They maintained sophisticated systems:

- **Seasonal migration patterns** — moving between summer fishing camps, fall wild rice beds, winter hunting grounds, and spring maple sugar camps. This was a planned, annual cycle based on deep ecological knowledge.
- **Trade networks** — birch bark canoes carried goods across the Great Lakes and connected nations from the East Coast to the Great Plains. Copper from the Upper Peninsula was traded as far as the Gulf of Mexico.
- **Land management** — controlled burns cleared underbrush, encouraged berry growth, and maintained healthy forests. This was intentional stewardship, not random fire.
- **Mapping** — oral traditions carried detailed geographic knowledge across generations. Routes, landmarks, seasonal resources, and safe harbors were all encoded in stories, songs, and place names.

When teaching Michigan geography, frame Indigenous peoples as the FIRST geographers. They did not simply "exist" on the land — they studied it, managed it, named it, and built civilizations around it. European cartographers who later mapped the region frequently relied on Indigenous guides and adopted Indigenous place names (most of which we still use today).

This is not a "before" story that exists only to set up a European "after." The Anishinaabe nations are still here. The Sault Ste. Marie Tribe of Chippewa Indians, the Grand Traverse Band of Ottawa and Chippewa Indians, the Little Traverse Bay Bands of Odawa Indians, and many others maintain sovereignty and cultural practices in Michigan today.

---

## Discussion Lunch

No lesson. No structure. Just a conversation starter over food.

> **Ask over lunch**: "If you could live anywhere in Michigan, where would you pick and why? Think about what you learned today — the lakes, the dunes, the forests, the rivers. What kind of place would you choose?"

Let it be a real conversation. Share your own answer too. If the student picks a place from the lesson (Sleeping Bear Dunes, Mackinac Island, the Upper Peninsula), ask them what they'd do there every day. If they pick their own city, ask them what geographic feature they like most about where they live.

---

## End-of-Day Check

Before you close out Thursday, quickly verify:

- [ ] **Math**: Student can fill in a place value chart for a 4- or 5-digit number without blocks
- [ ] **Math**: Student can write a number in expanded form AND word form
- [ ] **Math**: Student can compare two numbers using < > = and explain their reasoning
- [ ] **Social Studies**: Student can name at least 3 of the 4 Great Lakes bordering Michigan
- [ ] **Social Studies**: Student can name at least 2 Michigan landforms
- [ ] **Social Studies**: Student knows that "Michigan" comes from an Anishinaabe word meaning "great water"
- [ ] **Map**: Completed and saved in student's portfolio/folder

If any boxes are unchecked, note them. Friday's lesson will have review time built in.

---

## Friday Preview

Tomorrow is **Boot Sequence Day 3**. In math, we move further into pictorial and start working with number lines for comparison. In social studies, we go deeper into how Michigan's geography created different regions and how those regions supported different ways of life. The week closes with a short reflection activity.

---

*Root Access Learning OS — Week 1, Thursday*
*Boot Sequence: Day 2*

---

(c) 2026 Root Access Learning OS. All rights reserved.
