# Week 1 — Wednesday

## Boot Sequence: Day 1

**Grade:** 4 | **Standards:** 4.NBT.1, 4.NBT.2, 4-PS3-1, 4.RI.4, 4.W.2, 4.SL.1
**Total instructional time:** ~2 hours 15 minutes (with breaks built in)

---

## Materials Checklist

Gather everything before the day starts. No mid-lesson scavenger hunts.

### Math
- [ ] Base-ten blocks (units, rods, flats, cubes) — physical manipulatives required today
- [ ] Place value chart (printed or hand-drawn on blank paper — template below)
- [ ] Dry-erase board or scratch paper
- [ ] Pencil and eraser
- [ ] Math journal or dedicated spiral notebook

### Science
- [ ] Ramp: a cutting board, cookie sheet, or sturdy hardcover book (at least 18 inches long)
- [ ] Stack of books for propping the ramp (you need 3 different heights — roughly 2 inches, 5 inches, 8 inches)
- [ ] A toy car with wheels that roll freely (or a marble — car is better because it travels straighter)
- [ ] 6 plastic cups OR a tower of small wooden/plastic blocks (at least 10 blocks)
- [ ] Ruler or tape measure
- [ ] Masking tape (to mark the start line and tower position)
- [ ] Science journal or dedicated spiral notebook
- [ ] Pencil, colored pencils optional

### General
- [ ] Timer or phone with timer
- [ ] Morning journal (can be the same notebook)
- [ ] A snack for Discussion Lunch

---

## Morning Work (15 min)

Set out the journal, a pencil, and nothing else. No screens. This is quiet, focused writing time.

> **Say this:** "Before we do anything today, I want you to write. This is your journal, and there are no wrong answers. Take your time. Think before you write."

### Journal Prompt

Write this prompt at the top of a fresh page (or read it aloud and have the student copy it):

**"If you could spend one whole year getting really, deeply good at something — not just okay, but genuinely excellent — what would you pick? Why that thing? What would it feel like to be that good?"**

**Parent instructions:** Set a timer for 12 minutes. Let them write. Resist the urge to help unless they say they're stuck. If they finish early, ask: *"Can you add more about why?"* If they're stuck at the start, say: *"Close your eyes for ten seconds and picture yourself being amazing at something. What did you see?"*

When the timer goes off, ask them to read it aloud to you. Listen. Respond to what they said — not to how they wrote it. Today is about trust, not corrections.

> **Say this (after they read aloud):** "I love that you picked that. This year, we're going to learn how to get good at things — really good. Math, science, writing, all of it. And it starts right now."

---

## Block 1: Math (60 min) — Place Value

**Standards:** 4.NBT.1, 4.NBT.2
**Approach:** Singapore Math — Concrete > Pictorial > Abstract. Today we stay mostly concrete.

---

### Launch (10 min)

**Setup:** Put the base-ten blocks on the table between you. Have a flat (hundred square), a rod (ten stick), and a single unit cube in front of you. No paper yet.

> **Say this:** "Okay. First day. Let's start with something that seems simple but is actually wild once you really see it."

Hold up a single unit cube.

> **Say this:** "What's this worth?"

*(Wait for answer: one.)*

> **Say this:** "Right. One. Now watch."

Line up ten unit cubes in a row. Then set one rod next to them.

> **Say this:** "Count those little cubes. Ten, right? And this rod — it's the same as all ten of those cubes pushed together. Same amount. But instead of counting ten tiny pieces, we just use this one piece. It represents ten."

Now hold up the flat (hundred square).

> **Say this:** "So if one rod is ten... how many rods do you think make one of these?"

*(Let them answer — or count the lines on the flat. Answer: ten rods = one flat.)*

> **Say this:** "So this flat is ten tens. What's ten tens?"

*(Wait: one hundred.)*

> **Say this:** "Here's the thing that blows my mind about math. The number 3 — just the digit 3 — can mean totally different things depending on where it sits. If I write the number 35, that 3 means thirty. Three tens. But if I write 305, that same 3 means three hundred. And in 3,000? Three thousand. Same digit. Completely different value. The POSITION is what gives it power. That's called place value."

Pick up a rod.

> **Say this:** "So this rod? It's not just 'a ten.' It's worth ten TIMES more than one of those little cubes. Every time you move one place to the left, the value gets ten times bigger. Every single time. That's the rule. That's the whole system."

**Check:** Ask the student to show you what 23 looks like with blocks (2 rods, 3 units). Then ask them to show 230 (2 flats, 3 rods). Ask: *"What happened to the 2? It used to be tens, now it's..."* (hundreds). *"It got ten times bigger because it moved one place to the left."*

---

### Guided Practice (20 min)

Work these three problems TOGETHER. The student handles the blocks. You guide.

---

#### Problem 1: Identifying the Value of a Digit
**Real-world context: Money**

> **Say this:** "Let's say your grandma tells you she's putting $4,572 into a savings account for your college fund. That's awesome. But I want to know — what is the 5 worth in that number? Not what digit it is. What it's WORTH."

**Step 1 — Build it with blocks.**
Have the student build 4,572:
- 4 cubes (thousands) — if you don't have a thousands cube, stack 4 flats and say "pretend each of these stacks is a thousand"
- 5 flats (hundreds)
- 7 rods (tens)
- 2 unit cubes (ones)

**Step 2 — Identify the position.**

> **Say this:** "Okay. Point to the 5. Now — what column is it sitting in? Let's count from the right: ones, tens, hundreds... It's in the hundreds place."

**Step 3 — State the value.**

> **Say this:** "So the digit is 5, but its VALUE is 500. It's not five dollars. It's five hundred dollars. The place tells you the value."

**Answer:** The 5 in 4,572 is in the hundreds place. Its value is 500.

---

#### Problem 2: Writing a Number in Expanded Form
**Real-world context: Distance**

> **Say this:** "The driving distance from our house to Mackinac Island is about 3,286 miles if you take the long way around. Let's break that number apart — pull it into pieces so we can see what each digit is really worth. That's called expanded form."

**Step 1 — Build it with blocks.**
Have the student build 3,286.

**Step 2 — Separate the groups.**

> **Say this:** "Now spread them out. Put the thousands over here, hundreds here, tens here, ones here. Like sorting laundry — each type gets its own pile."

**Step 3 — Draw a quick place value chart.** (This is the move from concrete to pictorial.)

Draw this on scratch paper or a dry-erase board:

```
| Thousands | Hundreds | Tens | Ones |
|-----------|----------|------|------|
|     3     |    2     |  8   |  6   |
```

**Step 4 — Write expanded form.**

> **Say this:** "Now write what each digit is really worth, and put plus signs between them."

**Answer:** 3,286 = 3,000 + 200 + 80 + 6

> **Say this:** "See? You took one number and cracked it open. Each piece shows the real value of each digit. That's expanded form."

---

#### Problem 3: Comparing Two Multi-Digit Numbers
**Real-world context: Population**

> **Say this:** "Let's say the town of Holland, Michigan has a population of 6,243 people, and the town of Traverse City has 5,891. Which town has more people? Seems obvious — but I want you to PROVE it, not just guess."

**Step 1 — Build both numbers with blocks, side by side.**

6,243 on the left. 5,891 on the right.

**Step 2 — Compare from the LEFT.**

> **Say this:** "When you compare big numbers, always start from the biggest place — the left side. Look at the thousands place first. What do you see?"

*(6 thousands vs. 5 thousands.)*

> **Say this:** "Six thousand is more than five thousand. Do we even need to look at the hundreds?"

*(No — the thousands already decided it.)*

**Step 3 — Write it.**

**Answer:** 6,243 > 5,891 because 6 thousands is greater than 5 thousands.

> **Say this:** "But what if the thousands were the SAME? Then you'd move one place to the right and compare the hundreds. You keep going until something is different. Left to right, biggest place first. Always."

---

### Independent Practice (20 min)

> **Say this:** "Your turn. Five problems. Use your blocks if you need them — that's not babyish, that's smart. I'm right here if you get stuck, but try each one on your own first."

Hand the student a clean sheet of paper (or their math journal). Read each problem aloud and let them write and solve. They should show their work.

---

**Problem 1** (Easy — identify digit value)

In the number **7,394**, what is the value of the digit 3?

---

**Problem 2** (Easy — write in expanded form)

Write the number **5,817** in expanded form.

---

**Problem 3** (Medium — compare two numbers)

Which is greater: **4,629** or **4,682**? Use >, <, or = and explain how you know.

---

**Problem 4** (Medium — write a number from expanded form)

What number is this?
**2,000 + 400 + 60 + 9**

Write it as a standard number with a comma.

---

**Problem 5** (Hard — multi-step, combined skills)

Marcus has 3,456 baseball cards. Priya has a collection where the thousands digit is the same as Marcus's, the hundreds digit is worth 200 more than Marcus's hundreds digit, the tens digit is 5, and the ones digit is 0. How many cards does Priya have? Write her number in expanded form. Who has more cards?

---

### Answer Key with Explanations

**Problem 1:**
The digit 3 is in the **hundreds** place. Its value is **300**.
*(Common error: student says "3." Redirect: "3 is the digit. What is it WORTH? How many hundreds is it?")*

**Problem 2:**
5,817 = **5,000 + 800 + 10 + 7**
*(Check: Do the pieces add back up to 5,817? 5,000 + 800 = 5,800. 5,800 + 10 = 5,810. 5,810 + 7 = 5,817. Yes.)*

**Problem 3:**
4,629 **<** 4,682
Explanation: The thousands digits are the same (4 = 4). The hundreds digits are the same (6 = 6). Compare the tens: 2 < 8. So 4,629 is less than 4,682.
*(Common error: student compares only the first digit and says "they're equal." Redirect: "When the first digits match, move right.")*

**Problem 4:**
**2,469**
*(Check: Does 2,000 + 400 + 60 + 9 = 2,469? Yes.)*

**Problem 5:**
Marcus has 3,456 cards.
- Priya's thousands digit: same as Marcus's = **3**
- Priya's hundreds digit: Marcus's hundreds value is 400, plus 200 more = **600**, so the digit is **6**
- Priya's tens digit: **5**
- Priya's ones digit: **0**

Priya has **3,650** cards.
Expanded form: **3,000 + 600 + 50 + 0**
Comparison: 3,650 > 3,456 — **Priya has more cards.**
*(This problem requires reading carefully. If the student gets stuck, ask: "What is Marcus's hundreds digit worth?" and build from there.)*

---

### Beast Academy Challenge (10 min)

> **Say this:** "Okay. This last one is meant to be tricky. It's a puzzle. Don't panic if it takes a few tries — that's the whole point."

**The Puzzle:**

I am a 4-digit number.
- My thousands digit is odd and less than 5.
- My hundreds digit is double my thousands digit.
- My tens digit is the sum of my thousands digit and ones digit.
- My ones digit is 2.
- The value of my hundreds digit is greater than the value of my tens digit.

What number am I? Write me in expanded form.

**Solution and Reasoning:**

Start with what we know for certain:
- Ones digit = **2**
- Thousands digit is odd and less than 5, so it's **1** or **3**

Test thousands digit = 1:
- Hundreds digit = double 1 = **2**
- Tens digit = 1 + 2 = **3**
- Check: Is the value of the hundreds digit (200) greater than the value of the tens digit (30)? **Yes.** 200 > 30.
- Number: **1,232**

Test thousands digit = 3:
- Hundreds digit = double 3 = **6**
- Tens digit = 3 + 2 = **5**
- Check: Is the value of the hundreds digit (600) greater than the value of the tens digit (50)? **Yes.** 600 > 50.
- Number: **3,652**

Both work based on the clues given. **Either 1,232 or 3,652 is correct.**

- 1,232 in expanded form: 1,000 + 200 + 30 + 2
- 3,652 in expanded form: 3,000 + 600 + 50 + 2

> **Say this (if the student finds one):** "Great — but is that the ONLY answer? Can you find another number that fits all the clues?"

> **Say this (if the student finds both):** "You just proved that some puzzles have more than one right answer. That's real mathematical thinking."

---

### Bug Check

Use this section if the student struggled. Pick the error pattern that matches what you observed.

#### Error 404: Student can't identify place values at all.
Go back to 2-digit numbers. Build **37** with blocks — 3 rods, 7 units. Have the student physically trade 10 unit cubes for 1 rod. Ask: *"How many tens? How many ones?"* Then build **73**. Ask: *"What changed? The 3 used to be tens. Now what is it?"* Work up to 3-digit, then 4-digit numbers only after 2-digit is solid.

#### Error 500: Student says "the 5 is worth 5" when it's in the hundreds or thousands place.
Build the number with blocks. Point to the hundreds pile. Say: *"Count these flats. Five, right? But each flat is a hundred. So is this five, or five hundred? Count by hundreds with me: one hundred, two hundred, three hundred, four hundred, five hundred."* The student needs to hear the difference between the digit and the value.

#### Syntax Error: Student understands the concept but writes numbers without commas or writes expanded form incorrectly.
This is formatting, not comprehension. Say: *"Your math brain is working. Now let's clean up the writing."* Teach the comma rule: starting from the right, count three digits and place a comma. Practice with five numbers. For expanded form, always verify: *"Do your pieces add back up to the original number?"*

---

## Block 2: Science (45 min) — Energy and Speed

**Standard:** 4-PS3-1 — Use evidence to construct an explanation relating the speed of an object to the energy of that object.
**ELA Integration:** 4.RI.4 (vocabulary), 4.W.2 (informative writing), 4.SL.1 (discussion)

---

### Hook (5 min)

Grab a ball or toy car. Roll it gently across the table toward a plastic cup. Then roll it hard.

> **Say this:** "Watch this."

*(Roll it gently. Cup barely moves or doesn't fall.)*

> **Say this:** "Now watch this."

*(Roll it hard. Cup gets knocked over or pushed far.)*

> **Say this:** "Same ball. Same cup. Same table. What was different?"

*(Let the student answer. They'll likely say "you pushed it harder" or "it went faster.")*

> **Say this:** "Right. The ball moved faster the second time. And when it was faster, it did MORE to that cup. It pushed it farther. It hit harder. Why? That's what we're figuring out today."

---

### Lesson (15 min)

> **Say this:** "When something is moving, it has energy. Not the kind of energy like 'I'm tired' or 'I had too much sugar.' A specific kind: kinetic energy. Let's break that word down."

Write **kinetic energy** on a piece of paper or whiteboard.

> **Say this:** "Kinetic means 'moving.' So kinetic energy is the energy something has BECAUSE it's moving. A parked car has zero kinetic energy. A car driving down the highway has a lot. A baseball sitting on the ground? Zero. A baseball flying through the air after a hit? A ton of kinetic energy."

> **Say this:** "Here's the big idea: the FASTER something moves, the MORE kinetic energy it has. And more energy means it can do more stuff — push things farther, knock things over, make a bigger crash."

Write these vocabulary words and have the student copy them into their science journal:

| Word | Meaning |
|------|---------|
| **Energy** | The ability to make something happen — to push, pull, move, or change something |
| **Kinetic energy** | The energy an object has because it is moving |
| **Speed** | How fast something is moving — the distance it travels in a certain amount of time |
| **Force** | A push or pull on an object |
| **Collision** | When two objects hit each other |

> **Say this:** "So when our ball rolled fast and smashed into that cup, here's what happened in science language: the ball had high kinetic energy because of its high speed. When the collision happened, that energy transferred to the cup and pushed it far. When the ball rolled slow, it had low kinetic energy, so the collision barely moved the cup."

> **Say this:** "Now we're going to test this for real. Like scientists. We're going to run an experiment, collect data, and prove it."

---

### Activity: The Ramp Experiment (20 min)

#### Setup (5 min)

1. Place a strip of masking tape on the floor (or table) to mark where the bottom of the ramp will be.
2. Place another strip of tape about 6 inches from the bottom of the ramp. This is where the cup tower goes.
3. Build a tower of 6 plastic cups (stacked in a pyramid: 3 on bottom, 2 in middle, 1 on top) at the second tape mark.
4. Prop the ramp (cutting board or book) against a stack of books. Start with a LOW height — about 2 inches at the top end.
5. Place the car at the very top of the ramp. Mark this starting spot with a small piece of tape so the release point is consistent.

> **Say this:** "We're going to release this car from the same spot every time. The only thing we're changing is the height of the ramp. That means if anything different happens to the cups, it's because of the height — not because we pushed harder or started in a different spot."

#### Data Collection Sheet

Have the student draw this table in their science journal:

```
RAMP EXPERIMENT — Energy and Speed

My prediction: ________________________________________________

| Trial | Ramp Height | What I predict will happen | Cups knocked down | How far cups scattered (estimate) |
|-------|-------------|---------------------------|-------------------|-----------------------------------|
|   1   | Low (~2 in) |                           |                   |                                   |
|   2   | Med (~5 in) |                           |                   |                                   |
|   3   | High (~8 in)|                           |                   |                                   |
```

#### Running the Experiment

**Before any trials:**

> **Say this:** "Before we start, I want your prediction. Write it at the top: what do you THINK will happen as we make the ramp higher?"

**Trial 1 — Low Ramp (~2 inches)**

1. Stack books so the top of the ramp is about 2 inches high.
2. Rebuild the cup tower at the tape mark.
3. Have the student place the car at the top of the ramp and release it — no pushing.
4. Observe: How many cups fell? How far did they scatter?
5. Student records data in the table.

> **Say this:** "Good. What did you notice? Was the car moving fast or slow when it hit the cups?"

**Trial 2 — Medium Ramp (~5 inches)**

1. Add books so the top of the ramp is about 5 inches high.
2. Rebuild the cup tower exactly the same way.
3. Release the car from the same starting spot.
4. Observe and record.

> **Say this:** "Compare that to Trial 1. What changed? Was the car faster or slower? What happened to the cups?"

**Trial 3 — High Ramp (~8 inches)**

1. Raise the ramp to about 8 inches.
2. Rebuild the cup tower.
3. Release the car.
4. Observe and record.

> **Say this:** "Okay — look at your data. All three trials. What pattern do you see?"

#### Conclusions

Have the student write 3-4 sentences in their science journal answering these questions:

1. What happened to the speed of the car as the ramp got higher?
2. What happened to the cups as the car got faster?
3. What does this tell us about the relationship between speed and energy?

> **Say this:** "Use the vocabulary we learned. I want to see the words 'kinetic energy,' 'speed,' and 'collision' in your writing."

**Sample student response (for parent reference — do not read this to the student):**

*"When the ramp was higher, the car went faster. When the car was faster, it knocked down more cups and pushed them farther. This shows that a faster object has more kinetic energy. In the collision, the car transferred more energy to the cups when it was moving at a higher speed."*

If the student's response captures the core idea — faster = more energy = bigger impact — they've got it.

---

### Discussion (5 min)

> **Say this:** "Last thing. Think about real life. Can you give me an example of when speed changes how much energy something has? Think about sports, cars, weather — anything."

Let them talk. Possible answers:
- A fast baseball hurts more to catch than a slow one
- A car crash at high speed is worse than a fender bender
- A fast river current can move rocks but slow water can't
- A bowling ball rolled fast knocks down more pins

> **Say this:** "Every single one of those is the same science we just tested on our little ramp. Faster speed, more kinetic energy, bigger effect. That's a real physics principle, and you just proved it with cups and a toy car."

---

## Discussion Lunch

While eating, ask:

> **"If you dropped a bowling ball and a tennis ball from the same height, which one would knock over more cups? Is it only speed that matters, or does something else matter too?"**

*(This previews the concept of mass and kinetic energy — don't teach it yet. Just let them wonder. If they say "the heavier one," say: "Interesting. Why do you think that?" and leave it open.)*

---

## End of Day

> **Say this:** "That was Day 1. You did real math and real science today. Not worksheets about math and science — the actual thing. That's how this year is going to work. See you tomorrow."

---

*Total time: approximately 2 hours 15 minutes (Morning Work 15 min + Math 60 min + Science 45 min + Discussion Lunch 15 min)*

---

© 2026 Root Access Learning OS. All rights reserved.
