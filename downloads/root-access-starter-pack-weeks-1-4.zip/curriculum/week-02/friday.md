# Week 02 — Friday Lesson Plan

## Loading Dependencies: Day 3

**Grade:** 4 | **Standards:** 4.NBT.2, 4.NBT.3, 4-PS3-2, 4.W.2, 4.W.4, 4.SL.1
**Total instructional time:** ~3 hours (Math + Science + Coding + Discussion Lunch)

## Parent Pre-Read (5 min)

Today wraps up Week 2. Math combines comparing and rounding — your student uses both skills together to estimate and check reasonableness. Science explores energy transfer through heat, extending Wednesday's collision work into thermal transfer (heat moving from a warm object to a cool one). The coding block introduces events in Scratch — making sprites respond when things happen (keyboard presses, clicks). End the day celebrating another week completed.

---

## Morning Work (15 min)

**Type:** Reflection + Review

> **Say this:** "Two quick rounding problems, then a reflection question."

### Quick Review (8 min)

**1.** Round 6,748 to the nearest hundred.

**2.** Round 35,501 to the nearest thousand.

#### Answers

| # | Answer | Notes |
|---|--------|-------|
| 1 | 6,700 | Tens digit 4 < 5, round down. |
| 2 | 36,000 | Hundreds digit 5 = 5, round up. |

### Reflection (7 min)

**Prompt:** *"Think about this week — the number lines, the rounding, the dominoes, the cities on the map. What is one thing that clicked for you this week — something that went from confusing to clear? How did it click?"*

---

## Block 1: Math (60 min) — Comparing and Rounding Combined

### Today's Objective

Student can use comparing and rounding together: round numbers before comparing, use rounding to estimate and check reasonableness, and solve multi-step problems that require both skills.

### Standards
- **4.NBT.2:** Compare two multi-digit numbers using >, =, and <
- **4.NBT.3:** Use place value understanding to round multi-digit whole numbers to any place
- **4.SL.1:** Engage effectively in collaborative discussions

---

### Launch (10 min)

> **Say this:** "This week you learned two skills: comparing numbers and rounding them. Today, we put them together. Here's why that matters."

Write on the board:

**Store A: TV costs $1,287**
**Store B: TV costs $1,349**

> **Say this:** "Which store has the cheaper TV?"

*(Store A — $1,287 < $1,349.)*

> **Say this:** "Now — if someone asked you 'about how much does the cheaper TV cost?' you wouldn't say $1,287. You'd round it. To the nearest hundred: $1,300. To the nearest ten: $1,290. Rounding gives you a quick, easy-to-remember number. Comparing tells you which is bigger or smaller. Together, they help you make real decisions."

Now write:

**Fundraiser A raised about $5,000. Fundraiser B raised about $5,000.**

> **Say this:** "Both raised 'about $5,000.' Does that mean they raised the same amount?"

*(Not necessarily — one could have raised $4,600 and the other $5,400, and both round to $5,000.)*

> **Say this:** "That's the important thing about rounding: it loses precision. Two different numbers can round to the same thing. So when you compare rounded numbers that are the same, you might need to go back to the original numbers to see the real difference. Rounding is a tool, not a final answer."

---

### Guided Practice (20 min)

#### Problem 1: Round Then Compare

> **Say this:** "Two Michigan cities reported their annual snowfall. Marquette got 14,382 inches over 100 years. Traverse City got 13,875 inches over 100 years. Round both to the nearest thousand and compare the rounded numbers."

**Step 1 — Round each number.**
- 14,382 → nearest thousand → **14,000** (hundreds digit 3 < 5, round down)
- 13,875 → nearest thousand → **14,000** (hundreds digit 8 ≥ 5, round up)

**Step 2 — Compare the rounded numbers.**

> **Say this:** "They both round to 14,000. So at a glance, they seem about the same. But are they really the same?"

*(No — 14,382 > 13,875.)*

> **Say this:** "This is why rounding is an estimate, not the final answer. The rounded numbers look equal, but the actual numbers are different. Marquette got more snow. Rounding helped us see they're CLOSE — but comparing the originals tells us which is actually bigger."

**Answer:** Both round to 14,000, but the original numbers show 14,382 > 13,875. Marquette had more snow.

---

#### Problem 2: Estimation Check

> **Say this:** "A student solved this addition problem: 3,847 + 2,156 = 6,003. Let's use rounding to check if that answer is reasonable."

**Step 1 — Round each number to the nearest thousand.**
- 3,847 → **4,000**
- 2,156 → **2,000**

**Step 2 — Add the rounded numbers.**
- 4,000 + 2,000 = **6,000**

**Step 3 — Compare the estimate to the answer.**

> **Say this:** "Our estimate is 6,000. The student's answer is 6,003. Is 6,003 close to 6,000?"

*(Yes — very close.)*

> **Say this:** "So the answer is reasonable. If the student had written 60,003 or 603, we'd know something was wrong because those are way off from our estimate of 6,000. Rounding gives you a reality check."

**Answer:** The estimate (6,000) is close to the answer (6,003), so the answer is reasonable.

---

#### Problem 3: Multi-Step with Context

> **Say this:** "The Detroit Zoo had 47,826 visitors in June and 52,341 visitors in July. Which month had more visitors? About how many more? Round to the nearest thousand to estimate the difference."

**Step 1 — Compare.**
47,826 vs. 52,341: ten-thousands 4 < 5, so 52,341 > 47,826. July had more visitors.

**Step 2 — Round both to estimate the difference.**
- 47,826 → **48,000**
- 52,341 → **52,000**
- Estimated difference: 52,000 - 48,000 = **4,000**

**Answer:** July had more visitors. The difference is approximately 4,000 visitors.

---

### Independent Practice (20 min)

> **Say this:** "Five problems. Show all your work — round, compare, explain."

---

**Problem 1** (Easy — round and compare)

Round both numbers to the nearest hundred and compare:
- 4,672 and 4,718

---

**Problem 2** (Easy — reasonableness check)

A student says 7,254 + 1,823 = 9,077. Use rounding to the nearest thousand to check if this answer is reasonable.

---

**Problem 3** (Medium — round to different places)

The number 28,465 is rounded to the nearest thousand AND the nearest ten-thousand. What are the two rounded values? Are they the same or different? Explain why.

---

**Problem 4** (Medium — real-world context)

Three schools collected canned goods:
- Oak Elementary: 2,847 cans
- Pine Elementary: 3,125 cans
- Maple Elementary: 2,980 cans

Round each to the nearest hundred. Then order the schools from most cans to fewest, using the rounded numbers. Does the order change if you use the exact numbers?

---

**Problem 5** (Hard — multi-step reasoning)

Lake Huron has a surface area of 23,007 square miles. Lake Michigan has a surface area of 22,404 square miles. A student rounds both to the nearest thousand and says "They're both about 23,000 square miles, so they're the same size." Is the student correct? Explain your reasoning using both the rounded and exact numbers.

---

### Answer Key

**Problem 1:**
4,672 → nearest hundred → **4,700**. 4,718 → nearest hundred → **4,700**. Both round to 4,700. But 4,672 < 4,718 (tens: 7 vs. 1 — wait, comparing the originals: 4,672 vs. 4,718. Hundreds same (6 vs. 7) — 6 < 7. So 4,672 < 4,718. The rounded numbers hide this difference.

**Problem 2:**
7,254 → **7,000**. 1,823 → **2,000**. 7,000 + 2,000 = **9,000**. The answer 9,077 is close to 9,000, so it is **reasonable**.

**Problem 3:**
- Nearest thousand: **28,000** (hundreds digit 4 < 5, round down)
- Nearest ten-thousand: **30,000** (thousands digit 8 ≥ 5, round up)
They are **different**. Rounding to a bigger place value loses more precision. The nearest thousand keeps us within 500 of the original; the nearest ten-thousand could be up to 5,000 away.

**Problem 4:**
- Oak: 2,847 → **2,800**
- Pine: 3,125 → **3,100**
- Maple: 2,980 → **3,000**
Rounded order (most to fewest): Pine (3,100) > Maple (3,000) > Oak (2,800).
Exact order: Pine (3,125) > Maple (2,980) > Oak (2,847). **Same order.** The rounding preserved the ranking in this case.

**Problem 5:**
Lake Huron: 23,007 → nearest thousand → **23,000**. Lake Michigan: 22,404 → nearest thousand → **22,000**. The student is **incorrect** — Lake Huron rounds to 23,000 and Lake Michigan rounds to 22,000, so they do NOT round to the same number. Even if they did, the exact numbers show Lake Huron (23,007) > Lake Michigan (22,404). The student's error was rounding incorrectly or not checking both numbers.

---

### Beast Academy Challenge (10 min)

> **Say this:** "This is a logic puzzle about rounding. Take your time."

**The Puzzle:**

I am a 4-digit number. When you round me to the nearest ten, you get 3,470. When you round me to the nearest hundred, you get 3,500. What are ALL the possible numbers I could be?

**Solution:**

Rounding to nearest ten gives 3,470: the number must be between 3,465 and 3,474.

Rounding to nearest hundred gives 3,500: the number must be between 3,450 and 3,549.

Both conditions must be true at the same time: the number must be between 3,465 and 3,474 AND between 3,450 and 3,549.

The overlap is: **3,465, 3,466, 3,467, 3,468, 3,469, 3,470, 3,471, 3,472, 3,473, 3,474.**

All 10 numbers are valid answers.

> **Say this:** "If you found the range 3,465 to 3,474, you nailed it. The trick is that BOTH rounding rules have to work at the same time. You're finding the overlap."

---

### Bug Check

- **Error 404** (No understanding): If the student cannot combine comparing and rounding, separate the skills. Do three pure rounding problems, then three pure comparison problems. Then try one combined problem with heavy support. The combination is not a new skill — it is using two existing skills in sequence.

- **Error 500** (Bad logic — rounds correctly but compares rounded numbers as if they are exact): This is the "they're both 5,000 so they're equal" error. Return to the launch example: two different numbers can round to the same value. Rounding tells you "about how much" — comparing exact numbers tells you "exactly how much." Both are useful, for different purposes.

- **Syntax Error** (Computation errors in rounding): Student understands the concept but makes mechanical errors — rounding to the wrong place, forgetting to zero out, etc. Slow them down. Have them underline the rounding digit, circle the decision digit, draw an arrow showing up or down, then write the answer. Add structure to reduce errors.

---

## Block 2: Science (45 min) — Energy Transfer: Heat

**Standard:** 4-PS3-2 — Make observations to provide evidence that energy can be transferred from place to place by sound, light, heat, and electric currents.
**ELA Integration:** 4.W.2 (informative writing), 4.SL.1 (discussion)

---

### Hook (5 min)

> **Say this:** "On Wednesday, we proved that energy transfers through collisions — a penny hits a penny, a domino hits a domino. But collisions aren't the only way energy moves. Today we're going to explore another way: HEAT."

Hold up the metal spoon and the wooden spoon.

> **Say this:** "I'm going to put both of these spoons in a cup of hot water. Before I do — make a prediction. Which spoon will feel hotter after 30 seconds? The metal one or the wooden one?"

Let them predict. Most will guess metal.

---

### Lesson (10 min)

> **Say this:** "Heat is a form of energy. When something is hot, its tiny particles are moving fast — vibrating, bouncing around. When a hot object touches a cooler object, the fast-moving particles bump into the slower ones and transfer energy to them. The cool object warms up. That's heat transfer."

> **Say this:** "Here's the key: heat ALWAYS moves from hot to cold. Never the other way. A hot cup of cocoa warms your cold hands — not the other way around. A warm blanket doesn't actually make heat. Your body makes heat, and the blanket traps it so it doesn't escape. Heat flows from warm to cool, every single time."

Write in the science journal:

| Word | Meaning |
|------|---------|
| **Heat transfer** | When thermal energy moves from a warmer object to a cooler object |
| **Conductor** | A material that heat moves through easily (like metal) |
| **Insulator** | A material that heat does NOT move through easily (like wood, plastic, or cloth) |

---

### Activity: The Spoon Test (20 min)

**Materials:** Metal spoon, wooden spoon (or plastic spoon), cup of very warm water (tap hot — safe to touch but noticeably warm), timer.

#### Setup

1. Fill a cup with very warm tap water.
2. Place the metal spoon and the wooden spoon in the cup so the handles stick out.
3. Set a timer for 2 minutes.

> **Say this:** "Both spoons are going into the same water at the same time. After 2 minutes, you're going to carefully touch the handle of each spoon — not the part in the water, the part sticking OUT. Tell me which one feels warmer."

#### Data Collection

Have the student draw this in their science journal:

```
SPOON HEAT TRANSFER EXPERIMENT

Prediction: I think the _______ spoon handle will feel warmer because _________.

After 2 minutes:
Metal spoon handle feels: _______________
Wooden spoon handle feels: _______________

Which spoon transferred more heat from the water to the handle? _______________
```

#### Running the Experiment

Start the timer. While waiting:

> **Say this:** "While we wait — think about what's happening inside the cup. The hot water is touching both spoons. The water's energy is trying to transfer to the spoons. But the two spoons are made of different materials. What do you think matters?"

After 2 minutes, have the student carefully touch each handle.

**Expected result:** The metal spoon handle feels warm (or hot). The wooden spoon handle feels barely warm (or room temperature).

> **Say this:** "What did you find?"

*(The metal spoon is warmer.)*

> **Say this:** "The metal let the heat travel all the way from the water, through the spoon, up to the handle. The wood didn't — it blocked most of the heat. In science, we call metal a CONDUCTOR. It conducts heat well — it lets heat pass through. We call wood an INSULATOR. It insulates — it blocks heat from passing through."

> **Say this:** "Think about your house. Why are pot handles often made of wood or plastic? Why are oven mitts made of thick cloth? Because those materials are insulators — they stop heat from reaching your hand. But the pot itself is metal — a conductor — because you WANT heat to reach the food inside."

#### Writing

Have the student write a CER (Claim-Evidence-Reasoning) conclusion:

- **Claim:** One sentence about which material conducts heat better.
- **Evidence:** What they observed (which handle was warmer, which was cooler).
- **Reasoning:** WHY — metal is a conductor, wood is an insulator, heat transfers through conductors more easily.

---

### Discussion (5 min)

> **Ask:** "Where in your daily life do you see conductors and insulators being used on purpose?"

**Listen for:** Pot handles (insulator), oven mitts (insulator), metal pans (conductor), thermos bottles (insulator to keep drinks hot or cold), winter coats (insulator).

> **If student struggles:** "Think about the kitchen. What's the pan made of? What's the handle made of? Why are they different materials?"

---

## Block 3: Coding (30 min) — Scratch: Events & Responses

### Today's Project: Make the Cat React

Last week, the student made the Scratch cat walk and talk. This week, they make it respond to keyboard input — pressing different keys triggers different actions.

### Setup
- Open **scratch.mit.edu** and log in
- Open last week's project (or start a new one)

### Instructions

> **Say this:** "Last week, your program ran when you clicked the green flag. That's ONE kind of event — clicking the flag. But in real programs, things happen based on lots of different events. A game character moves when you press arrow keys. A button does something when you click it. Today, you're going to make the cat respond to different keys."

**Step 1: Arrow Key Movement (10 min)**

1. From **Events** (yellow), drag **"when [space] key pressed"** into the scripting area.
2. Click the dropdown on the block and change "space" to **"right arrow"**.
3. From **Motion** (blue), snap **"change x by 10"** underneath it.
4. Click the right arrow key on your keyboard. The cat should move right.

Now repeat for left:
1. Drag another **"when [left arrow] key pressed"** block.
2. Snap **"change x by -10"** underneath it.

And for up and down:
1. **"when [up arrow] key pressed"** + **"change y by 10"**
2. **"when [down arrow] key pressed"** + **"change y by -10"**

> **Say this:** "Press the arrow keys. You can move the cat anywhere on the stage. You just built a basic character controller — that's the foundation of every video game ever made."

**Step 2: Make the Cat Talk on Space Bar (10 min)**

1. Drag **"when [space] key pressed"** from Events.
2. From **Looks**, snap **"say [Hello!] for 2 secs"** underneath.
3. Change the text to something fun.
4. Press the space bar — the cat talks.

**Challenge:** Can the cat say something DIFFERENT each time? (Hint: From **Operators**, use **"pick random 1 to 3"** inside an **"if/else"** structure. This is advanced — give hints but let them explore.)

**Step 3: Add Sound (5 min)**

1. Click the **Sounds** tab at the top of the screen.
2. Click the speaker icon to browse sounds. Pick one.
3. Go back to **Code**. From the **Sound** category, drag **"play sound [meow] until done"** and add it to the space bar script (after or instead of the "say" block).

> **Say this:** "Now your cat moves with arrow keys, talks when you press space, and makes a sound. Every one of those is an EVENT — something happens, and the program RESPONDS. Events and responses. That's how all interactive programs work."

### Extension
- Add a second sprite (choose any character). Give it its own keyboard controls using different keys (W, A, S, D).
- Make the two sprites interact: when they touch, something happens (use **"if touching [sprite]"** from Sensing).

### Coding Vocabulary Introduced Today
- **Event**: Something that happens — a key press, a click, a timer finishing
- **Response**: What the program does when an event happens
- **x position**: How far left or right the sprite is on the stage
- **y position**: How far up or down the sprite is on the stage

---

## Discussion Lunch

> **"If you could design any video game, what would it be about? What would the player do? What events and responses would you need to program?"**

Follow-ups:
- "What key would make the character jump?"
- "What would happen when the character touches an enemy?"
- "How would you keep score?"

---

## End-of-Week Wrap-Up (5 min)

> **Say this:** "That's Week 2. Done. You compared numbers, you rounded them, you combined both skills. You proved energy transfers through collisions AND through heat. You learned why every city in Michigan is where it is. And you made a Scratch character that responds to your keyboard. That's a serious week of work."

> **Say this:** "Tell me one thing you want to remember from this week."

Listen. Respond to what they say.

> **Say this:** "Next week, we start the real heavy lifting — addition and subtraction with big numbers. The kind of problems that make you feel like a real mathematician. I think you're ready."

---

## Homework

See homework.md for this week's assignments.

---

## Materials Checklist

- [ ] Math journal and pencil
- [ ] Number lines from this week (keep them — you will reuse)
- [ ] Metal spoon and wooden spoon
- [ ] Cup of very warm water (prepare fresh)
- [ ] Timer
- [ ] Science journal
- [ ] Computer or tablet with internet (for Scratch)
- [ ] Scratch account login info

---

*Root Access Learning OS — Week 02 of 36*

© 2026 Root Access Learning OS. All rights reserved.
