# Week 02 — Homework

*All homework reinforces what was learned during the day's lesson — never introduces new concepts. If your student is struggling with an assignment, that is a signal to revisit the topic during the next lesson. Homework should take roughly 30 minutes per night (15 min math + 15 min reading/writing). The weekend project is flexible — 30 minutes total, done whenever it fits your family's schedule.*

---

## Wednesday Homework

### Math Practice (15 min)

**Directions:** Complete these four problems in your math notebook. Show your thinking — circle the place where two numbers differ when comparing.

**1.** Compare: 56,842 _____ 56,824. Use >, <, or =. Circle the place where the numbers first differ.

**2.** Order these numbers from least to greatest: 7,083 — 7,308 — 7,038

**3.** The Henry Ford Museum in Dearborn had 34,256 visitors one month and 34,652 the next month. Which month had more visitors? Explain how you know.

**4.** Using the digits 6, 1, 9, 3, and 0 (each used exactly once), what is the LARGEST 5-digit number you can make? What is the SMALLEST 5-digit number you can make?

---

### Reading/Writing (15 min)

**Journal Prompt:** *Think about the domino experiment from today. Energy transferred from the first domino through the entire chain. Write a paragraph (at least 5 sentences) explaining how energy transferred through the dominoes. Use the words "energy transfer," "collision," and "contact" in your writing.*

This is informative writing — you are explaining a scientific process. Be specific: what happened first, what happened next, and what happened when the gap was there.

---

## Thursday Homework

### Math Practice (15 min)

**Directions:** Complete these four problems. For the first two, draw a quick number line to show where the number sits between the two benchmarks.

**1.** Round 4,762 to the nearest thousand. Draw a number line from 4,000 to 5,000.

**2.** Round 865 to the nearest hundred. Draw a number line from 800 to 900.

**3.** Round 23,547 to:
- The nearest ten: _____
- The nearest hundred: _____
- The nearest thousand: _____

**4.** A news report says "About 40,000 people attended the Michigan State football game." If the actual number rounds to 40,000 when rounded to the nearest thousand, what is the SMALLEST the real attendance could have been? What is the LARGEST?

---

### Reading/Writing (15 min)

**Writing Prompt:** *Choose one Michigan city from today's lesson. Write a short paragraph (4-6 sentences) explaining WHY that city is located where it is. Your paragraph must include:*
- *The city's name and location*
- *At least one geographic feature that influenced the location*
- *A connection to how the Anishinaabe used that same location*
- *The vocabulary word "strategic location" or "natural resources"*

This is informative writing — you are explaining a geography concept to a reader who knows nothing about Michigan.

---

## Friday Homework

### Weekend Project: Energy Transfer Scavenger Hunt (30 min total, flexible)

**The Assignment:** Find and document at least 5 examples of energy transfer happening in your home or neighborhood. For each example, write or draw:

1. **What is transferring energy?** (the source)
2. **What is receiving energy?** (the target)
3. **What type of transfer is it?** (collision, heat, sound — or a type you figure out on your own)
4. **How do you know energy transferred?** (what evidence can you observe?)

**Examples to get started (do NOT use these — find your own):**
- A pot on the stove (heat transfers from burner to pot to food)
- A basketball bouncing on the ground (ball hits ground = collision, energy bounces back)
- A guitar string being plucked (finger transfers energy to string, string vibrates and makes sound)

**Format:** Use a full page in your science journal. Create a table or list. Include at least one drawing for one of your examples — label the energy source, the receiver, and the direction of transfer with arrows.

**Bonus:** Find an example of a CHAIN REACTION (energy transferring through multiple objects in sequence) happening in real life. Describe it.

---

## Answer Keys

### Wednesday Math

**1.** 56,842 **>** 56,824
Both numbers match through the hundreds: 56,8__. The tens differ: **4 > 2**. Circle the tens place.

**2.** Least to greatest: **7,038 < 7,083 < 7,308**
All three have the same thousands digit (7). 7,308 has 3 hundreds, while 7,038 and 7,083 have 0 hundreds. Between 7,038 and 7,083: tens are 3 < 8. So 7,038 is smallest.

**3.** The second month had more visitors: **34,652 > 34,256**. Ten-thousands and thousands are the same (34,___). Hundreds: 6 > 2. The second month's number has 6 hundreds vs. 2 hundreds.

**4.**
- Largest: **96,310** (place digits in descending order: 9, 6, 3, 1, 0)
- Smallest: **10,369** (smallest non-zero digit in ten-thousands: 1, then 0, 3, 6, 9)
*(Common error: student writes 01,369 as the smallest. Remind them: a number cannot start with 0.)*

---

### Thursday Math

**1.** 4,762 rounded to the nearest thousand is **5,000**.
The hundreds digit is 7 (≥ 5), so round up. On the number line, 4,762 is past the midpoint (4,500), so it is closer to 5,000.

**2.** 865 rounded to the nearest hundred is **900**.
The tens digit is 6 (≥ 5), so round up. On the number line, 865 is past 850 (the midpoint), so it is closer to 900.

**3.**
- Nearest ten: **23,550** (ones digit 7 ≥ 5, round up)
- Nearest hundred: **23,500** (tens digit 4 < 5, round down)
- Nearest thousand: **24,000** (hundreds digit 5 = 5, round up)

**4.**
If the actual number rounds to 40,000 when rounded to the nearest thousand, the number must be between **39,500** and **40,499** (inclusive). So the smallest could be **39,500** and the largest could be **40,499**.

*(This requires understanding that rounding to the nearest thousand means the number is within 500 of the rounded value. Advanced for 4th grade — if the student gets close, celebrate the reasoning.)*

---

### Friday Weekend Project — Success Criteria

There is no single right answer. Use these criteria to evaluate:

- [ ] **Quantity:** At least 5 examples of energy transfer identified
- [ ] **Accuracy:** Each example correctly identifies a source, receiver, and type of transfer
- [ ] **Evidence:** Each example explains how you can tell energy transferred (observable change)
- [ ] **Vocabulary:** Uses "energy transfer" and at least one other science term from this week (collision, conductor, insulator, heat transfer, chain reaction)
- [ ] **Drawing:** At least one example includes a labeled drawing with arrows showing the direction of energy transfer
- [ ] **Effort:** The work shows genuine observation and thinking — not just listing obvious examples

**If the student goes above and beyond:** They find a chain reaction, identify a type of energy transfer we have not studied yet (light, electrical), or connect their observations back to the experiments from class. Celebrate that.

**If the student struggles:** Start in the kitchen. Ask: "What is hot in this room? Where is the heat going? Is the stove giving energy to the pot? Is the pot giving energy to the food?" Walk through the house together and point things out until they can spot the pattern independently.

---

*Root Access Learning OS — Week 02 of 36*

© 2026 Root Access Learning OS. All rights reserved.
