# Week 02 — Loading Dependencies

*Building on what you installed last week. The foundations are set — now we layer on the skills that everything else depends on.*

## Week Summary

Week 1 was about booting up: place value, energy basics, and Michigan's physical geography. This week, your student goes deeper on all three fronts. In math, they move from reading and writing numbers to comparing multi-digit numbers with precision and rounding them strategically — two skills that show up constantly in estimation, measurement, and real-world problem solving. In science, they explore what happens when objects collide and where the energy goes. In social studies, they investigate how Michigan's geography shaped where people chose to live — connecting physical features to human decisions across thousands of years. The theme is dependency: every skill this week depends on what was built last week, and everything coming next depends on what happens now.

## Standards Covered This Week

| Subject | Standard Code | Standard Description | Day(s) |
|---------|--------------|----------------------|--------|
| Math | 4.NBT.2 | Read and write multi-digit whole numbers using base-ten numerals, number names, and expanded form; compare two multi-digit numbers using >, =, and < | W, Th, F |
| Math | 4.NBT.3 | Use place value understanding to round multi-digit whole numbers to any place | W, Th, F |
| Science | 4-PS3-2 | Make observations to provide evidence that energy can be transferred from place to place by sound, light, heat, and electric currents | W, F |
| Social Studies | 4-G1.0.2 | Use geographic tools and information to investigate questions about the location of communities and describe how geography has shaped these communities | Th, F |
| ELA | 4.RI.1 | Refer to details and examples in a text when explaining what the text says explicitly and when drawing inferences from the text | Th |
| ELA | 4.RI.3 | Explain events, procedures, ideas, or concepts in a historical, scientific, or technical text | W, Th |
| ELA | 4.W.2 | Write informative/explanatory texts to examine a topic and convey ideas and information clearly | W, Th |
| ELA | 4.W.4 | Produce clear and coherent writing in which the development and organization are appropriate to task, purpose, and audience | W, Th, F |
| ELA | 4.SL.1 | Engage effectively in a range of collaborative discussions, building on others' ideas and expressing their own clearly | W, Th, F |
| ELA | 4.L.1-3 | Demonstrate command of conventions of standard English grammar, usage, capitalization, punctuation, and spelling when writing and speaking | W, Th, F |

## Materials Needed

### Math (all three days)
- [ ] Base-ten blocks (same set from Week 1 — keep them accessible as backup)
- [ ] Number line — draw one on a long strip of paper or tape several sheets end to end. You need number lines for various ranges: 0-100, 0-1,000, and 0-10,000 with major intervals marked. Alternatively, print number line templates (search "open number line template PDF").
- [ ] Dry-erase board or scratch paper
- [ ] Math journal (same notebook from Week 1)
- [ ] Pencil, eraser, and colored pencils (for marking number lines)
- [ ] Sticky notes (at least 10 — for placing numbers on the number line)

### Science (Wednesday and Friday)
- [ ] 2 toy cars (same from Week 1)
- [ ] Dominoes (at least 15) — if you do not have dominoes, use small wooden blocks, playing cards stood on edge, or even a row of thin books standing upright
- [ ] A metal spoon and a wooden spoon (or plastic spoon)
- [ ] A cup of very warm water (tap hot — not boiling)
- [ ] 2 coins of the same size (pennies work great)
- [ ] A rubber ball or bouncy ball
- [ ] Ruler or tape measure
- [ ] Science journal or notebook

### Social Studies (Thursday and Friday)
- [ ] Student's Michigan map from Week 1 (they created this — retrieve it from their folder)
- [ ] A printed or on-screen map showing Michigan's major cities AND physical features together (search "Michigan physical political map")
- [ ] Colored pencils or markers
- [ ] Lined paper for writing

### General
- [ ] Timer or phone with timer
- [ ] Snack for Discussion Lunch
- [ ] Student's folder/binder (continuing organizational habits from Week 1)

## Schedule at a Glance

| | Wednesday | Thursday | Friday |
|---|-----------|----------|--------|
| **Block 1** | Math: Comparing Multi-Digit Numbers | Math: Rounding to Any Place | Math: Comparing + Rounding Combined |
| **Block 2** | Science: Collisions & Energy Transfer | Social Studies: Geography Shapes Communities | Science: Energy Transfer Investigations |
| **Block 3** | — | — | Coding: Scratch — Events & Responses |
| **Notes** | Number lines introduced as a key tool. | Rounding rules built from place value understanding. | Coding block builds on Week 1 Scratch basics. |

## Parent Notes

**This week should feel easier to run than last week.**

The routines are in place now — or at least roughed in. You know where you sit, how you start, what the rhythm feels like. That means you can spend less energy on logistics and more on actual teaching. Here is what to keep in mind:

- **Comparing numbers is NOT just about the > and < symbols.** Your student learned the mechanics last week. This week, the problems get harder — numbers that are closer together, numbers with the same leading digits, numbers where the deciding digit is buried in the tens or ones place. The skill is reading carefully and comparing systematically, left to right. Do not let them eyeball it. Make them show the place where the numbers differ.

- **Rounding is one of the most misunderstood skills in elementary math.** Most kids learn a trick: "5 or above, give it a shove; 4 or below, let it go." That rhyme produces correct answers on worksheets but zero understanding. Your student needs to know WHY we round — to estimate, to simplify, to make quick decisions. And they need to understand rounding as finding the nearest benchmark number on a number line, not just following a rule. Spend time on the number line. It is the single most important tool for rounding.

- **The science this week is about energy transfer — where energy GOES.** Last week, your student saw that faster objects have more energy. This week, they explore what happens to that energy during a collision. It does not disappear — it transfers. The car hits the box; the box moves. The energy went FROM the car TO the box. This is the same principle that makes bowling work, that makes billiards work, that makes a line of dominoes fall. Your student will test this with hands-on experiments using household objects.

- **Social studies connects directly to the map work from last week.** Your student labeled Michigan's physical features. Now they answer the question: so what? Why does geography matter? Because it shaped where every community — Indigenous and modern — chose to live. Water, farmland, forests, minerals — these are not just map features. They are the reasons cities exist where they do.

---

*Root Access Learning OS — Week 02 of 36*

© 2026 Root Access Learning OS. All rights reserved.
