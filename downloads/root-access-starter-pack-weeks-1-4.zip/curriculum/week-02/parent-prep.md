# Week 02 — Parent Prep

Read this before Wednesday. It covers everything you need to know to teach this week confidently. Budget about 20 minutes to read through it and gather materials.

---

## Math Focus: Comparing Numbers & Rounding (4.NBT.2, 4.NBT.3)

### What You're Teaching

Two connected skills this week. First, your student deepens their ability to compare multi-digit numbers — not just "which is bigger" but "how do you know, and at which place value does the difference show up?" Second, they learn to round multi-digit numbers to any place. Both skills are rooted in the place value understanding from Week 1. If your student truly understands that each place is worth ten times more than the one to its right, comparing and rounding will make sense. If that understanding is shaky, these skills will feel like memorized tricks. Watch for that.

### The Progression Across Three Days

- **Wednesday**: Compare multi-digit numbers using a systematic left-to-right strategy. Introduce the number line as a visual tool for seeing where numbers fall relative to each other. Students compare 4-, 5-, and 6-digit numbers with increasingly similar leading digits.
- **Thursday**: Rounding multi-digit numbers to any place (nearest ten, hundred, thousand, ten-thousand). Build understanding through number lines before introducing any rules. The student should be able to explain WHY a number rounds up or down by showing which benchmark it is closer to.
- **Friday**: Combine both skills. Compare rounded estimates, use rounding to check reasonableness, and solve problems that require both comparing and rounding in the same context.

### The Misconception You Need to Watch For

**Rounding**: The most dangerous misconception is "rounding means changing the number." It does not. Rounding means finding the nearest benchmark — the closest "round" number at a given place value. When your student rounds 4,372 to the nearest thousand, they are not changing the number. They are finding the nearest thousand (4,000) and saying "4,372 is closer to 4,000 than to 5,000." The original number still exists. Rounding is a tool for estimation, not a permanent operation.

Another common error: students who round to the nearest hundred look at the tens digit and then change EVERY digit to the right of the hundreds place to zero — but accidentally also change the hundreds digit. For example, rounding 6,749 to the nearest hundred: they look at the 4, decide to round down, and write 6,000 instead of 6,700. They zeroed out too much. Watch for this.

**Comparing**: Students sometimes compare numbers by looking at individual digits without considering place value. They see 8,342 vs. 12,501 and say 8,342 is bigger because "8 is bigger than 1." They are comparing the leading digits without noticing that 12,501 has five digits and 8,342 has four. Always start by checking: do the numbers have the same number of digits?

### If Your Student Is Ahead

Push to rounding larger numbers — round 347,829 to the nearest ten-thousand. Or introduce rounding in context: "About how much would it cost if a tablet is $389 and a case is $47? Round each to the nearest ten, then add." This connects rounding to estimation, which is where it lives in the real world.

### If Your Student Is Behind

Go back to the number line. Draw a line from 0 to 100 with marks at every ten. Place the number 37 on the line. Ask: "Is 37 closer to 30 or 40?" That is rounding. Start with two-digit numbers on a number line. Do not move to three- or four-digit rounding until the student can round two-digit numbers by pointing to their position on the line. The visual must come first.

---

## Science Focus: Collisions and Energy Transfer (4-PS3-2)

### What You're Teaching

Last week, your student learned that faster objects have more energy. This week, they learn what happens to that energy when objects interact. The core idea: energy does not disappear. It transfers from one object to another. When a moving car hits a stationary box, the car slows down (loses energy) and the box moves (gains energy). The energy was transferred through the collision.

### Background You Need

You do not need to teach the law of conservation of energy in formal terms. But you should know the basic principle: energy is never created or destroyed — it just moves from place to place and changes form. At the 4th-grade level, the focus is on transfer through collisions (mechanical contact) and observable evidence that the transfer happened.

Key ideas for this week:

- **Energy transfer** means energy moves from one object to another. The first object has less energy after the transfer; the second object has more.
- **Collisions** are the primary mechanism this week. When objects hit each other, energy transfers through contact.
- **Evidence of transfer**: the receiving object moves, makes a sound, gets warmer, or changes in some observable way. If something happened to the second object, energy was transferred.
- **Chain reactions** (like dominoes) show energy transferring through a series of objects, one after another.

### The Domino Experiment

On Wednesday, your student will set up a line of dominoes and observe how energy transfers from one to the next in a chain. This is simple to set up but rich in observation. The first domino falls and hits the second, transferring its energy. The second hits the third. The energy moves down the line. If you remove one domino from the middle, the chain stops — because there is nothing to transfer energy to. That gap is powerful evidence that the energy must transfer through contact.

### Key Vocabulary

| Term | Student-Friendly Definition |
|------|---------------------------|
| **Energy transfer** | When energy moves from one object to another |
| **Collision** | When two objects hit each other |
| **Chain reaction** | When one event causes the next, which causes the next, in a series |
| **Contact** | When objects are touching — energy transfers through contact in a collision |

---

## Social Studies Focus: Geography Shapes Communities (4-G1.0.2)

### What You're Teaching

Last week, your student learned Michigan's physical geography — the shapes, the water, the landforms. This week, they answer the deeper question: how did that geography influence WHERE people built communities? Why is Detroit on the river? Why is Marquette in the Upper Peninsula? Why did the Anishinaabe build villages where they did? Geography is not just backdrop — it is the reason.

### Background You Need

Every major Michigan community — Indigenous and modern — was founded in a location that made geographic sense:

- **Detroit** (Waawiyaatanong): Built at the narrowest point of the river connecting Lake Erie and Lake Huron. Controlling that strait meant controlling trade. The Anishinaabe, the French, and the British all recognized this. It was strategic before it was a city.
- **Sault Ste. Marie** (Baawitigong — "place of the rapids"): The rapids between Lake Superior and Lake Huron were the best fishing site in the entire Great Lakes region. The Ojibwe fished there for thousands of years before Europeans arrived. The city exists because of those rapids.
- **Grand Rapids**: Named for the rapids on the Grand River. The rapids provided water power for mills and industry. Before that, the Odawa and other nations used the river as a travel corridor.
- **Marquette**: Founded because of iron ore deposits in the Upper Peninsula. The Ojibwe knew about the iron and copper in the region long before mining companies arrived.
- **Traverse City**: Situated at the base of Grand Traverse Bay, a protected harbor on Lake Michigan. The bay provided shelter, fish, and a launching point for travel across the lake.

The pattern is consistent: water access, natural resources, and strategic position. This was true for Indigenous communities thousands of years ago, and it remained true for every settlement that followed.

### Key Vocabulary

| Term | Student-Friendly Definition |
|------|---------------------------|
| **Community** | A group of people living in the same area |
| **Settlement** | A place where people choose to build homes and live |
| **Natural resources** | Things found in nature that people use — water, wood, minerals, soil, fish |
| **Strategic location** | A place that gives advantages for trade, travel, defense, or survival |
| **Trade route** | A path regularly used for buying, selling, or exchanging goods |

---

## ELA Integration Points

### Reading (4.RI.1, 4.RI.3)
- **Thursday, Social Studies**: Your student will analyze the relationship between geography and community location. They will refer to specific evidence (map features, geographic facts) to support their claims. This covers 4.RI.1. When they explain WHY geography shaped settlement patterns, they are explaining concepts in an informational context — 4.RI.3.

### Writing (4.W.2, 4.W.4)
- **Wednesday, Science**: After the domino experiment, your student writes observations explaining how energy transferred through the chain. This is informative writing (4.W.2) grounded in their own experimental evidence.
- **Thursday, Social Studies**: Your student writes a short explanatory paragraph connecting a city's location to its geographic advantages. This is 4.W.2 with domain-specific vocabulary.

### Speaking and Listening (4.SL.1)
- **Every day**: Discussions during lessons and at lunch. Push for explanations, not just answers. "Why do you think that?" should be your most-used phrase this week.

### Language Conventions (4.L.1-3)
- **Every day, in all writing**: Continue holding the standard from Week 1. Complete sentences, correct spelling, proper punctuation. When errors appear, fix them in the moment. "Let's make that sentence stronger" is better than "That's wrong."

---

## Materials Checklist

Gather everything below before Wednesday morning.

### Must Have
- [ ] **Base-ten blocks** — nearby as backup for students who need concrete support
- [ ] **Number lines** — draw or print these. You need at least: one line 0-100 (marked by tens), one line 0-1,000 (marked by hundreds), one line 0-10,000 (marked by thousands). A long strip of paper and a marker works perfectly. These will be reused.
- [ ] **Sticky notes** — small ones, at least 10. Students will write numbers on them and place them on the number line.
- [ ] **Math journal** — continuing from Week 1
- [ ] **Dominoes** (15+) — or substitute: wooden blocks that can stand upright, playing cards stood on edge, or small thin books. Anything that can be lined up and knocked over in a chain.
- [ ] **Metal spoon and wooden/plastic spoon** — for the heat transfer comparison
- [ ] **Cup of very warm water** — tap hot, not boiling. You will prepare this fresh during the science lesson.
- [ ] **2 pennies or same-size coins** — for the coin collision demonstration
- [ ] **Student's Michigan map from Week 1** — retrieve from their folder
- [ ] **Michigan physical/political map** — printed or on screen, showing cities AND physical features
- [ ] **Colored pencils** — for map annotation
- [ ] **Pencils, eraser, sharpener** — at the workspace

### Nice to Have
- [ ] **Whiteboard and markers** — for quick demonstrations
- [ ] **Rubber ball or bouncy ball** — for the energy transfer demonstration
- [ ] **Printed number line templates** — faster than hand-drawing, search "blank number line to 1000 PDF"

---

## Your Mindset This Week

Last week was about survival. This week is about settling in.

If Week 1 felt chaotic, that is normal. It was Day One of everything. This week, the routines should start to click. Your student knows where their materials are. They know the flow: morning work, math, break, second subject, lunch discussion. Lean into that rhythm.

The content this week is a step up from Week 1, but it builds directly on what your student already knows. Comparing numbers uses place value. Rounding uses place value. Energy transfer uses what they learned about kinetic energy. Geography and community location uses the map they already built. Everything connects. If your student says "Oh, this is like what we did last week," that means the curriculum is working.

One more thing: if rounding does not click on Thursday, do not panic. Rounding is one of those skills that some students grasp instantly and others need to see from three different angles. The number line approach works for most kids, but if your student needs more time, take it. Friday is designed to reinforce both comparing and rounding, and homework provides additional practice. You have room.

---

*Root Access Learning OS — Week 02 of 36*

© 2026 Root Access Learning OS. All rights reserved.
