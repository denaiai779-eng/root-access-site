# Week 2 — Thursday

## Loading Dependencies: Day 2

**Grade:** 4 | **Standards:** 4.NBT.2, 4.NBT.3, 4-G1.0.2, 4.RI.1, 4.RI.3, 4.W.2, 4.SL.1
**Theme:** Loading Dependencies — layering skills on top of Week 1 foundations
**Math Mode:** Pictorial to Abstract — Number lines for rounding

---

## Materials Checklist

Gather these before you start. Everything on this list is used today.

- [ ] Math journal and pencil
- [ ] Number line: 0 to 100 (marks at every 10)
- [ ] Number line: 0 to 1,000 (marks at every 100)
- [ ] Number line: 0 to 10,000 (marks at every 1,000) — draw this on a long strip of paper
- [ ] Sticky notes (at least 8)
- [ ] Colored pencils (2 colors)
- [ ] Dry-erase board or scratch paper
- [ ] Student's Michigan map from Week 1
- [ ] Michigan physical/political map (printed or on screen — showing cities AND features)
- [ ] Lined paper for social studies writing
- [ ] Timer or phone with timer
- [ ] Snack for Discussion Lunch

---

## Morning Work (15 min)

**Start time:** _____ **End time:** _____

> **Say this:** "Three quick review problems, then a journal entry. Let's go."

### Quick Math Review (8 min)

**1.** Compare: 67,203 _____ 67,230. Use >, <, or =.

**2.** Order from greatest to least: 5,482 — 15,003 — 9,871

**3.** The population of Kalamazoo is about 72,786. The population of Battle Creek is about 51,247. Which city has more people? How do you know?

#### Morning Review Answers

| # | Answer | Notes |
|---|--------|-------|
| 1 | 67,203 < 67,230 | Same through hundreds. Tens: 0 < 3. |
| 2 | 15,003 > 9,871 > 5,482 | 15,003 has 5 digits (greatest). Between the 4-digit numbers: 9 > 5 in the thousands place. |
| 3 | Kalamazoo (72,786 > 51,247). Ten-thousands: 7 > 5. |

### Journal Prompt (7 min)

> **Say this:** "Write at least three sentences."

**Prompt:** *"If you could live anywhere in the world, where would you pick? Don't just name the place — explain WHY. What is it about that place — the water, the mountains, the weather, the people — that makes you want to live there? What does that place give you that you need?"*

This connects to today's social studies lesson: geography shapes where people choose to live.

---

## Block 1: Math (60 min) — Rounding Multi-Digit Numbers

**Standards:** 4.NBT.3, 4.NBT.2
**Approach:** Singapore Math — Pictorial (number line) to Abstract (rounding procedure)

---

### Launch (10 min)

**Setup:** Lay the 0-to-100 number line on the table. Have sticky notes ready.

> **Say this:** "Yesterday we put numbers on number lines to compare them. Today we're going to use number lines for something new: rounding. Here's the idea."

Write **37** on a sticky note. Place it on the number line.

> **Say this:** "There's 37, sitting between 30 and 40. Here's my question: is 37 closer to 30 or closer to 40?"

Let them look at the number line. They should see it is closer to 40.

> **Say this:** "37 is only 3 away from 40, but it's 7 away from 30. So 37 is closer to 40. If I asked you to ROUND 37 to the nearest ten, the answer is 40. Rounding just means: find the nearest round number."

Write **63** on another sticky note. Place it on the line.

> **Say this:** "What about 63? Is it closer to 60 or 70?"

*(Closer to 60 — it is 3 away from 60 but 7 away from 70.)*

> **Say this:** "So 63 rounded to the nearest ten is 60. You're not changing the number. You're finding the nearest benchmark — the nearest ten."

Now write **45** on a sticky note. Place it on the line.

> **Say this:** "Okay, tricky one. 45 is right in the middle between 40 and 50. It's exactly 5 away from both. So which way do we round?"

*(Let them guess.)*

> **Say this:** "Here's the convention — the rule mathematicians agreed on: when a number is exactly in the middle, we round UP. So 45 rounds to 50. It's a tie-breaker rule, that's all. The number 5 always rounds up."

> **Say this:** "That's what rounding IS. Find the two benchmarks the number sits between, figure out which one it's closer to, and go there. If it's exactly in the middle, round up. That's the whole thing."

---

### Guided Practice (20 min)

Work these three problems TOGETHER. Use number lines for the first two, then transition to the abstract procedure.

---

#### Problem 1: Rounding to the Nearest Hundred

> **Say this:** "The Sleeping Bear Dunes in Michigan are about 450 feet tall. If someone asked you 'about how tall are the dunes — to the nearest hundred feet?' what would you say?"

**Step 1 — Draw a mini number line.**

Draw a number line from 400 to 500, with a mark at 450 in the middle.

```
400 -------- 450 -------- 500
```

**Step 2 — Place the number.**

> **Say this:** "450 is right in the middle between 400 and 500. It's exactly 50 away from both. What's our rule for ties?"

*(Round up.)*

**Step 3 — State the answer.**

**Answer:** 450 rounded to the nearest hundred is **500**.

> **Say this:** "So you'd say the dunes are about 500 feet tall. That's an estimate — close enough to be useful, simple enough to remember."

---

#### Problem 2: Rounding to the Nearest Thousand

> **Say this:** "The Mackinac Bridge is 26,372 feet long. If you rounded that to the nearest thousand, what would you get?"

**Step 1 — Identify the two benchmarks.**

> **Say this:** "What two thousands is 26,372 between? It's between 26,000 and 27,000."

Draw a number line:

```
26,000 -------- 26,500 -------- 27,000
```

**Step 2 — Place the number.**

> **Say this:** "Where does 26,372 fall? Is it before or after 26,500?"

*(Before — 26,372 < 26,500.)*

> **Say this:** "So it's closer to 26,000 than to 27,000. It's in the first half."

**Step 3 — State the answer.**

**Answer:** 26,372 rounded to the nearest thousand is **26,000**.

> **Say this:** "Here's the shortcut that the number line just proved. To round to the nearest thousand, look at the HUNDREDS digit. It's the digit to the RIGHT of the place you're rounding to. In 26,372, the hundreds digit is 3. Is 3 less than 5, equal to 5, or greater than 5?"

*(Less than 5.)*

> **Say this:** "Less than 5, so the number rounds DOWN. The thousands digit stays at 6, and everything to the right becomes zeros. 26,000. But notice — we didn't memorize that rule first. We SAW it on the number line, and the rule just describes what we already understood."

---

#### Problem 3: Rounding to the Nearest Ten-Thousand (Abstract)

> **Say this:** "Michigan's population in a recent year was about 73,650. Round that to the nearest ten-thousand."

**Step 1 — Identify the benchmarks.**

> **Say this:** "What two ten-thousands is 73,650 between?"

*(70,000 and 80,000.)*

**Step 2 — Look at the digit to the right of the rounding place.**

> **Say this:** "The ten-thousands digit is 7. The digit to the right — the thousands digit — is 3. Is 3 less than 5?"

*(Yes.)*

**Step 3 — Round.**

**Answer:** 73,650 rounded to the nearest ten-thousand is **70,000**.

> **Say this:** "Here's the procedure, now that you understand WHY it works:
> 1. Find the place you're rounding to.
> 2. Look at the digit ONE PLACE to the right.
> 3. If that digit is 0, 1, 2, 3, or 4 — round DOWN (keep the rounding digit the same).
> 4. If that digit is 5, 6, 7, 8, or 9 — round UP (increase the rounding digit by 1).
> 5. Replace everything to the right with zeros."

---

### Independent Practice (20 min)

> **Say this:** "Your turn. Five problems. For the first two, I want you to draw a quick number line showing the benchmarks. For the rest, you can use the procedure — but if you get stuck, draw the number line."

---

**Problem 1** (Easy — round to nearest ten)

Round 83 to the nearest ten. Draw a number line from 80 to 90 to show your answer.

---

**Problem 2** (Easy — round to nearest hundred)

The distance from Lansing to Grand Rapids is about 67 miles. Round 67 to the nearest ten. Then: the distance from Detroit to Chicago is about 283 miles. Round 283 to the nearest hundred.

---

**Problem 3** (Medium — round to nearest thousand)

Round 14,682 to the nearest thousand.

---

**Problem 4** (Medium — round to different places)

The number is **45,837**. Round it to:
- The nearest ten: _____
- The nearest hundred: _____
- The nearest thousand: _____

---

**Problem 5** (Hard — apply rounding in context)

A school fundraiser earned $8,463. The principal told the local newspaper "We raised about $8,000." Was the principal rounding to the nearest hundred, the nearest thousand, or the nearest ten-thousand? Explain how you know. Is there a more precise way the principal could have rounded the number?

---

### Answer Key

**Problem 1:**
83 rounded to the nearest ten is **80**. On the number line, 83 is between 80 and 90. The ones digit is 3, which is less than 5, so round down.

**Problem 2:**
67 rounded to the nearest ten is **70** (ones digit is 7, which is ≥ 5, round up). 283 rounded to the nearest hundred is **300** (tens digit is 8, which is ≥ 5, round up).

**Problem 3:**
14,682 rounded to the nearest thousand is **15,000**. The hundreds digit is 6, which is ≥ 5, so the thousands digit rounds up from 4 to 5.

**Problem 4:**
- Nearest ten: **45,840** (ones digit 7 ≥ 5, round up)
- Nearest hundred: **45,800** (tens digit 3 < 5, round down)
- Nearest thousand: **46,000** (hundreds digit 8 ≥ 5, round up)

**Problem 5:**
The principal rounded to the **nearest thousand**. We know because $8,463 rounded to the nearest thousand gives $8,000 (hundreds digit 4 < 5, round down). A more precise estimate would be rounding to the nearest hundred: **$8,500** (tens digit 6 ≥ 5, round up). Accept either "nearest hundred" or "nearest ten" as a more precise alternative, as long as the student explains the reasoning.

---

### Beast Academy Challenge (10 min)

> **Say this:** "Here's a puzzle that uses rounding in reverse. Instead of rounding a number, you have to figure out what the original number COULD have been."

**The Puzzle:**

A mystery number was rounded to the nearest hundred and the result was **4,300**. The mystery number is odd. The sum of its digits is 15. What is the mystery number?

**Solution:**

Step 1: If the number rounds to 4,300 (nearest hundred), it must be between 4,250 and 4,349.

Step 2: The number is odd, so the ones digit is 1, 3, 5, 7, or 9.

Step 3: The digits must sum to 15. The number is 4,_ _ _. The first digit is 4. So the remaining three digits must sum to 15 - 4 = 11. The hundreds digit must be 2 or 3 (to stay in the range 4,250-4,349).

If hundreds digit = 2: tens + ones = 11 - 2 = 9. Need an odd ones digit between 0-9 and tens digit between 5-9 (since the number must be ≥ 4,250).
- Tens = 5, ones = 4 — but 4 is even. No.
- Tens = 6, ones = 3 — 4,263. Odd. Digits sum: 4+2+6+3 = 15. In range (4,250 to 4,349). **Yes!**
- Tens = 7, ones = 2 — even. No.
- Tens = 8, ones = 1 — 4,281. Digits sum: 4+2+8+1 = 15. In range. Odd. **Yes!**

If hundreds digit = 3: tens + ones = 11 - 3 = 8. Tens can be 0-4 (to stay ≤ 4,349), ones must be odd.
- Tens = 1, ones = 7 — 4,317. Digits sum: 4+3+1+7 = 15. In range. Odd. **Yes!**
- Tens = 3, ones = 5 — 4,335. Digits sum: 4+3+3+5 = 15. In range. Odd. **Yes!**

**Valid answers: 4,263, 4,281, 4,317, or 4,335.** Accept any one with correct reasoning.

> **Say this (if they find one):** "Great work. But there's actually more than one answer. Can you find another?"

---

### Bug Check

#### Error 404: Student does not understand what rounding means.
Go back to the 0-100 number line with marks at every ten. Point to 37. Say: "Is 37 closer to 30 or 40? Count the spaces." Have them physically count: 37 to 40 is 3, 37 to 30 is 7. So 37 is closer to 40. Round 37 to the nearest ten = 40. Repeat with 62, 84, 15, 48. Do not introduce the "look at the digit" rule until they can explain rounding using the number line.

#### Error 500: Student applies the rounding rule to the wrong digit.
Common error: asked to round to the nearest thousand, the student looks at the ones digit instead of the hundreds digit. Teach this explicitly: "The digit you LOOK AT is always one place to the RIGHT of the place you're rounding to. Rounding to the nearest hundred? Look at the tens. Rounding to the nearest thousand? Look at the hundreds." Write the number, underline the rounding digit, and circle the "decision digit" next to it. Practice with three examples.

#### Syntax Error: Student rounds correctly but writes the answer wrong — fails to zero out digits to the right.
Example: rounds 3,672 to the nearest hundred and writes 3,700 but then leaves the tens and ones as 72, writing 3,772. This is a notation error. Say: "After you round, every digit to the RIGHT of the rounding place becomes a zero. That's what makes it a round number." Practice converting: 3,672 → nearest hundred → 3,700 (not 3,772).

---

## Block 2: Social Studies (45 min) — Geography Shapes Communities

**Standards:** 4-G1.0.2, 4.RI.1, 4.RI.3, 4.W.2, 4.SL.1

---

### Hook (5 min)

Pull out the student's Michigan map from Week 1 and the physical/political reference map.

> **Say this:** "Last week, you made this map. You labeled the Great Lakes, the peninsulas, rivers, forests, dunes. You know the LAND. But here's the question I want you to think about today: WHY do cities exist where they do? Why is Detroit in that corner? Why is Marquette way up in the U.P.? Why didn't people just build cities in random spots?"

Pause. Let them think.

> **Say this:** "The answer is geography. People — all people, for thousands of years — have chosen where to live based on what the land offers them. Water to drink and fish from. Flat land to grow food. Forests for building. Rivers for travel. The Anishinaabe knew this. The French and British who came later knew this. And modern cities are STILL in those same spots. Geography comes first. Everything else follows."

---

### Lesson (15 min)

Read this aloud to your student. Pause at the **[PAUSE]** marks.

> **Say this:** "Let's look at five Michigan cities and figure out WHY each one is where it is. For each one, we're going to name the geographic advantage — the thing about that location that made people say, 'This is a good place to live.'"

**City 1: Detroit (Waawiyaatanong)**

> **Say this:** "Detroit sits right where the Detroit River connects Lake Erie and Lake St. Clair. The Anishinaabe called this place Waawiyaatanong — 'where the water goes around.' It was the narrowest crossing point on the waterway between two Great Lakes. If you controlled that spot, you controlled trade. The Anishinaabe used it as a crossing and trading point for generations. Later, the French built Fort Pontchartrain there in 1701 for the exact same reason — it was strategic. Detroit exists because of that river."

**[PAUSE]**

> **Ask:** "What was the geographic advantage of Detroit's location?"

*(Water access, narrow river crossing, trade route control.)*

**City 2: Sault Ste. Marie (Baawitigong)**

> **Say this:** "Sault Ste. Marie is the oldest city in Michigan, and it's way up at the eastern tip of the Upper Peninsula. The Ojibwe called it Baawitigong — 'at the rapids.' The St. Marys River drops about 20 feet between Lake Superior and Lake Huron, creating rapids. Those rapids were one of the best fishing spots in all of North America. The Ojibwe harvested whitefish there for thousands of years. It wasn't just food — it was a gathering place where nations came together to fish, trade, and hold councils. The city exists because of the rapids."

**[PAUSE]**

**City 3: Grand Rapids**

> **Say this:** "Grand Rapids is named after the rapids on the Grand River. The Odawa used the river as a travel highway — birch bark canoes carrying people and goods through the Lower Peninsula. The rapids marked an important stop on that route. Later, European settlers used the rapids for water power to run sawmills and furniture factories. The city became the 'Furniture Capital of the World.' Same geographic feature, different uses — but the river is the reason the city is there."

**[PAUSE]**

**City 4: Marquette**

> **Say this:** "Marquette is on the shore of Lake Superior in the Upper Peninsula. Why would people build a city in such a remote, cold, heavily forested place? Minerals. The area around Marquette has massive deposits of iron ore. The Ojibwe had long known about the iron and copper in the region. In the 1840s, mining companies began extracting iron ore and shipping it out through Marquette's harbor on Lake Superior. The city exists because of what's in the ground beneath it AND the lake access to ship it out."

**[PAUSE]**

**City 5: Traverse City**

> **Say this:** "Traverse City sits at the base of Grand Traverse Bay, a deep, protected inlet on Lake Michigan. Protected harbors are valuable — they give shelter from storms, a safe place for boats, and access to open water for fishing and travel. The Odawa and other Anishinaabe peoples used the bay for exactly these purposes. Later, the area became known for cherry orchards — the lake moderates the temperature and prevents late frosts that would kill cherry blossoms. Same geography, multiple advantages."

---

### Activity (20 min)

> **Say this:** "Now you're going to be a geographer. Pick THREE cities from the lesson — or pick three cities on your Michigan map — and do the following for each one."

**For each city, the student writes:**

1. **City name** (and Indigenous name if known)
2. **Location** — where on the map is it? Near what body of water? In which peninsula?
3. **Geographic advantage** — WHY is it there? What does the geography offer? (water, resources, trade routes, farmland, harbors, etc.)
4. **One sentence connecting geography to community** — "______ is located at ______ because ______."

**Example (do this one together first):**

- **City:** Detroit (Waawiyaatanong)
- **Location:** Southeast corner of Lower Peninsula, on the Detroit River between Lake Erie and Lake St. Clair
- **Geographic advantage:** Narrow river crossing = control of trade; water access to two Great Lakes
- **Connection sentence:** "Detroit is located on the Detroit River because controlling the narrow crossing point gave access to trade routes through the Great Lakes."

The student then does two more cities independently.

**Materials:** Michigan map, lined paper, colored pencils for marking cities on the map.

---

### Historical Context — A Note for the Parent

When discussing why cities are where they are, center the understanding that Indigenous peoples were the FIRST to identify these strategic locations. The Anishinaabe did not stumble onto good locations — they studied and selected them through millennia of geographic knowledge. European settlements were frequently built in the exact same spots, often because Indigenous peoples told them about them, traded with them there, or were forcibly removed from them.

This is not a narrative of "empty land waiting to be settled." Every location had significance and often permanent or seasonal communities long before European contact. When your student writes about why a city exists, encourage them to note BOTH the Indigenous use and the later use — showing continuity, not replacement.

The Ojibwe, Odawa, and Potawatomi nations maintain active tribal communities in Michigan today. The Little Traverse Bay Bands of Odawa Indians are in the Traverse City / Petoskey area. The Sault Ste. Marie Tribe of Chippewa Indians governs in the eastern U.P. These are living communities, not historical artifacts.

---

### Discussion (5 min)

> **Ask:** "Look at your map. Is there any major Michigan city that is NOT near water? What does that tell you about what people need?"

**Listen for:** The observation that almost every major Michigan city is on a river, lake, or bay. Water is the common factor — it provides drinking water, transportation, fishing, trade routes, and later, industrial power.

> **If student struggles, say:** "Point to any city on the map. Now look — is there water nearby? A river? A lake? Try another city. See the pattern?"

> **Follow-up:** "The Anishinaabe figured this out thousands of years ago. Every major camp, village, and gathering place was near water. Modern cities are in those same spots. Geography doesn't change, and what people need from it hasn't changed either."

---

## Discussion Lunch

No lesson. Just a conversation over food.

> **Ask over lunch:** "If you were starting a brand-new city from scratch — no roads, no buildings, nothing — where in Michigan would you put it, and why? Think about what your city would need: water, food, transportation, safety from weather."

Let it be a real discussion. Push for specifics: "Why THAT lake? What would you grow? How would people get there?" Share your own answer too.

---

## End-of-Day Check

Before you close out Thursday, quickly verify:

- [ ] **Math:** Student can round a 4- or 5-digit number to the nearest ten, hundred, or thousand
- [ ] **Math:** Student can explain WHY a number rounds up or down (not just recite the rule)
- [ ] **Math:** Student can draw a number line showing benchmarks for rounding
- [ ] **Social Studies:** Student can name at least 3 Michigan cities and their geographic advantages
- [ ] **Social Studies:** Student understands that Indigenous peoples identified strategic locations first
- [ ] **Writing:** Student completed the city analysis activity with clear connection sentences

If any boxes are unchecked, note them. Friday's lesson reinforces both rounding and comparing.

---

## Friday Preview

Tomorrow is **Loading Dependencies Day 3**. In math, we combine comparing and rounding — using estimation to check answers and solve real-world problems. In science, we investigate more ways energy transfers: through heat and sound, not just collisions. The coding block builds on last week's Scratch introduction with event-based programming.

---

*Root Access Learning OS — Week 02, Thursday*
*Loading Dependencies: Day 2*

---

© 2026 Root Access Learning OS. All rights reserved.
