# Week 2 — Wednesday

## Loading Dependencies: Day 1

**Grade:** 4 | **Standards:** 4.NBT.2, 4.NBT.3, 4-PS3-2, 4.RI.3, 4.W.2, 4.SL.1
**Total instructional time:** ~2 hours 15 minutes (with breaks built in)

---

## Materials Checklist

Gather everything before the day starts.

### Math
- [ ] Math journal and pencil
- [ ] Number line (hand-drawn or printed — 0 to 1,000 with marks at every hundred)
- [ ] A second number line: 0 to 100 with marks at every ten
- [ ] Sticky notes (at least 6)
- [ ] Dry-erase board or scratch paper
- [ ] Base-ten blocks (nearby as backup)

### Science
- [ ] Dominoes (at least 15) or substitute: wooden blocks, playing cards stood on edge
- [ ] 2 pennies or same-size coins
- [ ] A flat, hard surface (table or smooth floor)
- [ ] Ruler or tape measure
- [ ] Science journal or notebook
- [ ] Pencil and colored pencils

### General
- [ ] Timer or phone with timer
- [ ] Snack for Discussion Lunch

---

## Morning Work (15 min)

Set out the journal, a pencil, and the number line from 0 to 100. No screens.

> **Say this:** "Quick warm-up to get your brain going. Three review problems from last week, then a short journal."

### Quick Math Review (8 min)

Write these on a whiteboard or paper:

**1.** What is the value of the 6 in 56,241?

**2.** Write 8,035 in expanded form.

**3.** Compare: 45,872 _____ 45,827. Fill in >, <, or =.

#### Morning Review Answers

| # | Answer | Notes |
|---|--------|-------|
| 1 | 6,000 (six thousand) | The 6 is in the thousands place. |
| 2 | 8,000 + 0 + 30 + 5 (or 8,000 + 30 + 5) | Accept either form for the zero. |
| 3 | 45,872 > 45,827 | Same ten-thousands (4), same thousands (5), same hundreds (8). Tens differ: 7 > 2. |

### Journal Prompt (7 min)

> **Say this:** "Write at least three sentences. Think carefully."

**Prompt:** *"When you estimate something — like guessing how many people are in a room, or about how much something costs — you don't need an exact number. You just need a close-enough number. Write about a time you estimated something. How close were you? When is a close-enough answer actually better than an exact answer?"*

---

## Block 1: Math (60 min) — Comparing Multi-Digit Numbers

**Standards:** 4.NBT.2, 4.NBT.3
**Approach:** Singapore Math — Pictorial to Abstract. Number lines as the primary visual tool today.

---

### Launch (10 min)

**Setup:** Lay the 0-to-1,000 number line on the table. Have sticky notes and a marker ready.

> **Say this:** "Last week, you learned how to compare numbers using place value — start from the left, find the first digit that's different, and that tells you which number is bigger. You're good at that. But today, I want you to SEE it. I want you to see WHERE numbers live — are they closer to the beginning, the middle, the end? And once you can see that, comparing gets even easier."

Write the number **372** on a sticky note. Hand it to the student.

> **Say this:** "Put this on the number line. Where does 372 live? Find the right spot."

Let them think. They should place it between 300 and 400, closer to 400.

> **Say this:** "Good. Now tell me — is 372 closer to 300 or 400?"

*(Closer to 400.)*

> **Say this:** "Right. 372 is only 28 away from 400, but it's 72 away from 300. It's closer to 400. That's going to matter a lot this week. But first, let's use the number line to compare."

Write **372** on one sticky note and **419** on another.

> **Say this:** "Place both on the number line. Which one is further to the right?"

*(419 is further right.)*

> **Say this:** "On a number line, further right ALWAYS means bigger. 419 is to the right of 372, so 419 > 372. You already knew that from comparing digits — 4 hundreds beats 3 hundreds. But the number line lets you SEE the distance between them. They're not just 'different' — you can see HOW different."

---

### Guided Practice (20 min)

Work these three problems TOGETHER. Use the number line for the first two, then move to abstract comparison for the third.

---

#### Problem 1: Close Numbers on the Number Line

> **Say this:** "Here's a real situation. Your family is driving from Detroit to Mackinac City. The GPS says the distance is 282 miles going through the middle of the state, or 291 miles going along the coast. Which route is shorter?"

**Step 1 — Place both on the 0-to-1,000 number line.**
Both fall between 200 and 300. Place sticky notes at approximately 282 and 291.

**Step 2 — Compare visually.**

> **Say this:** "They're really close together. Both are between 200 and 300. So the hundreds are the same — 2 hundreds in both. How do we decide? Move to the tens. 282 has 8 tens. 291 has 9 tens. 8 < 9, so 282 is smaller."

**Step 3 — Write it.**

**Answer:** 282 < 291, so the route through the middle of the state is shorter.

> **Say this:** "Notice — when numbers have the same leading digits, you have to look deeper. Don't rush. Go place by place."

---

#### Problem 2: Different Number of Digits

> **Say this:** "Lake Michigan has a surface area of about 22,404 square miles. Lake Erie has a surface area of about 9,910 square miles. Which lake is bigger?"

**Step 1 — Count the digits.**

> **Say this:** "Before we even compare digit by digit, look at the numbers. 22,404 has five digits. 9,910 has four digits. A five-digit number is ALWAYS greater than a four-digit number. Always. Why?"

*(Because the smallest five-digit number is 10,000, and the biggest four-digit number is 9,999. 10,000 > 9,999.)*

**Step 2 — Write it.**

**Answer:** 22,404 > 9,910. Lake Michigan is bigger.

> **Say this:** "Quick rule: if two numbers have different amounts of digits, the one with more digits is bigger. You don't need to compare anything else."

---

#### Problem 3: Abstract Comparison — Close and Tricky

> **Say this:** "The attendance at a Michigan State football game one week was 74,863. The next week it was 74,836. Which game had more people?"

**Step 1 — Line up the digits.**

Write them stacked:
```
74,863
74,836
```

**Step 2 — Compare left to right.**

> **Say this:** "Ten-thousands: 7 = 7. Same. Thousands: 4 = 4. Same. Hundreds: 8 = 8. Same. Tens: 6 vs. 3. Stop. 6 > 3."

**Answer:** 74,863 > 74,836. The first game had more attendance.

> **Say this:** "The difference was in the tens place. Everything to the left was identical. You had to get all the way to the tens before you found the difference. That's why you NEVER stop early."

---

### Independent Practice (20 min)

> **Say this:** "Your turn. Five problems. For the first two, sketch a quick number line to place the numbers. For the rest, just compare using place value. Show your work — circle the digit where the numbers differ."

---

**Problem 1** (Easy — visual comparison)

The Grand River is 252 miles long. The Muskegon River is 227 miles long. Which river is longer? Place both numbers on a number line from 200 to 300 and explain.

---

**Problem 2** (Easy — different digit counts)

Compare: 8,457 _____ 12,306. Use >, <, or =.

---

**Problem 3** (Medium — same leading digits)

Compare: 35,192 _____ 35,187. Circle the place where the numbers first differ.

---

**Problem 4** (Medium — three-way comparison)

Order these Michigan city populations from least to greatest:
- Holland: 33,051
- Midland: 41,863
- Traverse City: 15,678

---

**Problem 5** (Hard — multi-step)

Two schools held fundraisers. Lincoln Elementary raised $12,847. Washington Elementary raised a total where the ten-thousands digit is the same as Lincoln's, the thousands digit is 3, the hundreds digit is the same as Lincoln's, and the remaining digits are 19. How much did Washington raise? Which school raised more?

---

### Answer Key

**Problem 1:**
252 > 227. The Grand River is longer. On the number line, 252 sits to the right of 227. Comparing digits: hundreds are both 2, tens: 5 > 2.

**Problem 2:**
8,457 **<** 12,306. 12,306 has five digits; 8,457 has four. The five-digit number is always greater.

**Problem 3:**
35,192 **>** 35,187. Ten-thousands: 3 = 3. Thousands: 5 = 5. Hundreds: 1 = 1. **Tens: 9 > 8** (this is where they first differ).

**Problem 4:**
Least to greatest: **15,678 < 33,051 < 41,863** (Traverse City, Holland, Midland).
Reasoning: 15,678 has the smallest ten-thousands digit (1). Between 33,051 and 41,863, the ten-thousands differ: 3 < 4.

**Problem 5:**
Washington's number: ten-thousands digit same as Lincoln's = **1**. Thousands digit = **3**. Hundreds digit same as Lincoln's = **8**. Remaining digits = **19**. Washington raised **$13,819**.
Compare: 13,819 > 12,847 (thousands: 3 > 2). **Washington raised more.**

---

### Beast Academy Challenge (10 min)

> **Say this:** "Puzzle time. This one requires you to think backwards."

**The Puzzle:**

I'm thinking of two 5-digit numbers. Here are the clues:
- Both numbers have the digits 1, 2, 3, 4, and 5 (each used exactly once per number).
- The two numbers are as CLOSE TOGETHER as possible.
- Neither number starts with the same digit.

What are the two closest 5-digit numbers you can make using these digits, where each number uses all five digits exactly once?

**Solution:**

To make two numbers close together, you want them to differ in the ten-thousands place by exactly 1 (consecutive digits), then make the first number as large as possible and the second as small as possible within their leading digits.

Best approach: one number starts with 3, the other starts with 2.
- The number starting with 3 should be as SMALL as possible: **31,245**
- The number starting with 2 should be as LARGE as possible: **25,431**

Wait — we need each number to use all five digits. Let's verify:
- 31,245 uses: 3, 1, 2, 4, 5. Yes.
- 25,431 uses: 2, 5, 4, 3, 1. Yes.

Difference: 31,245 - 25,431 = **5,814**

Can we do better with 4 and 3?
- 31,254 and 42,135? No, 42,135 - 31,254 = 10,881. Worse.

Can we try 2 and 3 differently?
- 32,145 and 21,543? 32,145 - 21,543 = 10,602. Worse.
- 31,245 and 25,431 = 5,814. This is strong.

**Accept any valid pair with a difference under 7,000.** The key insight is: minimize the gap between leading digits and then balance the remaining digits.

> **Say this:** "This is the kind of problem that professional mathematicians play with. There's strategy involved — you're not just comparing numbers, you're BUILDING them on purpose. That's powerful."

---

### Bug Check

#### Error 404: Student cannot compare numbers at all.
Go back to 2-digit numbers on the 0-100 number line. Write 37 and 52 on sticky notes. Place them on the line. Ask: "Which is further right?" That one is bigger. Do five pairs this way. Then move to 3-digit numbers on the 0-1,000 line. The visual must come before the abstract rule.

#### Error 500: Student compares correctly when digit counts differ but freezes when leading digits match.
This means they understand "more digits = bigger" but have not internalized the left-to-right scan. Practice explicitly: write two numbers stacked and aligned. Point to each column starting from the left. Say: "Same or different?" When you hit "different," stop and ask "Which is bigger?" Repeat with five pairs where the difference is in different places — hundreds, tens, ones.

#### Syntax Error: Student compares correctly but writes the symbol backwards.
This is a symbol issue, not a math issue. Teach the alligator metaphor: the open end always faces the bigger number (the alligator wants to eat the bigger meal). Or: the pointed end always points to the smaller number. Practice writing five comparison statements with the correct symbol.

---

## Block 2: Science (45 min) — Collisions & Energy Transfer

**Standard:** 4-PS3-2 — Make observations to provide evidence that energy can be transferred from place to place.
**ELA Integration:** 4.RI.3 (explaining scientific concepts), 4.W.2 (informative writing), 4.SL.1 (discussion)

---

### Hook (5 min)

Place two pennies on a flat, hard surface (table or smooth floor). Line them up about 6 inches apart.

> **Say this:** "Watch carefully."

Flick the first penny so it slides into the second penny. The first penny should stop (or slow dramatically). The second penny should slide away.

> **Say this:** "What just happened? The first penny was moving. Then it hit the second penny. Now the first penny stopped and the SECOND penny is moving. Where did the energy go?"

*(Let them answer. They should say something like "it went from the first penny to the second one.")*

> **Say this:** "Exactly. The energy didn't disappear. It TRANSFERRED — it moved from one object to another. That's what we're studying today. Not just that things have energy — but where that energy GOES."

---

### Lesson (15 min)

> **Say this:** "Last week, you proved that faster objects have more kinetic energy. A fast car knocked over more cups than a slow car. But here's the question we didn't answer: what happened to the car's energy after the collision? Did the energy just vanish?"

*(No.)*

> **Say this:** "Right. Energy doesn't just disappear. It goes somewhere. When the car hit the cups, the car GAVE its energy to the cups. The car slowed down — it lost energy. The cups moved — they gained energy. The energy transferred from the car to the cups through the collision."

Write these terms in the science journal:

| Word | Meaning |
|------|---------|
| **Energy transfer** | When energy moves from one object to another |
| **Collision** | When two objects hit each other — this is one way energy transfers |
| **Chain reaction** | When energy transfers from one object to the next to the next, in a series |
| **Contact** | Objects touching each other — energy transfers through contact |

> **Say this:** "Here's the rule: energy transfers through CONTACT. The moving object has to actually touch the other object for the energy to move. If the car missed the cups entirely — zoomed right past them — would the cups move?"

*(No.)*

> **Say this:** "No contact, no transfer. That's why dominoes are such a perfect example. Watch."

---

### Activity: The Domino Chain Experiment (20 min)

#### Setup (5 min)

1. Set up 15 dominoes in a straight line on a flat surface, each about 1 inch apart.
2. Make sure each domino is standing upright.
3. Leave space at both ends of the line.

> **Say this:** "Here's the experiment. You're going to push the first domino. Just the first one. Let's see what happens."

#### Part 1: The Chain (5 min)

Have the student push the first domino gently. Watch the entire chain fall.

> **Say this:** "You only touched ONE domino. How did the last domino fall?"

*(Each domino hit the next one.)*

> **Say this:** "Each domino transferred its energy to the next domino through a collision. Domino 1 hit domino 2 — energy transferred. Domino 2 hit domino 3 — energy transferred again. All the way down the line. That's a chain reaction. You put energy into one domino, and it traveled through the whole chain."

#### Part 2: The Gap Test (5 min)

Set up the dominoes again, but this time **remove the 8th domino** — leave a gap in the middle.

> **Say this:** "Same setup, but I took one out. Push the first domino again. What do you predict will happen?"

Let them predict, then test it. The chain should fall until it reaches the gap, then stop.

> **Say this:** "What happened? Why did the chain stop?"

*(Because there was nothing for domino 7 to hit. No contact = no transfer.)*

> **Say this:** "That gap PROVES that energy transfers through contact. Without contact, the energy has nowhere to go. The chain breaks."

Have the student write in their science journal:

**Observation:** Write 3-4 sentences describing what happened in both tests (full chain vs. gap).

**Explanation:** Use the words "energy transfer," "collision," and "contact" to explain WHY the chain stopped when the gap was there.

#### Part 3: Coin Collision (5 min)

Return to the penny demonstration from the hook. Let the student try it several times.

> **Say this:** "Now you try the pennies. Flick the first one into the second. Watch what happens to BOTH pennies. In your journal, draw a before-and-after picture and label where the energy went."

**Sample student drawing description:**
- Before: Penny A is moving right (arrow). Penny B is still.
- After: Penny A is still (or barely moving). Penny B is moving right (arrow).
- Label: "Energy transferred from Penny A to Penny B through collision."

---

### Discussion (5 min)

> **Ask:** "Can you think of a sport where energy transfers through a collision? Describe the transfer — what gives the energy, what receives it?"

**Listen for:** Clear identification of two objects and the direction of energy transfer. Strong answers:
- A baseball bat hits a ball — energy transfers from bat to ball, ball flies
- A bowling ball hits pins — energy from the ball transfers to the pins
- A soccer player kicks a ball — foot transfers energy to ball
- A hockey stick hits a puck — energy from stick transfers to puck

> **If student struggles, say:** "Think about hitting a ball with a bat. Before you swing, is the ball moving? After the bat hits it, is the ball moving? Where did the ball's energy come from?"

---

## Discussion Lunch

While eating, ask:

> **"Imagine you're standing at the start of a really long line of dominoes — like a thousand of them, stretching across a football field. You push the first one. If the energy has to transfer through every single domino, do you think the last domino falls with more, less, or the same amount of energy as the first one? Why?"**

*(This introduces the idea of energy loss through a chain — some energy converts to sound and heat at each collision. Don't teach this formally — just let them think about it. If they say "less," ask why. If they say "same," ask if that matches what they saw in the experiment.)*

---

## End of Day

> **Say this:** "Today you proved something important: energy doesn't just appear and disappear. It MOVES. It transfers from one thing to another through collisions. That's real physics. And you proved it with pennies and dominoes. Tomorrow we work on rounding numbers — which is basically the math version of estimating. See you then."

---

*Total time: approximately 2 hours 15 minutes (Morning Work 15 min + Math 60 min + Science 45 min + Discussion Lunch 15 min)*

---

© 2026 Root Access Learning OS. All rights reserved.
