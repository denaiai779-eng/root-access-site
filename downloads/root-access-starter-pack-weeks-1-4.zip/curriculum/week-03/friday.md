# Week 03 — Friday Lesson Plan

## First Commit: Day 3

**Grade:** 4 | **Standards:** 4.NBT.4, 4-H3.0.1, 4-PS3-3, 4.W.2, 4.W.4, 4.SL.1
**Total instructional time:** ~3 hours (Math + Social Studies + Coding + Discussion Lunch)

## Parent Pre-Read (5 min)

Today wraps Week 3. Math mixes addition and subtraction — your student must determine which operation to use. Social studies continues the Anishinaabe content from Thursday; the student finishes their Seasonal Round poster and does a writing activity about Anishinaabe trade. The coding block introduces variables in Scratch — the student will build a simple score counter. This is the week your student starts feeling genuinely competent. Celebrate that.

---

## Morning Work (15 min)

> **Say this:** "One addition, one subtraction, then a journal."

### Quick Review (8 min)

**1.** 8,205 - 3,467 = _____

**2.** 14,738 + 9,264 = _____

#### Answers

| # | Answer | Notes |
|---|--------|-------|
| 1 | 4,738 | Ones: 5-7, borrow, 15-7=8. Tens: 9-6=3 (after borrow: 0→9, then 9-6=3... Wait: 0-6, borrow from hundreds: 2→1, tens 0→10, 10-6=4... Recheck: 8,205 - 3,467. Ones: 5-7 borrow, 15-7=8. Tens: 0-6, borrow from hundreds, but hundreds=2, so 2→1, tens 0→10. 10-6=4. Actually tens was 0 after borrowing for ones. Let me redo: 8,205. Borrow for ones: tens 0→can't borrow. Go to hundreds: 2→1, tens 0→10. Now borrow for ones: tens 10→9, ones 5→15. 15-7=8. Tens: 9-6=3. Hundreds: 1-4, borrow from thousands: 8→7, hundreds 1→11. 11-4=7. Thousands: 7-3=4. Answer: **4,738**. |
| 2 | 24,002 | Ones: 8+4=12, carry 1. Tens: 3+6+1=10, carry 1. Hundreds: 7+2+1=10, carry 1. Thousands: 4+9+1=14, carry 1. Ten-thousands: 1+0+1=2. Answer: **24,002**. |

### Journal (7 min)

**Prompt:** *"This week, you learned about how the Anishinaabe lived through the seasons — different activities for different times of year. If YOU followed a seasonal round — a cycle of activities through the year — what would your seasons look like? What would you do in each season and why?"*

---

## Block 1: Math (60 min) — Mixed Addition and Subtraction

### Today's Objective

Student can fluently add and subtract multi-digit numbers, determine which operation to use in context, and check answers using estimation (rounding).

### Standards
- **4.NBT.4:** Fluently add and subtract multi-digit whole numbers using the standard algorithm
- **4.NBT.3:** Use place value understanding to round (for estimation checks)
- **4.SL.1:** Collaborative discussion

---

### Launch (10 min)

> **Say this:** "You now know how to add big numbers and subtract big numbers. Today, the challenge isn't just the math — it's figuring out WHICH operation to use. Some problems tell you to add. Some tell you to subtract. Some don't tell you at all — you have to figure it out from the situation."

Write on the board:

**Keywords that often signal ADDITION:** total, combined, altogether, in all, sum, both together

**Keywords that often signal SUBTRACTION:** difference, how many more, how many fewer, remaining, left over, how much longer/shorter

> **Say this:** "These aren't rules — they're clues. You still need to think about what the problem is actually asking. But these words can point you in the right direction."

---

### Guided Practice (20 min)

#### Problem 1: Word Problem — Choose the Operation

> **Say this:** "Michigan's Lower Peninsula has an area of about 40,162 square miles. The Upper Peninsula has an area of about 16,452 square miles. What is the total area of Michigan?"

**Step 1 — Choose the operation.** "Total" = addition.

**Step 2 — Solve.**
```
  40,162
+ 16,452
--------
  56,614
```
Ones: 2+2=4. Tens: 6+5=11, carry 1. Hundreds: 1+4+1=6. Thousands: 0+6=6. Ten-thousands: 4+1=5.

**Step 3 — Check with estimation.** 40,162 ≈ 40,000. 16,452 ≈ 16,000. 40,000 + 16,000 = 56,000. Our answer (56,614) is close. Reasonable.

**Answer:** Michigan's total area is about **56,614** square miles.

---

#### Problem 2: Subtraction in Context

> **Say this:** "Lake Superior has a surface area of 31,700 square miles. Lake Michigan has a surface area of 22,404 square miles. How much larger is Lake Superior?"

**Step 1 — Choose the operation.** "How much larger" = subtraction (finding the difference).

**Step 2 — Solve.**
```
  31,700
- 22,404
--------
```
Ones: 0-4, borrow, 10-4=6. Tens: 9-0=9 (after borrow: tens was 0→borrow from hundreds: 7→6, tens 0→10, then borrow for ones: 10→9). Hundreds: 6-4=2. Thousands: 1-2, borrow: ten-thousands 3→2, thousands 1→11. 11-2=9. Ten-thousands: 2-2=0.

**Answer:** 31,700 - 22,404 = **9,296** square miles larger.

**Estimate check:** 32,000 - 22,000 = 10,000. Our answer (9,296) is close. Reasonable.

---

#### Problem 3: Two-Step Problem

> **Say this:** "A family drove from Detroit to Mackinac City (282 miles), then from Mackinac City to Marquette (165 miles). The total trip was supposed to be 500 miles according to their map. Were they over or under their estimate, and by how much?"

**Step 1 — Find the actual distance.** 282 + 165 = **447** miles.

**Step 2 — Compare to the estimate.** The map said 500 miles. Actual was 447. 500 - 447 = **53** miles under.

**Answer:** They drove **53 fewer miles** than their map estimated. They were under.

---

### Independent Practice (20 min)

> **Say this:** "Five problems. For each one, first decide: add or subtract? Then solve. Then check with an estimate."

**Problem 1** (Easy)

A farmer harvested 4,328 bushels of corn in September and 2,756 bushels in October. How many bushels total?

---

**Problem 2** (Easy)

A library has 12,450 books. They donated 3,875 books to another library. How many books remain?

---

**Problem 3** (Medium)

The population of Lansing is 112,644. The population of Flint is 87,092. How many more people live in Lansing than Flint?

---

**Problem 4** (Medium — two-step)

A school fundraiser set a goal of $10,000. On Monday they raised $3,847. On Tuesday they raised $4,215. How much more do they need to reach their goal?

---

**Problem 5** (Hard — multi-step with estimation)

Two rivers flow into a lake. The Grand River carries about 15,680 cubic feet of water per second. The Muskegon River carries about 8,947 cubic feet per second. Estimate the combined flow by rounding each to the nearest thousand, then calculate the exact combined flow. How close was your estimate?

---

### Answer Key

**Problem 1:** 4,328 + 2,756 = **7,084** bushels. (Addition — "total")

**Problem 2:** 12,450 - 3,875 = **8,575** books. (Subtraction — "remain")

**Problem 3:** 112,644 - 87,092 = **25,552** more people in Lansing. (Subtraction — "how many more")

**Problem 4:** Step 1: 3,847 + 4,215 = **8,062** raised so far. Step 2: 10,000 - 8,062 = **$1,938** still needed.

**Problem 5:** Estimate: 16,000 + 9,000 = **25,000**. Exact: 15,680 + 8,947 = **24,627**. Difference between estimate and exact: 25,000 - 24,627 = **373**. The estimate was 373 over.

---

### Beast Academy Challenge (10 min)

> **Say this:** "This puzzle combines addition and subtraction in a creative way."

**The Puzzle:**

Using the digits 1 through 8 (each used exactly once), fill in this equation:

_ _ _ _ + _ _ _ _ = 9,999

**Solution:**

The key insight: for each column (ones, tens, hundreds, thousands), the two digits must sum to 9.

- Thousands: __ + __ = 9. Possible pairs from {1,2,3,4,5,6,7,8}: (1,8), (2,7), (3,6), (4,5).
- We need four pairs that each sum to 9, using each digit 1-8 once: (1,8), (2,7), (3,6), (4,5).
- Assign them to columns in any order.

Example: **1,234 + 8,765 = 9,999**. Check: uses 1,2,3,4,5,6,7,8 each once. 1+8=9, 2+7=9, 3+6=9, 4+5=9.

Another: **5,274 + 4,725 = 9,999**.

**Accept any valid arrangement.**

> **Say this:** "There are actually MANY right answers. The constraint is that each column must sum to 9. Once you see that pattern, you can build dozens of solutions. Pattern recognition is the heart of mathematical thinking."

---

### Bug Check

- **Error 404**: If the student cannot choose the correct operation, go back to concrete situations. Use actual objects: "Here are 8 blocks. I take away 3. How many are left? Did we add or subtract?" Then: "Here are 5 blocks. I give you 4 more. How many now? Add or subtract?" Build the conceptual link between the situation and the operation before returning to word problems.

- **Error 500**: Student sets up the problem correctly but makes regrouping errors. Have them check every answer with estimation. If the estimate and the answer are wildly different, there is an error somewhere. This teaches self-correction.

- **Syntax Error**: Student writes the answer to a subtraction problem but forgets to include units or context. Push for complete answers: not just "25,552" but "Lansing has 25,552 more people than Flint."

---

## Block 2: Social Studies (45 min) — Anishinaabe Trade and Culture

**Standards:** 4-H3.0.1, 4.W.2, 4.SL.1

---

### Hook (5 min)

> **Say this:** "Yesterday, you learned about the three nations of the Three Fires Confederacy, the Seasonal Round, and Anishinaabe governance. Today, we go deeper into two things: trade and culture. Let's start with a question."

> **Ask:** "If you lived hundreds of years ago and you wanted something from far away — a tool made from a special kind of rock, or food that only grows in a different region — how would you get it? There are no stores, no internet, no delivery trucks."

*(Trading with other people.)*

> **Say this:** "Exactly. And the Anishinaabe — especially the Odawa — were some of the most skilled traders in North America."

---

### Lesson (15 min)

> **Say this:** "The Odawa — the Keepers of the Trade — managed trade networks that were massive in scale. Think about it: they traveled by birch bark canoe across the Great Lakes. These canoes were engineering achievements — lightweight enough for one person to carry over land between waterways, but strong enough to handle waves on Lake Superior. The Odawa could move goods hundreds of miles."

> **Say this:** "Here's what they traded and where it came from:"

Write this table on the board or have the student copy it:

| Trade Good | Where It Came From | Where It Went |
|-----------|-------------------|--------------|
| **Copper** | Upper Peninsula mines | Throughout the Great Lakes, as far as the Gulf of Mexico |
| **Furs** (beaver, mink, deer) | Forests of Michigan | Eastern nations, later Europeans |
| **Dried fish** (whitefish) | Great Lakes, especially the rapids at Baawitigong | Inland communities |
| **Maple sugar** | Sugar camps across Michigan | Nations that lacked maple forests |
| **Wild rice (manoomin)** | Northern lakes and rivers | Southern communities |
| **Birch bark canoes** | Northern forests (birch trees) | Nations across the region |
| **Obsidian** (volcanic glass for tools) | Rocky Mountains (far west) | Anishinaabe communities |
| **Shell beads (wampum)** | Atlantic coast | Great Lakes region |

> **Say this:** "Look at that list. Copper from Michigan has been found at archaeological sites near the Gulf of Mexico — that's over a thousand miles away. Obsidian from the Rocky Mountains has been found in Michigan — another thousand miles in the other direction. These weren't random exchanges. These were organized, long-distance trade routes maintained over generations."

> **Say this:** "And trade wasn't just about goods. Trade was about relationships. When the Odawa traded with another nation, they were also building alliances, sharing information, and maintaining peace. A gift of maple sugar or copper wasn't just a transaction — it was a statement of friendship and obligation. Trade and diplomacy were inseparable."

**[PAUSE]**

> **Say this:** "Now, culture. The Anishinaabe had rich artistic and spiritual traditions. Birch bark was used not just for canoes, but for baskets, containers, and scrolls. Birch bark scrolls carried important knowledge — songs, maps, ceremonies, and history. The Midewiwin (Grand Medicine Society) used birch bark scrolls to record healing knowledge that was passed down through generations."

> **Say this:** "Storytelling, as we discussed yesterday, was not entertainment — it was education. Stories taught young people how to behave, how the world works, and where the people came from. Some stories were told only in certain seasons or only by certain people. The oral tradition was treated with the same seriousness that a library treats its books."

---

### Activity (20 min)

**Part 1: Finish the Seasonal Round Poster (10 min)**

> **Say this:** "First, take 10 minutes to finish your poster from yesterday. Make sure every season has its Anishinaabe name, a drawing, and at least 2 sentences."

Check their work. Make sure the writing is substantive, not just labels.

**Part 2: Trade Route Paragraph (10 min)**

> **Say this:** "Now, write a paragraph about Anishinaabe trade. You're explaining to someone who knows nothing about it. Your paragraph must include:"

1. Who were the main traders? (The Odawa)
2. At least two trade goods and where they came from
3. How goods were transported (birch bark canoe)
4. Why trade was about more than just goods (relationships, alliances, diplomacy)

This is informative writing — 5-7 sentences minimum. Use vocabulary from this week.

---

### Discussion (5 min)

> **Ask:** "The Anishinaabe traded copper, furs, fish, maple sugar, and wild rice. What do we trade today that is similar? What is different about how we trade?"

**Listen for:** Connections between ancient and modern trade — goods still move long distances, trade still builds relationships between nations, but methods have changed (trucks, ships, planes instead of canoes; money instead of gift exchange).

> **If student struggles:** "Think about a grocery store. Where does your food come from? How does it get to the store? Is that so different from the Odawa moving dried fish from the Great Lakes to communities inland?"

---

## Block 3: Coding (30 min) — Scratch: Variables and Score Keeping

### Today's Project: Build a Click Counter

Variables are how programs remember things. Today, the student creates a variable that tracks how many times they click a sprite.

### Setup
- Open **scratch.mit.edu** and log in
- Start a new project

### Instructions

> **Say this:** "In the last two weeks, you made the cat move and respond to keyboard presses. But your programs couldn't REMEMBER anything. They didn't keep score. They didn't count anything. Today, we fix that. We're going to teach Scratch to remember a number — that's called a variable."

**Step 1: Create a Variable (5 min)**

1. Click on **Variables** (orange) in the block palette.
2. Click **"Make a Variable."**
3. Name it **"Score"** and click OK.
4. A display appears on the stage showing "Score: 0." That's your variable — visible and counting.

> **Say this:** "A variable is a box that holds a number. Right now, the box called 'Score' holds the number 0. We're going to make it go up every time you click the cat."

**Step 2: Increase Score on Click (10 min)**

1. From **Events**, drag **"when this sprite clicked"** into the scripting area.
2. From **Variables**, drag **"change [Score] by 1"** and snap it underneath.
3. From **Looks**, add **"say [Clicked!] for 0.5 secs"** after the change block.
4. Click the cat on the stage. The score should go up by 1 each time.

> **Say this:** "Every time you click the cat, the program reads the instruction: change Score by 1. The variable goes from 0 to 1, then 1 to 2, then 2 to 3. The program is REMEMBERING how many times you clicked. That's what variables do — they store information."

**Step 3: Add a Reset Button (10 min)**

1. From **Events**, drag **"when [space] key pressed"** into the scripting area.
2. From **Variables**, drag **"set [Score] to 0"** underneath it.
3. From **Looks**, add **"say [Score reset!] for 1 secs"** after the set block.
4. Press space — the score resets to 0.

**Challenge:** Can you make the cat move to a random position after each click? (Hint: from **Motion**, use **"go to x: [pick random -200 to 200] y: [pick random -150 to 150]"**.) This turns it into a clicking game.

> **Say this:** "You just built a game. The cat appears somewhere random, you try to click it, and the score goes up. Then it jumps somewhere else. Variables made that possible — without the Score variable, there would be no way to keep track."

### Coding Vocabulary Introduced Today
- **Variable**: A named container that stores a value (like a number)
- **Set**: Give a variable a specific value (set Score to 0)
- **Change**: Increase or decrease a variable's value (change Score by 1)

### Extension
- Add a timer: create a second variable called "Time" and use **"wait 1 seconds" + "change Time by -1"** in a repeat loop to count down from 10. When Time reaches 0, stop the game.

---

## Discussion Lunch

> **"The Anishinaabe traded things that were valuable — copper, furs, food. What makes something valuable? Is it how rare it is? How useful it is? How hard it was to get? Think of something YOU think is really valuable and explain why."**

---

## End-of-Week Wrap-Up (5 min)

> **Say this:** "Week 3 is done. You can add and subtract multi-digit numbers — the kind of math that adults do every day. You learned about the Anishinaabe — a civilization that built trade networks across a continent, designed governance systems based on wisdom, and managed the land with knowledge built over thousands of years. And you taught a computer to remember things using variables. That's a serious week."

> **Say this:** "Next week, we go even deeper. More math practice, more about the Three Fires Confederacy's political systems, and we start designing energy solutions in science. You're not just learning — you're building. See you next week."

---

## Homework

See homework.md for this week's assignments.

---

## Materials Checklist

- [ ] Math journal, grid paper, pencil
- [ ] Base-ten blocks (backup)
- [ ] Anishinaabe poster from Thursday (to finish)
- [ ] Colored pencils and markers
- [ ] Lined paper for writing
- [ ] Computer or tablet with internet (for Scratch)

---

*Root Access Learning OS — Week 03 of 36*

© 2026 Root Access Learning OS. All rights reserved.
