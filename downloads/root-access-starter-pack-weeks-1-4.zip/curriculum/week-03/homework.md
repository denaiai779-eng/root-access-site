# Week 03 — Homework

*All homework reinforces what was learned during the day's lesson — never introduces new concepts. If your student is struggling with an assignment, that is a signal to revisit the topic during the next lesson. Homework should take roughly 30 minutes per night (15 min math + 15 min reading/writing). The weekend project is flexible — 30 minutes total, done whenever it fits your family's schedule.*

---

## Wednesday Homework

### Math Practice (15 min)

**Directions:** Complete these four problems in your math notebook. Show all your work — write the carried digits above the correct columns. Use grid paper if it helps you keep your columns aligned.

**1.** 3,845 + 2,678 = _____

**2.** 24,509 + 18,736 = _____

**3.** A Michigan apple farm picked 6,483 Honeycrisp apples and 4,759 Fuji apples. How many apples did they pick in total?

**4.** Fill in the missing digit:

&nbsp;&nbsp;&nbsp;&nbsp;4, _ 6 2 + 3,871 = 8,333

---

### Reading/Writing (15 min)

**Journal Prompt:** *Today you learned that energy can CONVERT — change from one form to another. Write a paragraph (at least 5 sentences) about energy conversions you observed during the science experiments. Your paragraph must include:*
- *The words "energy conversion"*
- *At least two specific examples (e.g., light to heat, motion to sound)*
- *An explanation of WHY the dark paper got warmer than the light paper*

This is informative writing — you are explaining a scientific concept. Be specific about what you observed, not what you guessed.

---

## Thursday Homework

### Math Practice (15 min)

**Directions:** Complete these four problems. Show all your borrowing — cross out the old digit and write the new one above it. Use blocks if you need to.

**1.** 7,432 - 3,856 = _____

**2.** 8,001 - 4,537 = _____

**3.** A bookstore started the week with 15,340 books. By Friday, they had sold 6,872. How many books are left?

**4.** Find the error in this subtraction. Write the correct answer.

```
  6,325
- 2,481
-------
  4,856    ← Is this correct? If not, what is the correct answer?
```

---

### Reading/Writing (15 min)

**Writing Prompt:** *Write a paragraph (5-7 sentences) explaining how the Anishinaabe governed themselves. Your paragraph must include:*
- *The word "ogimaa" and what it means*
- *An explanation of how leaders were chosen (not by inheritance or force)*
- *The word "consensus" and what it means*
- *At least one comparison to how leaders are chosen in the United States today*

This is informative writing — you are teaching your reader about a system of government they may not know about. Use specific details from today's lesson.

---

## Friday Homework

### Weekend Project: Energy Conversion Diagram (30 min total, flexible)

**The Assignment:** Create an Energy Conversion Map of your home.

Walk through your house (or apartment, or wherever you live) and find at least **6 devices or activities** that convert energy from one form to another. For each one, create an entry that includes:

1. **The device or activity** (what is it?)
2. **Input energy** (what form of energy goes IN?)
3. **Output energy** (what form or forms of energy come OUT?)
4. **The conversion arrow** (write it as: Input → Output)

**Format:** Use a full page. Draw a simple floor plan of your home (it can be rough — just rooms with labels). Place each device in the correct room and draw its conversion arrow next to it.

**Example (do NOT use this one — find your own):**
- Kitchen: Toaster → Electrical energy → Heat energy + Light energy

**Challenge:** Find one device that has a CHAIN of conversions — energy changes form more than once. (Hint: think about a car, a phone charger, or a washing machine.)

**Required vocabulary:** Use at least 3 of these terms in labels or captions: *energy conversion, light energy, thermal energy (heat), sound energy, electrical energy, kinetic energy (motion)*.

---

## Answer Keys

### Wednesday Math

**1.** 3,845 + 2,678 = **6,523**
- Ones: 5 + 8 = 13. Write 3, carry 1.
- Tens: 4 + 7 + 1 = 12. Write 2, carry 1.
- Hundreds: 8 + 6 + 1 = 15. Write 5, carry 1.
- Thousands: 3 + 2 + 1 = 6.

**2.** 24,509 + 18,736 = **43,245**
- Ones: 9 + 6 = 15. Write 5, carry 1.
- Tens: 0 + 3 + 1 = 4.
- Hundreds: 5 + 7 = 12. Write 2, carry 1.
- Thousands: 4 + 8 + 1 = 13. Write 3, carry 1.
- Ten-thousands: 2 + 1 + 1 = 4.

**3.** 6,483 + 4,759 = **11,242** apples total.
- Ones: 3 + 9 = 12, carry 1. Tens: 8 + 5 + 1 = 14, carry 1. Hundreds: 4 + 7 + 1 = 12, carry 1. Thousands: 6 + 4 + 1 = 11.

**4.** Missing digit: **4**. The full problem is 4,462 + 3,871 = 8,333.
- Check: Ones: 2 + 1 = 3. Tens: 6 + 7 = 13, carry 1. Hundreds: 4 + 8 + 1 = 13, carry 1. Thousands: 4 + 3 + 1 = 8. Confirmed: 8,333.

*(Common error on Problem 4: Student guesses randomly instead of working backward. Coach them: "Start with a column where you know all but one digit. The tens column: _+7 must end in 3. What + 7 = 13? The answer is 6. Now check: does 4,462 + 3,871 = 8,333?")*

---

### Thursday Math

**1.** 7,432 - 3,856 = **3,576**
- Ones: 2 - 6, borrow. 12 - 6 = 6. Tens: 2 - 5 (was 3, now 2 after borrow), borrow. 12 - 5 = 7. Hundreds: 3 - 8 (was 4, now 3 after borrow), borrow. 13 - 8 = 5. Thousands: 6 - 3 (was 7, now 6 after borrow) = 3.

**2.** 8,001 - 4,537 = **3,464**
- Ones: 1 - 7, cannot. Borrow from tens — tens is 0. Borrow from hundreds — hundreds is 0. Go to thousands: 8 → 7, hundreds 0 → 10, then hundreds 10 → 9, tens 0 → 10, then tens 10 → 9, ones 1 → 11.
- Ones: 11 - 7 = 4. Tens: 9 - 3 = 6. Hundreds: 9 - 5 = 4. Thousands: 7 - 4 = 3. Answer: **3,464**.

*(Common error: student gets confused by the chain borrowing across two zeros. If this happens, use blocks: break 1 thousand cube into 10 hundred flats, then break 1 flat into 10 rods, then break 1 rod into 10 cubes. Walk through it physically.)*

**3.** 15,340 - 6,872 = **8,468** books remaining.
- Ones: 0 - 2, borrow. 10 - 2 = 8. Tens: 3 - 7 (was 4, now 3 after borrow), borrow. 13 - 7 = 6. Hundreds: 2 - 8 (was 3, now 2 after borrow), borrow. 12 - 8 = 4. Thousands: 4 - 6 (was 5, now 4 after borrow), borrow. 14 - 6 = 8. Ten-thousands: 0 (was 1, now 0 after borrow).

**4.** The answer 4,856 is **INCORRECT**. The correct answer is **3,844**.
- Ones: 5 - 1 = 4. Tens: 2 - 8, borrow. 12 - 8 = 4. Hundreds: 2 - 4 (was 3, now 2 after borrow), borrow. 12 - 4 = 8. Thousands: 5 - 2 (was 6, now 5 after borrow) = 3.
- The original "answer" of 4,856 appears to have added instead of subtracted. This is a common error — the student sees the digits and adds them without attending to the operation sign. If your student made this mistake in class, it is worth flagging.

---

### Friday Weekend Project — Success Criteria

There is no single right answer. Use these criteria to evaluate:

- [ ] **Quantity:** At least 6 devices or activities identified
- [ ] **Accuracy:** Each entry correctly identifies the input and output energy forms
- [ ] **Conversion arrows:** Each entry uses the arrow format (Input → Output)
- [ ] **Floor plan:** The diagram shows a basic layout of the home with devices placed in the correct rooms
- [ ] **Vocabulary:** At least 3 science vocabulary terms from this week are used correctly
- [ ] **Effort:** The work shows genuine observation — not just listing obvious devices but thinking about the energy forms involved

**If the student goes above and beyond:** They find a chain conversion (e.g., phone charger: wall electrical → charger heat + phone electrical → phone light + phone sound), correctly identify that most conversions produce heat as a "side effect," or add devices not typically thought of (e.g., a doorbell converts electrical to sound; a candle converts chemical energy to light and heat). Celebrate that.

**If the student struggles:** Start in one room. Stand in the kitchen together. Point at the microwave: "What goes in? Electricity. What comes out? Heat — the food gets warm. Write that down." Move to the next device. Work through 2-3 examples together, then let them continue independently.

---

*Root Access Learning OS — Week 03 of 36*

© 2026 Root Access Learning OS. All rights reserved.
