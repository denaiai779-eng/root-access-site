# Week 03 — First Commit

*Making real progress. No more setup — this is the actual work.*

## Week Summary

Your student has spent two weeks building foundations: place value, number forms, comparing, rounding, energy basics, Michigan geography. This week, they put those foundations to work. In math, they begin multi-digit addition and subtraction — the standard algorithm, with regrouping, applied to numbers in the thousands and beyond. In science, they investigate how energy converts between forms: light becomes heat, motion becomes sound, electrical energy becomes light. In social studies, the focus shifts to the Indigenous peoples of Michigan — specifically the Anishinaabe: the Ojibwe, Odawa, and Potawatomi, known together as the People of the Three Fires. This is not a sidebar. This is the main content. Your student will learn about governance, culture, trade, and daily life of sophisticated civilizations that thrived in the Great Lakes region for millennia.

## Standards Covered This Week

| Subject | Standard Code | Standard Description | Day(s) |
|---------|--------------|----------------------|--------|
| Math | 4.NBT.4 | Fluently add and subtract multi-digit whole numbers using the standard algorithm | W, Th, F |
| Science | 4-PS3-3 | Ask questions and predict outcomes about the changes in energy that occur when objects collide | W, F |
| Social Studies | 4-H3.0.1 | Use historical inquiry to investigate the life of peoples living in Michigan before European contact; describe the daily life, governance, and culture of the Anishinaabe | Th, F |
| ELA | 4.RI.1 | Refer to details and examples in a text when explaining what the text says explicitly and when drawing inferences | Th |
| ELA | 4.RI.3 | Explain events, procedures, ideas, or concepts in a historical, scientific, or technical text | W, Th |
| ELA | 4.W.2 | Write informative/explanatory texts to examine a topic and convey ideas and information clearly | W, Th |
| ELA | 4.W.4 | Produce clear and coherent writing appropriate to task, purpose, and audience | W, Th, F |
| ELA | 4.SL.1 | Engage effectively in a range of collaborative discussions | W, Th, F |
| ELA | 4.L.1-3 | Demonstrate command of conventions of standard English | W, Th, F |

## Materials Needed

### Math (all three days)
- [ ] Math journal (continuing from Weeks 1-2)
- [ ] Pencil and eraser
- [ ] Base-ten blocks (critical this week — regrouping is best taught concretely first)
- [ ] Dry-erase board or scratch paper (for working through multi-step problems)
- [ ] Grid paper or lined paper with wide spacing (helps keep place values aligned during addition/subtraction)

### Science (Wednesday and Friday)
- [ ] Flashlight or lamp
- [ ] A dark-colored piece of paper or cloth (black or navy)
- [ ] A light-colored piece of paper (white)
- [ ] A rubber band (thick, sturdy)
- [ ] A small cardboard box (tissue box or similar — to make a simple instrument)
- [ ] A metal pan or cookie sheet
- [ ] A marble or small ball
- [ ] Science journal or notebook

### Social Studies (Thursday and Friday)
- [ ] Lined paper for writing
- [ ] Colored pencils or markers
- [ ] Large blank paper (at least 11x17 or poster board) for the Anishinaabe life poster
- [ ] Student's Michigan map from previous weeks (for reference)

### General
- [ ] Timer or phone with timer
- [ ] Snack for Discussion Lunch

## Schedule at a Glance

| | Wednesday | Thursday | Friday |
|---|-----------|----------|--------|
| **Block 1** | Math: Multi-Digit Addition | Math: Multi-Digit Subtraction | Math: Mixed Addition & Subtraction |
| **Block 2** | Science: Energy Conversions | Social Studies: The Anishinaabe | Social Studies: Anishinaabe Culture (continued) |
| **Block 3** | — | — | Coding: Scratch — Variables & Score Keeping |
| **Notes** | Regrouping introduced with blocks. | Deep dive into Indigenous civilizations. | Coding builds on Weeks 1-2 Scratch skills. |

## Parent Notes

**This is the week your student starts feeling like a real student.**

The first two weeks were setup and foundations. This week, the work gets real. Addition and subtraction of multi-digit numbers is a core 4th-grade skill — it shows up on every assessment, in every subject, for the rest of the year. If your student can add and subtract 5-digit numbers fluently by the end of this week, they are on track.

- **Addition with regrouping will challenge some students.** Regrouping (what used to be called "carrying") is the moment where 14 ones become 1 ten and 4 ones. Use the base-ten blocks to make this physical. Trade 10 unit cubes for 1 rod. Trade 10 rods for 1 flat. The blocks make the abstract procedure concrete.

- **Subtraction with regrouping is harder.** Always. Especially when there are zeros in the middle of the number (like 5,003 - 2,847). The blocks help here too — you need to "break open" a ten to get ones, or "break open" a hundred to get tens. If subtraction feels brutal on Thursday, slow down and spend extra time with the blocks. Friday has mixed practice built in.

- **The social studies this week is about the Anishinaabe.** This is not a token cultural lesson. Your student will learn about the Ojibwe, Odawa, and Potawatomi as what they were and are: sophisticated civilizations with systems of governance, extensive trade networks, scientific knowledge, rich oral traditions, and diplomatic alliances. Present them with the same depth and respect you would give any civilization. They are not "before" — they are ongoing.

- **You may need to do your own learning this week.** If you are not familiar with the Three Fires Confederacy, read the parent-prep materials carefully. The goal is for your student to understand that Indigenous peoples were not passive inhabitants of the land, but active shapers of it. Their governance systems influenced the U.S. Constitution. Their trade networks spanned a continent. Their ecological knowledge is still studied by scientists today.

---

*Root Access Learning OS — Week 03 of 36*

© 2026 Root Access Learning OS. All rights reserved.
