# Week 03 — Parent Prep

Read this before Wednesday. Budget 25 minutes. The social studies section is longer than usual because it covers material you may not have learned yourself. Take the time.

---

## Math Focus: Multi-Digit Addition & Subtraction (4.NBT.4)

### What You're Teaching

The standard algorithm for adding and subtracting multi-digit whole numbers — with regrouping. Your student has the place value foundation from Weeks 1 and 2. Now they apply it. When you add 3,847 + 2,695, the ones column gives you 12 — but you cannot write 12 in one column. You regroup: write the 2, carry the 1 to the tens column. This is regrouping, and it is the direct result of place value. Ten ones IS one ten. Your student already knows this from the blocks.

### The Progression Across Three Days

- **Wednesday**: Multi-digit addition with and without regrouping. Start concrete (blocks), move to pictorial (drawing regrouping), finish abstract (standard algorithm on paper). Problems range from 4-digit to 5-digit.
- **Thursday**: Multi-digit subtraction with and without regrouping. This is harder — especially when zeros are involved (borrowing across a zero). Same progression: concrete to abstract.
- **Friday**: Mixed practice — problems that require both addition and subtraction, including word problems that ask the student to determine which operation to use.

### The Misconception You Need to Watch For

**"Carrying" without understanding**: Students learn to "carry the 1" but have no idea what the 1 represents. When they add 47 + 35, they write 2 in the ones column and "carry the 1" to the tens — but that 1 is actually 1 ten. If they cannot explain WHY they are carrying, the procedure will break down with larger numbers. Use the blocks to physically trade 10 ones for 1 ten.

**Subtraction across zeros**: 5,003 - 2,847. The student needs to subtract 7 from 3 in the ones place — they cannot. So they need to borrow from the tens. But the tens are 0. So they need to borrow from the hundreds. But those are also 0. So they go to the thousands, break a thousand into 10 hundreds, then break a hundred into 10 tens, then break a ten into 10 ones. This chain of borrowing is where most 4th graders stumble. Use the blocks to model every step physically.

### If Your Student Is Ahead

Give them problems with 6- or 7-digit numbers. Same algorithm, bigger numbers. Or introduce problems that require addition and subtraction in the same problem: "Marcus had $15,432. He spent $3,875 on Monday and $4,213 on Tuesday. How much does he have left?"

### If Your Student Is Behind

Drop to 3-digit numbers. Add 347 + 286 with blocks side by side. Show the trade physically. Do not move to 4-digit until they can do 3-digit with confidence. There is no rush — Thursday and Friday give more practice, and this standard continues into Week 4.

---

## Science Focus: Energy Conversions (4-PS3-3)

### What You're Teaching

In Weeks 1 and 2, your student learned that energy exists (kinetic energy), that faster objects have more of it, and that energy can transfer between objects. This week, they learn that energy can also CHANGE FORM. Light can become heat. Motion can become sound. Electrical energy can become light. Energy is not stuck in one form — it converts.

### Background You Need

The key concept is **energy conversion** (also called energy transformation). Here are the forms of energy your student will work with this week:

| Form | Description | Everyday Example |
|------|-------------|-----------------|
| **Light** | Energy you can see — visible electromagnetic radiation | Sunshine, lightbulb, phone screen |
| **Heat (thermal)** | Energy from the vibration of particles — makes things warm | Stove burner, body warmth, friction |
| **Sound** | Energy from vibrations traveling through air (or other materials) | Music, voices, a drum beat |
| **Motion (kinetic)** | Energy of a moving object | Running, a rolling ball, wind |
| **Electrical** | Energy from the flow of electrons through a circuit | Batteries, wall outlets, lightning |

Energy conversions happen constantly. A lightbulb converts electrical energy to light AND heat. A drum converts motion (the strike of the stick) to sound. Rubbing your hands together converts motion to heat. Your student will observe and identify these conversions through hands-on activities.

### Key Vocabulary

| Term | Student-Friendly Definition |
|------|---------------------------|
| **Energy conversion** | When energy changes from one form to another |
| **Light energy** | Energy we can see |
| **Thermal energy (heat)** | Energy that makes things warm |
| **Sound energy** | Energy we can hear, made by vibrations |
| **Electrical energy** | Energy from electricity |

---

## Social Studies Focus: The Anishinaabe (4-H3.0.1)

### What You're Teaching

This is the beginning of a two-week deep study of the Indigenous peoples of Michigan, specifically the Anishinaabe — the Ojibwe (also called Chippewa), the Odawa (also called Ottawa), and the Potawatomi. Together, they are known as the People of the Three Fires (Niswi-mishkodewin). This week focuses on daily life, governance, culture, and trade. Week 4 will go deeper into the Three Fires Confederacy's political systems and diplomacy.

### Background You Need — Please Read Carefully

**The Anishinaabe are not a historical footnote.** They are living peoples with sovereign nations, active governments, and thriving cultures in Michigan today. When you teach this material, avoid the past tense as the default. Say "the Anishinaabe live in the Great Lakes region" — not just "they lived." Say "the Ojibwe harvest wild rice" — not just "they used to harvest." The past and present coexist.

**The Three Fires:**

The Ojibwe, Odawa, and Potawatomi are related peoples who share the Anishinaabemowin language family and a common origin story. They are allied in the Council of Three Fires (Niswi-mishkodewin), a confederacy that predates European contact by centuries. Each nation had a distinct role:

- **Ojibwe (Chippewa)** — "Keepers of the Faith." The largest of the three nations. They maintained spiritual traditions, ceremonies, and the knowledge of medicines. They lived primarily in the northern Great Lakes — the Upper Peninsula, northern Lower Peninsula, and into present-day Wisconsin, Minnesota, and Ontario.

- **Odawa (Ottawa)** — "Keepers of the Trade." Master traders and diplomats. The Odawa managed vast trade networks that moved goods across the Great Lakes and beyond. Copper from the U.P., furs, dried fish, maple sugar, and birch bark canoes were all trade goods. They lived primarily along the Lake Michigan and Lake Huron shores.

- **Potawatomi** — "Keepers of the Sacred Fire." They maintained the council fire — the symbolic and literal center of alliance meetings. They were known as negotiators and peacekeepers. They lived primarily in the southern Lower Peninsula and into present-day Indiana, Illinois, and Wisconsin.

**Governance:**

The Anishinaabe did not have kings or queens. Governance was based on consensus and councils. Leaders (ogimaa) earned their position through wisdom, generosity, and service — not inheritance or force. Decisions were made in councils where all voices were heard, including women's and elders'. This was not primitive — it was a deliberately designed system that valued collective decision-making over individual power. Some historians argue that the Iroquois and Anishinaabe confederacy models influenced the framers of the U.S. Constitution.

**Seasonal Round:**

The Anishinaabe followed a seasonal cycle of activity — sometimes called the "Seasonal Round." This was not aimless wandering. It was a precisely planned annual pattern:

- **Spring (Ziigwan):** Maple sugar camps. Families gathered to tap maple trees and process sugar. This was a social and economic event.
- **Summer (Niibin):** Planting gardens (corn, beans, squash — the Three Sisters), fishing, gathering berries.
- **Fall (Dagwaagin):** Wild rice (manoomin) harvest. Wild rice was and remains a sacred food. Hunting deer and other game.
- **Winter (Biboon):** Storytelling season. Families gathered in winter camps. Stories carried history, science, morality, and entertainment. Hunting and trapping continued.

**Trade:**

Anishinaabe trade networks were extensive and sophisticated. Copper from the Upper Peninsula has been found in archaeological sites as far away as the Gulf of Mexico. The Odawa in particular were known as expert traders who managed routes across the Great Lakes by birch bark canoe. These were not barter-only systems — they involved diplomacy, alliances, gift exchanges, and reciprocal obligations.

**Today:**

There are 12 federally recognized tribes in Michigan, and several more state-recognized. The Sault Ste. Marie Tribe of Chippewa Indians, the Grand Traverse Band of Ottawa and Chippewa Indians, the Little Traverse Bay Bands of Odawa Indians, the Pokagon Band of Potawatomi, the Nottawaseppi Huron Band of the Potawatomi, and others are active, sovereign nations. They operate governments, schools, cultural centers, and businesses. Their treaty rights — including fishing and hunting rights — are legally recognized and actively exercised.

### Key Vocabulary

| Term | Student-Friendly Definition |
|------|---------------------------|
| **Anishinaabe** | The collective name for the Ojibwe, Odawa, and Potawatomi peoples |
| **Three Fires Confederacy** | The alliance of the Ojibwe, Odawa, and Potawatomi nations |
| **Ogimaa** | A leader or chief — earned through wisdom and service, not inherited |
| **Seasonal Round** | The annual cycle of activities: sugaring, planting, harvesting, hunting, storytelling |
| **Manoomin** | Wild rice — a sacred and staple food harvested in the fall |
| **Sovereignty** | A nation's right to govern itself |

---

## ELA Integration Points

### Reading (4.RI.1, 4.RI.3)
- **Thursday, Social Studies**: The oral lecture about the Anishinaabe functions as an informational text delivered aloud. Ask the student to refer to specific details (4.RI.1) and explain concepts like the Seasonal Round or consensus governance (4.RI.3).

### Writing (4.W.2, 4.W.4)
- **Wednesday, Science**: CER writing about energy conversions — informative writing using evidence (4.W.2).
- **Thursday, Social Studies**: Explanatory writing about Anishinaabe life, using domain-specific vocabulary (4.W.2, 4.W.4).

### Speaking and Listening (4.SL.1)
- **Every day**: This week's discussions are particularly rich. The social studies content invites genuine dialogue about governance, fairness, culture, and what it means for a civilization to be "advanced."

### Language Conventions (4.L.1-3)
- **Every day**: Same standard as previous weeks. Hold the line on grammar, spelling, and punctuation in all written work.

---

## Materials Checklist

### Must Have
- [ ] **Base-ten blocks** — essential this week for regrouping. Have the full set (ones, tens, hundreds, thousands) accessible for every math lesson.
- [ ] **Grid paper** — helps keep digits aligned during addition and subtraction. Print graph paper or buy a pad at any office supply store.
- [ ] **Math journal** — continuing from Weeks 1-2
- [ ] **Flashlight** — any kind. For the light-to-heat experiment.
- [ ] **Dark and light paper** — one sheet of each. For testing light absorption.
- [ ] **Rubber band and small box** — for building a simple sound instrument.
- [ ] **Large blank paper or poster board** — for the Anishinaabe life poster on Thursday/Friday.
- [ ] **Colored pencils and markers**
- [ ] **Pencils, eraser, sharpener**

### Nice to Have
- [ ] **Whiteboard** — for working through addition/subtraction steps
- [ ] **Printed grid paper** — search "free printable grid paper" for perfect alignment

---

## Your Mindset This Week

Two things to hold onto:

First, addition and subtraction with regrouping is one of the most important procedural skills in elementary math. Your student needs to be fluent with it — not just able to do it, but able to do it accurately and without hesitation. That takes practice. If they need extra time, take it. The procedure matters.

Second, teaching Indigenous history with depth and respect is not optional. It is the standard. Many adults were taught a version of Michigan history that reduced Indigenous peoples to a paragraph before the "real" history started. That version was incomplete and harmful. Your student deserves better. The Anishinaabe built civilizations. They governed nations. They managed ecosystems. They traded across continents. Teach that with the same energy and detail you would bring to any world civilization, because that is exactly what it is.

---

*Root Access Learning OS — Week 03 of 36*

© 2026 Root Access Learning OS. All rights reserved.
