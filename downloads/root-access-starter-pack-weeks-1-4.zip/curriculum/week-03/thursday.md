# Week 3 — Thursday

## First Commit: Day 2

**Grade:** 4 | **Standards:** 4.NBT.4, 4-H3.0.1, 4.RI.1, 4.RI.3, 4.W.2, 4.SL.1
**Theme:** First Commit — doing the real work
**Math Mode:** Concrete to Abstract — Subtraction with regrouping

---

## Materials Checklist

- [ ] Math journal and pencil
- [ ] Base-ten blocks (full set — critical for subtraction regrouping)
- [ ] Grid paper
- [ ] Dry-erase board or scratch paper
- [ ] Large blank paper or poster board (for Anishinaabe poster — starts today, continues Friday)
- [ ] Colored pencils and markers
- [ ] Lined paper for social studies writing
- [ ] Student's Michigan map from previous weeks
- [ ] Timer
- [ ] Snack for Discussion Lunch

---

## Morning Work (15 min)

> **Say this:** "Three addition problems to warm up. Use the algorithm — show your regrouping."

### Quick Review (8 min)

**1.** 4,586 + 2,937 = _____

**2.** 15,248 + 7,693 = _____

**3.** Round your answer to Problem 1 to the nearest thousand. Then round your answer to Problem 2 to the nearest thousand.

#### Answers

| # | Answer | Notes |
|---|--------|-------|
| 1 | 7,523 | Ones: 6+7=13, carry 1. Tens: 8+3+1=12, carry 1. Hundreds: 5+9+1=15, carry 1. Thousands: 4+2+1=7. |
| 2 | 22,941 | Ones: 8+3=11, carry 1. Tens: 4+9+1=14, carry 1. Hundreds: 2+6+1=9. Thousands: 5+7=12, carry 1. Ten-thousands: 1+0+1=2. |
| 3 | 7,523 → 8,000. 22,941 → 23,000. |

### Journal Prompt (7 min)

**Prompt:** *"What does it mean to be a leader? Think about a leader you respect — not necessarily a president or a king. Maybe a coach, a teacher, an older cousin, a community member. What makes them a good leader? Is it power, or something else?"*

This connects directly to today's social studies lesson about Anishinaabe governance.

---

## Block 1: Math (60 min) — Multi-Digit Subtraction

**Standard:** 4.NBT.4
**Approach:** Concrete (blocks) to Abstract (standard algorithm)

---

### Launch (10 min)

**Setup:** Base-ten blocks on the table. Grid paper ready.

> **Say this:** "Yesterday you added big numbers. Today you subtract them. Subtraction uses the same place value understanding, but instead of regrouping UP — trading 10 small for 1 big — you regroup DOWN. You trade 1 big for 10 small. Let me show you."

Write **532 - 278** on the board.

> **Say this:** "Build 532 with blocks. 5 flats, 3 rods, 2 cubes. Now we need to take away 278. Start with the ones. We need to take away 8 ones, but we only have 2. What do we do?"

*(Wait for their answer. If they are stuck:)*

> **Say this:** "We don't have enough ones. So we BREAK OPEN a ten. Take 1 rod from the tens pile — that gives us 10 more ones. Now we have 12 ones and 2 tens (instead of 3 tens). Take away 8 ones from the 12. How many left?"

*(12 - 8 = 4 ones.)*

> **Say this:** "Good. Now the tens. We have 2 tens (we gave one away). We need to take away 7 tens. Not enough again. Break open a hundred — take 1 flat, trade it for 10 rods. Now we have 12 tens and 4 hundreds. Take away 7: 12 - 7 = 5 tens."

> **Say this:** "Hundreds: 4 - 2 = 2 hundreds. Answer: 254."

> **Say this:** "That's regrouping in subtraction. Instead of trading UP like in addition, you trade DOWN. You break a bigger block into 10 smaller ones whenever you don't have enough to subtract."

---

### Guided Practice (20 min)

#### Problem 1: Subtraction with One Regrouping

**Context:** A bookstore had 3,542 books. They sold 1,387. How many are left?

```
  3,542
- 1,387
-------
```

**Step 1 — Ones:** 2 - 7. Cannot do it. Borrow from tens: tens goes from 4 to 3, ones goes from 2 to 12. 12 - 7 = **5**.

**Step 2 — Tens:** 3 - 8. Cannot do it. Borrow from hundreds: hundreds goes from 5 to 4, tens goes from 3 to 13. 13 - 8 = **5**.

**Step 3 — Hundreds:** 4 - 3 = **1**.

**Step 4 — Thousands:** 3 - 1 = **2**.

**Answer:** 3,542 - 1,387 = **2,155** books remaining.

---

#### Problem 2: Subtraction Across Zeros

> **Say this:** "This next one is trickier. Watch what happens when there's a zero in the number you're subtracting from."

**Context:** A school had 5,003 students enrolled over its history. If 2,847 have graduated, how many are currently enrolled?

```
  5,003
- 2,847
-------
```

**Step 1 — Ones:** 3 - 7. Cannot do it. Borrow from tens. But tens is 0. Borrow from hundreds. But hundreds is also 0. Go to thousands.

> **Say this:** "This is the hard part. We need to go all the way to the thousands to find something to borrow. Watch."

- Break 1 thousand into 10 hundreds: thousands goes from 5 to 4, hundreds goes from 0 to 10.
- Break 1 hundred into 10 tens: hundreds goes from 10 to 9, tens goes from 0 to 10.
- Break 1 ten into 10 ones: tens goes from 10 to 9, ones goes from 3 to 13.

Now subtract:
- Ones: 13 - 7 = **6**
- Tens: 9 - 4 = **5**
- Hundreds: 9 - 8 = **1**
- Thousands: 4 - 2 = **2**

**Answer:** 5,003 - 2,847 = **2,156**.

> **Say this:** "When you hit a zero, you keep moving left until you find a digit you can borrow from. Then you chain the borrowing back. It feels complicated the first time, but it's the same idea: break a bigger unit into 10 of the next smaller unit."

---

#### Problem 3: 5-Digit Subtraction

**Context:** Michigan has about 36,350 miles of rivers and streams. Wisconsin has about 12,587 miles. How many more miles of rivers does Michigan have?

```
  36,350
- 12,587
--------
```

**Step 1 — Ones:** 0 - 7. Cannot. Borrow from tens: tens 5→4, ones 0→10. 10 - 7 = **3**.

**Step 2 — Tens:** 4 - 8. Cannot. Borrow from hundreds: hundreds 3→2, tens 4→14. 14 - 8 = **6**.

**Step 3 — Hundreds:** 2 - 5. Cannot. Borrow from thousands: thousands 6→5, hundreds 2→12. 12 - 5 = **7**.

**Step 4 — Thousands:** 5 - 2 = **3**.

**Step 5 — Ten-thousands:** 3 - 1 = **2**.

**Answer:** 36,350 - 12,587 = **23,763** more miles.

---

### Independent Practice (20 min)

> **Say this:** "Five subtraction problems. Use grid paper. Show all your borrowing. Use blocks for any problem that feels tough — there is no penalty for using blocks."

**Problem 1** (Easy — one regrouping)

7,685 - 3,241 = _____

---

**Problem 2** (Easy — two regroupings)

8,432 - 4,657 = _____

---

**Problem 3** (Medium — zeros involved)

6,005 - 2,738 = _____

---

**Problem 4** (Medium — 5-digit)

42,513 - 18,647 = _____

---

**Problem 5** (Hard — context)

The Mackinac Bridge is 26,372 feet long. The Ambassador Bridge connecting Detroit to Canada is 7,490 feet long. How much longer is the Mackinac Bridge?

---

### Answer Key

**Problem 1:** 7,685 - 3,241 = **4,444**. Ones: 5-1=4. Tens: 8-4=4. Hundreds: 6-2=4. Thousands: 7-3=4. No regrouping needed.

**Problem 2:** 8,432 - 4,657 = **3,775**. Ones: 2-7, borrow, 12-7=5. Tens: 2-5, borrow, 12-5=7. Hundreds: 3-6, borrow, 13-6=7. Thousands: 7-4=3.

**Problem 3:** 6,005 - 2,738 = **3,267**. Ones: 5-8, borrow from tens (0). Chain borrow from thousands: 6→5, hundreds 0→9 (after giving 1 to tens), tens 0→9 (after giving 1 to ones), ones 5→15. 15-8=7. Tens: 9-3=6. Hundreds: 9-7=2. Thousands: 5-2=3.

**Problem 4:** 42,513 - 18,647 = **23,866**. Ones: 3-7, borrow, 13-7=6. Tens: 0-4, borrow, 10-4=6. Hundreds: 4-6, borrow, 14-6=8. Thousands: 1-8, borrow, 11-8=3. Ten-thousands: 3-1=2.

**Problem 5:** 26,372 - 7,490 = **18,882**. Ones: 2-0=2. Tens: 7-9, borrow, 17-9=8. Hundreds: 2-4, borrow, 12-4=8. Thousands: 5-7, borrow, 15-7=8. Ten-thousands: 1-0=1. Answer: **18,882** feet longer.

---

### Beast Academy Challenge (10 min)

> **Say this:** "Subtraction puzzle. Think carefully."

**The Puzzle:**

Find a 4-digit number where:
- When you subtract 1,111 from it, every digit in the answer is exactly ONE LESS than the corresponding digit in the original number.
- No digit in the original number is 0.

**Solution:**

If subtracting 1,111 makes each digit decrease by 1, the original number must have no regrouping when you subtract 1,111. That means every digit must be at least 2 (since 1 - 1 = 0, and we need digits at least 0).

Any 4-digit number with all digits ≥ 2 works: for example, **2,222** → 2,222 - 1,111 = **1,111**. Check: each digit decreased by 1. Yes.

Or **5,678** → 5,678 - 1,111 = **4,567**. Each digit decreased by 1. Yes.

But wait — the problem says no digit in the original can be 0. Since we need digits ≥ 2 (to avoid regrouping and get a digit one less), and no digit is 0, the valid range for each digit is 2-9.

**Any number with all digits between 2 and 9 works.** There are many answers.

> **Say this:** "What if one of the digits were 1? Like 3,142? Then 3,142 - 1,111 = 2,031. The tens digit went from 4 to 3 — that's one less. But the hundreds digit went from 1 to 0 — that's also one less. So 3,142 actually works too, as long as you accept a 0 in the answer. The puzzle says no digit in the ORIGINAL is 0, not the answer. So any number with digits 1-9 works — there are thousands of answers!"

---

### Bug Check

#### Error 404: Student cannot subtract with regrouping.
Go back to 2-digit subtraction with blocks. Build 43. Take away 28. Show: you cannot take 8 ones from 3 ones. Break open a ten rod into 10 ones. Now you have 13 ones and 3 tens. 13-8=5 ones. 3-2=1 ten. Answer: 15. Repeat with three more problems.

#### Error 500: Student borrows but forgets to reduce the digit they borrowed from.
Common error: borrowing from tens but leaving the tens digit unchanged. Say: "When you break open a ten, you have one FEWER ten. Cross out the old tens digit and write the new one above it." Use a red pencil for the crossed-out digit and the new smaller digit. The visual crossing-out makes it concrete.

#### Syntax Error: Student understands regrouping but makes errors across zeros.
This is specifically the 5,003 - 2,847 type problem. Practice the chain-borrowing explicitly: "Go left until you find a non-zero digit. Borrow from there. Then send it back, one place at a time." Walk through the chain slowly, one place at a time, with blocks if needed.

---

## Block 2: Social Studies (45 min) — The Anishinaabe: People of the Three Fires

**Standards:** 4-H3.0.1, 4.RI.1, 4.RI.3, 4.W.2, 4.SL.1

---

### Hook (5 min)

> **Say this:** "For the last two weeks, we've been learning about Michigan — the shape of the land, the Great Lakes, why cities are where they are. We talked about how the Anishinaabe named these places and knew this land long before anyone else mapped it. Today, we go much deeper. We're going to learn about WHO the Anishinaabe are — not just where they lived, but HOW they lived. Their government. Their food. Their trade. Their culture. These weren't small bands wandering around. These were nations — with systems, alliances, laws, and knowledge that lasted for thousands of years."

Pause.

> **Say this:** "Here's something to hold on to as we learn today: the Anishinaabe are not just history. These nations are still here. They have governments, schools, cultural centers, and communities in Michigan right now. We're learning about them in the past AND the present."

---

### Lesson (20 min)

Read this aloud. Pause at **[PAUSE]** marks.

> **Say this:** "The Anishinaabe are a group of related peoples who have lived in the Great Lakes region for thousands of years. The name Anishinaabe means 'the people' or 'the original people.' Within the Anishinaabe, there are three main nations, and together they form an alliance called the Three Fires Confederacy — Niswi-mishkodewin in the Anishinaabe language."

Write on the board:

| Nation | Also Known As | Role in the Confederacy | Region |
|--------|--------------|------------------------|--------|
| **Ojibwe** | Chippewa | Keepers of the Faith | Northern Michigan, U.P. |
| **Odawa** | Ottawa | Keepers of the Trade | Lake Michigan & Huron shores |
| **Potawatomi** | Potawatomi | Keepers of the Sacred Fire | Southern Lower Peninsula |

> **Say this:** "Think of the Three Fires like three siblings in a family. They share the same language family — Anishinaabemowin — the same creation stories, and many of the same traditions. But each has a specific role."

**[PAUSE]**

> **Say this:** "The Ojibwe were the Keepers of the Faith. They maintained the spiritual practices, the ceremonies, the knowledge of healing medicines, and the sacred stories that held the culture together. They were the largest of the three nations and lived primarily in the northern Great Lakes — the Upper Peninsula and beyond."

> **Say this:** "The Odawa were the Keepers of the Trade. They were master traders and diplomats. The Odawa managed trade networks that stretched across the Great Lakes. They moved copper from the Upper Peninsula, furs, dried fish, maple sugar, and birch bark canoes along water routes that connected nations across hundreds of miles. If you needed something from far away, the Odawa could get it."

> **Say this:** "The Potawatomi were the Keepers of the Sacred Fire. They maintained the council fire — the literal and symbolic center of meetings between nations. They were peacekeepers and negotiators. When the Three Fires met in council, the Potawatomi tended the fire around which decisions were made."

**[PAUSE]**

> **Ask:** "Why do you think they called it the Three FIRES Confederacy?"

*(The fire was the center of their meetings, their councils, their decision-making. It represented warmth, light, and community — the things that hold people together.)*

> **Say this:** "Now let's talk about how the Anishinaabe lived through the year. They followed what historians call the Seasonal Round — a cycle of activities that matched the seasons."

**Spring — Ziigwan:**
> "Spring was maple sugar time. Families traveled to sugar camps — groves of maple trees — and tapped the trees to collect sap. They boiled the sap down into maple sugar, which was used as seasoning, medicine, and a trade good. This wasn't small-scale. Families produced hundreds of pounds of sugar in a good spring. Sugar camps were social gatherings — a time for families to reconnect after winter."

**Summer — Niibin:**
> "Summer was for planting and fishing. The Anishinaabe grew corn, beans, and squash — called the Three Sisters because the plants support each other when planted together. Corn stalks give the beans something to climb. Beans add nitrogen to the soil. Squash leaves shade the ground and keep it moist. This was sophisticated agriculture. They also fished the Great Lakes and rivers, using nets, spears, and weirs — structures built in rivers to direct fish into traps."

**Fall — Dagwaagin:**
> "Fall was harvest time — especially the wild rice harvest. Wild rice, called manoomin in Anishinaabemowin, grows in shallow lakes and rivers. Harvesters would paddle canoes through the rice beds and gently knock the ripe grains into the canoe with sticks. Manoomin is sacred to the Anishinaabe — it was a gift from the Creator and remains culturally important today. Fall was also hunting season — deer, elk, and other game were prepared and stored for winter."

**Winter — Biboon:**
> "Winter was storytelling season. Families gathered in winter camps. Elders told stories — not just for entertainment, but to teach. Stories carried history, science, morality, and survival knowledge from generation to generation. Some stories could only be told in winter. Hunting and trapping continued, and the stored food from fall kept communities fed. Winter was also a time for making tools, clothing, and items for trade."

**[PAUSE]**

> **Say this:** "One more thing: governance. The Anishinaabe did not have kings. They had leaders called ogimaa, and those leaders earned their position through wisdom, generosity, and service to the community. You couldn't buy the position. You couldn't inherit it. If a leader made bad decisions, people stopped following them. Decisions were made in councils where everyone — including women and elders — had a voice. The goal was consensus: not just a majority vote, but agreement that everyone could support."

> **Say this:** "Think about that for a moment. A system where leaders have to earn respect through actions, not just hold power through inheritance or money. Where decisions require everyone to agree, not just 51%. That's a sophisticated system of government."

---

### Activity (15 min)

> **Say this:** "You're going to create an Anishinaabe Life poster. Use the large paper. Divide it into four sections — one for each season. In each section, draw and write about what the Anishinaabe did during that season."

**For each season, include:**
1. The season name in Anishinaabemowin (Ziigwan, Niibin, Dagwaagin, Biboon)
2. A drawing of the main activity
3. 2-3 sentences describing what happened and why it mattered
4. At least one vocabulary word from today's lesson

**Start today, finish tomorrow.** This poster should show understanding, not just decoration. The writing matters more than the art.

---

### Historical Context — A Note for the Parent

Present the Anishinaabe as active agents — people who CHOSE how to live based on deep knowledge, not people who were simply "at the mercy of nature." The Seasonal Round was a deliberate, planned cycle based on ecological expertise built over millennia. The Three Sisters agriculture was intentional companion planting. The trade networks were organized systems of commerce and diplomacy. The governance was a designed political system.

Avoid phrases like: "They lived simply." "They were one with nature." "They lived off the land." These phrases erase the sophistication of Anishinaabe life and reduce complex civilizations to stereotypes.

Instead, use phrases like: "They managed the land." "They designed governance systems." "They built trade networks." "They cultivated crops using companion planting techniques." Active, specific, accurate.

---

### Discussion (5 min)

> **Ask:** "The Anishinaabe chose their leaders based on wisdom and service. In the United States today, how are leaders chosen? What are the similarities and differences?"

**Listen for:** Understanding that Anishinaabe governance was based on consensus and earned leadership, while U.S. governance uses elections, voting, and representatives. Both involve the community having a say. Differences: consensus vs. majority rule, earned vs. elected.

> **If student struggles:** "Think about how your family makes decisions. Does one person decide everything? Or do people talk about it and try to agree? How is that similar to or different from the Anishinaabe council system?"

---

## Discussion Lunch

> **"The Anishinaabe grew corn, beans, and squash together — the Three Sisters — because the plants help each other grow. Can you think of other examples of things that work better together than alone? In nature, in your family, in sports, anywhere."**

---

## End-of-Day Check

- [ ] **Math:** Student can subtract 4-digit numbers with regrouping
- [ ] **Math:** Student can handle at least one subtraction problem with zeros
- [ ] **Social Studies:** Student can name the three nations of the Three Fires Confederacy and their roles
- [ ] **Social Studies:** Student can describe at least two seasons of the Seasonal Round
- [ ] **Poster:** Started (will be completed Friday)

---

*Root Access Learning OS — Week 03, Thursday*

© 2026 Root Access Learning OS. All rights reserved.
