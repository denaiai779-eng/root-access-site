# Week 3 — Wednesday

## First Commit: Day 1

**Grade:** 4 | **Standards:** 4.NBT.4, 4-PS3-3, 4.RI.3, 4.W.2, 4.SL.1
**Total instructional time:** ~2 hours 15 minutes

---

## Materials Checklist

### Math
- [ ] Math journal and pencil
- [ ] Base-ten blocks (ones cubes, tens rods, hundreds flats, thousands cubes)
- [ ] Grid paper or lined paper with wide spacing
- [ ] Dry-erase board or scratch paper

### Science
- [ ] Flashlight or desk lamp
- [ ] Dark-colored paper (black or navy)
- [ ] Light-colored paper (white)
- [ ] Rubber band (thick)
- [ ] Small cardboard box (tissue box or similar — open on one side)
- [ ] Science journal and pencil

### General
- [ ] Timer
- [ ] Snack for Discussion Lunch

---

## Morning Work (15 min)

> **Say this:** "Quick review, then we dive into something new."

### Quick Review (8 min)

**1.** Round 7,650 to the nearest thousand.

**2.** Compare: 43,508 _____ 43,580

**3.** What is the value of the 9 in 29,143?

#### Answers

| # | Answer | Notes |
|---|--------|-------|
| 1 | 8,000 | Hundreds digit 6 ≥ 5, round up. |
| 2 | 43,508 < 43,580 | Same through hundreds. Tens: 0 < 8. |
| 3 | 9,000 | 9 is in the thousands place. |

### Journal Prompt (7 min)

**Prompt:** *"Think about a time you had to figure something out step by step — like building something, solving a puzzle, or learning a new skill. What was the first step? What came next? How did you know what order to do things in?"*

---

## Block 1: Math (60 min) — Multi-Digit Addition

**Standard:** 4.NBT.4 — Fluently add and subtract multi-digit whole numbers using the standard algorithm.
**Approach:** Singapore Math — Concrete (blocks) to Pictorial (drawn regrouping) to Abstract (standard algorithm).

---

### Launch (10 min)

**Setup:** Put the base-ten blocks on the table. Have grid paper ready.

> **Say this:** "For the past two weeks, you've been building your understanding of place value — what each digit is worth, how to compare numbers, how to round them. Now you're going to USE that understanding. Today, we start adding big numbers. And I mean big — thousands, ten-thousands. The real thing."

Write **347 + 285** on the board.

> **Say this:** "Let's start with one we can do with blocks. Build 347 with blocks: 3 hundreds flats, 4 tens rods, 7 ones cubes. Now build 285 next to it: 2 hundreds flats, 8 tens rods, 5 ones cubes."

> **Say this:** "Now push them together. You're adding — combining everything. Start with the ones. How many ones total?"

*(7 + 5 = 12 ones.)*

> **Say this:** "12 ones. But we can't have 12 loose cubes sitting in the ones column — we only write one digit per column. So what do we do? We TRADE. 10 of those ones cubes become 1 tens rod. That leaves 2 ones. Write 2 in the ones column, and add that new tens rod to the tens pile."

Physically trade 10 unit cubes for 1 rod. Place the rod with the other tens.

> **Say this:** "Now count the tens. 4 + 8 = 12, plus the 1 we just carried = 13 tens. Same thing — 13 tens means we trade again. 10 tens rods become 1 hundreds flat. That leaves 3 tens."

Trade 10 rods for 1 flat.

> **Say this:** "Now the hundreds. 3 + 2 = 5, plus the 1 we carried = 6 hundreds. No trade needed."

> **Say this:** "Answer: 632. And here's the thing — that trading you just did with blocks? That's called REGROUPING. When you have too many in one column, you regroup — trade 10 of the smaller for 1 of the bigger. It's exactly what place value is: 10 ones = 1 ten, 10 tens = 1 hundred. You already knew this. Now you're using it."

---

### Guided Practice (20 min)

#### Problem 1: Addition with One Regrouping

**Context:** A Michigan apple orchard picked 2,456 apples on Monday and 1,372 apples on Tuesday. How many total?

> **Say this:** "Let's set this up with the standard algorithm. Write the numbers stacked, lined up by place value."

```
  2,456
+ 1,372
-------
```

**Step 1 — Ones:** 6 + 2 = 8. Write 8. No regrouping needed.

**Step 2 — Tens:** 5 + 7 = 12. Write 2, carry 1 to hundreds.

**Step 3 — Hundreds:** 4 + 3 + 1 (carried) = 8. Write 8.

**Step 4 — Thousands:** 2 + 1 = 3. Write 3.

**Answer:** 2,456 + 1,372 = **3,828** apples.

> **Say this:** "We only needed to regroup once — in the tens. Sometimes you regroup in one column, sometimes two, sometimes every column. The process is the same every time."

---

#### Problem 2: Addition with Multiple Regroupings

**Context:** A school collected 4,687 cans in December and 3,845 cans in January. How many total?

```
  4,687
+ 3,845
-------
```

**Step 1 — Ones:** 7 + 5 = 12. Write 2, carry 1.

**Step 2 — Tens:** 8 + 4 + 1 = 13. Write 3, carry 1.

**Step 3 — Hundreds:** 6 + 8 + 1 = 15. Write 5, carry 1.

**Step 4 — Thousands:** 4 + 3 + 1 = 8. Write 8.

**Answer:** 4,687 + 3,845 = **8,532** cans.

> **Say this:** "Three regroupings in one problem. Every single column except the last one needed a trade. This is why lining up your digits matters — if your columns are crooked, you'll add the wrong digits together."

---

#### Problem 3: 5-Digit Addition

**Context:** The Detroit Zoo had 34,582 visitors in June and 27,649 visitors in July. How many visitors total?

```
  34,582
+ 27,649
--------
```

**Step 1 — Ones:** 2 + 9 = 11. Write 1, carry 1.

**Step 2 — Tens:** 8 + 4 + 1 = 13. Write 3, carry 1.

**Step 3 — Hundreds:** 5 + 6 + 1 = 12. Write 2, carry 1.

**Step 4 — Thousands:** 4 + 7 + 1 = 12. Write 2, carry 1.

**Step 5 — Ten-thousands:** 3 + 2 + 1 = 6. Write 6.

**Answer:** 34,582 + 27,649 = **62,231** visitors.

> **Say this:** "Five-digit addition. Same algorithm. Same process. Column by column, right to left, regroup when the sum is 10 or more. If you can do this, you can add ANY numbers. The algorithm works for 3-digit, 5-digit, 10-digit — it scales."

---

### Independent Practice (20 min)

> **Say this:** "Five problems. Use grid paper to keep your digits aligned. Show all your work — write the carried digits above the columns. Use your blocks if you need to."

**Problem 1** (Easy — no regrouping)

3,241 + 2,537 = _____

---

**Problem 2** (Easy — one regrouping)

5,463 + 2,178 = _____

---

**Problem 3** (Medium — multiple regroupings)

6,794 + 4,538 = _____

---

**Problem 4** (Medium — 5-digit)

23,467 + 18,855 = _____

---

**Problem 5** (Hard — context)

The population of Kalamazoo is 72,786. The population of Battle Creek is 51,247. What is their combined population?

---

### Answer Key

**Problem 1:** 3,241 + 2,537 = **5,778**. No regrouping needed.

**Problem 2:** 5,463 + 2,178 = **7,641**. Regroup in ones (3+8=11) and hundreds (4+1+1=6... wait: 4+1=5, no regroup. Ones: 3+8=11, regroup. Tens: 6+7+1=14, regroup. Hundreds: 4+1+1=6. Thousands: 5+2=7). **7,641**.

**Problem 3:** 6,794 + 4,538 = **11,332**. Ones: 4+8=12, carry 1. Tens: 9+3+1=13, carry 1. Hundreds: 7+5+1=13, carry 1. Thousands: 6+4+1=11, carry 1. Ten-thousands: 1. Answer: **11,332**.

**Problem 4:** 23,467 + 18,855 = **42,322**. Ones: 7+5=12, carry 1. Tens: 6+5+1=12, carry 1. Hundreds: 4+8+1=13, carry 1. Thousands: 3+8+1=12, carry 1. Ten-thousands: 2+1+1=4. Answer: **42,322**.

**Problem 5:** 72,786 + 51,247 = **124,033**. Ones: 6+7=13, carry 1. Tens: 8+4+1=13, carry 1. Hundreds: 7+2+1=10, carry 1. Thousands: 2+1+1=4. Ten-thousands: 7+5=12, carry 1. Hundred-thousands: 1. Answer: **124,033**.

---

### Beast Academy Challenge (10 min)

> **Say this:** "This one makes you think about addition differently."

**The Puzzle:**

Fill in the missing digits to make this addition correct:

```
  _ , 8 _ 7
+ 2 , _ 5 _
-----------
  9 , 3 1 3
```

**Solution:**

Work column by column:
- Ones: 7 + _ = 13 (since we need 3 in ones and must carry 1). Missing digit = **6**.
- Tens: _ + 5 + 1 (carried) = 11 (write 1, carry 1). So _ + 6 = 11, _ = **5**. Wait: _ + 5 + 1 = 11, so _ = **5**.
- Hundreds: 8 + _ + 1 (carried) = 13 (write 3, carry 1). So 9 + _ = 13, _ = **4**.
- Thousands: _ + 2 + 1 (carried) = 9. _ = **6**.

The complete problem: **6,857 + 2,456 = 9,313**.

Check: 6,857 + 2,456 = 9,313. Confirmed.

> **Say this:** "You solved an addition problem BACKWARDS. You used what you know about how addition works to figure out the missing pieces. That's algebraic thinking, even though we haven't called it algebra yet."

---

### Bug Check

#### Error 404: Student cannot add with regrouping at all.
Go back to 2-digit addition with blocks. Add 48 + 35. Build both with blocks. Combine the ones: 8 + 5 = 13. Trade 10 ones for 1 ten physically. Then count the tens: 4 + 3 + 1 = 8. Answer: 83. Repeat with three more 2-digit problems. Then move to 3-digit. Do not jump to 4-digit until 2-digit is solid.

#### Error 500: Student regroups but puts the carried digit in the wrong column.
This is a placement error. Draw the place value columns on the grid paper with labels: Th | H | T | O. Write the carried digit ABOVE the correct column header. Color-code: write carried digits in red, regular digits in pencil. The visual distinction helps prevent column confusion.

#### Syntax Error: Student gets the concept but makes arithmetic errors in the column sums.
Slow down. Have them say the column sum out loud before writing it. "7 plus 5 is 12. Write 2, carry 1." If they consistently miscalculate, practice basic addition facts (sums to 18) with flashcards for 5 minutes before the lesson. Speed and accuracy with single-digit addition is the engine that drives the algorithm.

---

## Block 2: Science (45 min) — Energy Conversions

**Standard:** 4-PS3-3 — Ask questions and predict outcomes about the changes in energy that occur when objects collide.
**ELA Integration:** 4.RI.3 (explaining scientific concepts), 4.W.2 (informative writing), 4.SL.1 (discussion)

---

### Hook (5 min)

Rub your hands together vigorously for 10 seconds. Then press your palms against your cheeks.

> **Say this:** "Feel that? Your hands are warm. But wait — you didn't put them near a fire. You didn't hold a hot cup. Where did the heat come from?"

*(From rubbing them together.)*

> **Say this:** "You moved your hands back and forth — that's MOTION energy. And the motion turned into HEAT. The energy didn't disappear — it CHANGED FORM. That's called energy conversion. Motion became heat. And that's everywhere."

---

### Lesson (15 min)

> **Say this:** "So far in science, we've learned that energy can TRANSFER — move from one object to another. Today we learn something new: energy can also CONVERT — change from one form to another. Let me show you what I mean."

Write these five forms of energy on the board (or in the science journal):

| Form | What It Looks Like |
|------|-------------------|
| **Light** | Sunshine, lightbulbs, screens |
| **Heat (thermal)** | Warmth from a fire, the sun, friction |
| **Sound** | Music, thunder, voices, a bell ringing |
| **Motion (kinetic)** | Anything moving — cars, wind, a ball rolling |
| **Electrical** | Batteries, outlets, lightning |

> **Say this:** "Energy is constantly converting between these forms. Watch."

**Demonstration 1: Clap your hands.**

> **Say this:** "I moved my hands toward each other — that's motion energy. They collided and made a noise — that's sound energy. Motion converted to sound. Clap your hands. You just converted energy."

**Demonstration 2: Turn on a flashlight.**

> **Say this:** "This flashlight runs on batteries — electrical energy. When I switch it on, the electrical energy converts to LIGHT energy. But put your hand in front of the beam for a few seconds. Feel anything?"

*(It feels a little warm.)*

> **Say this:** "Electrical energy converted to light AND heat. Most conversions produce heat as a side effect. A lightbulb makes light, but it also gets hot. A car engine makes motion, but it also gets hot. Energy conversion is never perfectly clean — some energy always becomes heat."

Write the conversion chains:
- **Hands rubbing:** Motion → Heat
- **Clapping:** Motion → Sound (+ Heat)
- **Flashlight:** Electrical → Light + Heat
- **Drum:** Motion → Sound (+ Heat)

> **Say this:** "See the pattern? Energy starts as one form and ends as another. That arrow means 'converts to.' The starting form is the input. The ending form is the output."

---

### Activity: Three Energy Conversion Stations (20 min)

Set up three mini-experiments. The student spends about 5 minutes at each.

#### Station 1: Light to Heat (7 min)

**Materials:** Flashlight, dark paper, light paper.

1. Turn the flashlight on and hold it 2 inches above the dark paper for 60 seconds.
2. Touch the paper. Note how it feels.
3. Do the same with the light (white) paper for 60 seconds.
4. Touch it. Compare.

> **Say this:** "Which paper got warmer?"

*(The dark paper should feel noticeably warmer.)*

> **Say this:** "Dark surfaces absorb more light energy and convert it to heat. Light surfaces reflect more light and absorb less. That's why wearing a black shirt on a sunny day feels hotter than wearing a white shirt. The black fabric converts more light energy into heat."

**Write in journal:** "At Station 1, I observed that light energy converts to _____ energy. The dark paper absorbed more light and got _____ than the white paper."

#### Station 2: Motion to Sound (7 min)

**Materials:** Rubber band, small cardboard box.

1. Stretch the rubber band over the open side of the box (like a single guitar string over a sound hole).
2. Pluck the rubber band.
3. Observe: what do you see? What do you hear?

> **Say this:** "What happened when you plucked it?"

*(It vibrated and made a sound.)*

> **Say this:** "Your finger gave the rubber band motion energy. The rubber band vibrated — that vibration is motion energy in a back-and-forth pattern. Those vibrations traveled through the air and reached your ear as SOUND. Motion converted to sound. And the box made it louder by amplifying the vibrations — the hollow space inside let the sound waves bounce around and get bigger."

> **Say this:** "Try this: pluck it gently, then pluck it hard. What changes?"

*(Louder sound when plucked harder.)*

> **Say this:** "More motion energy = more sound energy. Same conversion, bigger input, bigger output."

**Write in journal:** "At Station 2, I observed that _____ energy converts to _____ energy. When I plucked harder, the sound was _____ because I put in more _____ energy."

#### Station 3: Motion to Sound and Heat (6 min)

**Materials:** Metal pan, marble.

1. Drop the marble onto the metal pan from about 6 inches.
2. Listen to the sound. Feel the pan immediately after.
3. Drop the marble from 12 inches. Compare the sound.

> **Say this:** "The marble was moving — kinetic energy. It hit the pan. What happened?"

*(It made a sound, and the sound was louder when dropped from higher.)*

> **Say this:** "Motion converted to sound through the collision. And if you touched the spot where the marble hit, it might feel very slightly warm — some motion energy also converted to heat. Higher drop = more kinetic energy = louder sound. Same principle as the ramp experiment from Week 1."

**Write in journal:** "At Station 3, the marble's _____ energy converted to _____ energy when it hit the pan. A higher drop meant more _____ energy and a _____ sound."

---

### Discussion (5 min)

> **Ask:** "Can you think of a device in your house that converts energy from one form to another? What form does it start with, and what form does it end with?"

**Listen for:** Clear identification of input and output forms. Strong answers:
- TV: electrical → light + sound
- Toaster: electrical → heat
- Speaker: electrical → sound
- Fan: electrical → motion
- Microwave: electrical → heat

> **If student struggles:** "Think about when you turn on a lamp. What kind of energy goes IN? What comes OUT?"

---

## Discussion Lunch

> **"Here's a wild question: when you eat food, your body turns it into energy to move, think, and stay warm. What kind of energy conversion is that? Food energy → _____ ? Can you think of more than one output?"**

*(Food energy converts to motion, heat, and even electrical signals in the brain. This is a real and important conversion chain. Let them explore the idea.)*

---

## End of Day

> **Say this:** "Today you added numbers in the thousands and you proved that energy doesn't just transfer — it CONVERTS. Light becomes heat. Motion becomes sound. Every device you use runs on energy conversion. Tomorrow, we tackle subtraction. And then we learn about the Anishinaabe — the people who lived in Michigan for thousands of years before anyone else. Big day coming."

---

© 2026 Root Access Learning OS. All rights reserved.
