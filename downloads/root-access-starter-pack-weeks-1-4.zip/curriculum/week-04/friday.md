# Week 04 — Friday Lesson Plan

## Open Source: Day 3

**Grade:** 4 | **Standards:** 4.NBT.4, 4.OA.3, 4-H3.0.2, 4-PS3-4, 4.W.2, 4.W.4, 4.SL.1
**Total instructional time:** ~3 hours (Math + Social Studies + Coding + Discussion Lunch)

## Parent Pre-Read (5 min)

Today wraps Week 4 and the first full month of Root Access. Math today includes complex word problems and an informal end-of-unit check for addition and subtraction fluency. Social studies covers European contact with the Three Fires Confederacy — framed honestly, with Anishinaabe agency front and center. Science returns briefly with the sound amplifier redesign. The coding block introduces conditionals (if/then logic) in Scratch. This is a big day. Your student should feel genuinely confident by the end of it.

---

## Morning Work (15 min)

> **Say this:** "Last warm-up of the week. Two problems."

### Quick Review (8 min)

**1.** A store had 23,405 items. On Monday, they sold 4,832 items. On Tuesday, they received a shipment of 6,215 new items. How many items does the store have now?

**2.** Without solving, estimate whether the answer to this problem will be greater or less than 10,000: 15,430 - 6,872. Explain your reasoning, then solve to check.

#### Answers

| # | Answer | Notes |
|---|--------|-------|
| 1 | 23,405 - 4,832 = 18,573. Then 18,573 + 6,215 = **24,788** items. |
| 2 | Estimate: 15,000 - 7,000 = 8,000. So the answer should be LESS than 10,000. Actual: 15,430 - 6,872 = **8,558**. Confirmed — less than 10,000. |

### Journal (7 min)

**Prompt:** *"This is the end of your fourth week. Think about where you started and where you are now in math. What can you do now that you could not do a month ago? What was the hardest thing you learned? What are you most proud of?"*

---

## Block 1: Math (60 min) — Complex Word Problems and End-of-Unit Check

### Today's Objective

Student can solve complex multi-step word problems, identify and handle extra or missing information, and demonstrate fluency with multi-digit addition and subtraction.

### Standards
- **4.NBT.4:** Fluently add and subtract multi-digit whole numbers using the standard algorithm
- **4.OA.3:** Solve multistep word problems posed with whole numbers
- **4.SL.1:** Collaborative discussion

---

### Launch (10 min)

> **Say this:** "All week, you've been solving word problems — one-step, two-step, three-step. Today, the problems are even more interesting. Some have information you don't need. One problem won't give you ENOUGH information — you'll have to figure out what's missing. And at the end, you'll write your OWN word problem. Ready?"

Write on the board:

**Today's Challenges:**
- Problems with extra information (distractors)
- A problem with MISSING information
- Writing your own word problem

> **Say this:** "Let's start with something new: a problem that CANNOT be solved as written."

Read aloud: "A teacher bought supplies for her classroom. She bought pencils for $34 and notebooks for some amount. How much did she spend in total?"

> **Say this:** "Can you solve this?"

*(No — we do not know the cost of the notebooks.)*

> **Say this:** "Exactly. The information is INCOMPLETE. In real life, this happens all the time. You start solving a problem and realize you're missing something. A good problem-solver notices that and asks for the missing information instead of guessing."

---

### Guided Practice (20 min)

#### Problem 1: Extra Information — What Matters?

**Problem:** A Michigan cherry farm produced 34,250 pounds of cherries this year. Last year they produced 28,475 pounds. The farm has 15 employees and has been in business for 42 years. How many MORE pounds of cherries did they produce this year compared to last year?

> **Say this:** "What numbers do you need? What numbers are distractors?"

**Needed:** 34,250 and 28,475. **Distractors:** 15 employees and 42 years.

**Solution:** 34,250 - 28,475 = **5,775** more pounds.
Ones: 0-5, borrow, 10-5=5. Tens: 4-7 (5→4 after borrow), borrow, 14-7=7. Hundreds: 1-4 (2→1 after borrow), borrow, 11-4=7. Thousands: 3-8 (4→3 after borrow), borrow, 13-8=5. Ten-thousands: 2 (3→2 after borrow).

**Check:** 34,000 - 28,000 = 6,000. Answer (5,775) is close. Reasonable.

---

#### Problem 2: Missing Information

**Problem:** A school wants to buy new desks. Each desk costs $85. They have $2,500 in their budget. How many desks can they buy?

> **Say this:** "This problem requires division — which we haven't studied yet. So you can't fully solve it with the tools you have right now. But you CAN do this: you know each desk is $85. Can you figure out how much 10 desks would cost? What about 20? What about 30?"

**Approach using repeated addition:**
- 10 desks: $85 x 10 = **$850**
- 20 desks: $85 x 20 = **$1,700**
- 30 desks: $85 x 30 = **$2,550** — that's more than $2,500.
- 29 desks: $2,550 - $85 = **$2,465** — that fits.

**Answer:** They can buy **29 desks** and have $35 left over. ($2,500 - $2,465 = $35.)

> **Say this:** "You solved a division problem without knowing how to divide — you used repeated addition and subtraction to narrow it down. That is mathematical reasoning. When you learn division later, you'll have a shortcut. But the thinking you just did IS the foundation of division."

---

#### Problem 3: Write Your Own

> **Say this:** "Now YOU write a word problem. It must meet these requirements:"

1. Use numbers in the thousands or larger
2. Require at least two steps (two operations)
3. Include one piece of extra information that is not needed to solve the problem
4. Have a clear question at the end
5. Include a complete solution with answer

Give the student 5-7 minutes. Then have them read their problem aloud to you and solve it together.

**Evaluation criteria:**
- Does the problem make sense?
- Are there at least two steps?
- Is the extra information truly unnecessary for the solution?
- Is the solution correct?

---

### Independent Practice (20 min) — End-of-Unit Check

> **Say this:** "This is your end-of-unit check. Five problems that test everything you've learned about addition and subtraction over the past two weeks. Take your time. Show all your work. Check each answer with estimation."

**Problem 1** (Computation — addition)

47,683 + 35,849 = _____

---

**Problem 2** (Computation — subtraction)

60,004 - 27,358 = _____

---

**Problem 3** (Word problem — one-step)

Michigan's state park system has 103 state parks and recreation areas covering 306,418 acres. If 127,645 of those acres are in the Upper Peninsula, how many acres are in the Lower Peninsula?

---

**Problem 4** (Word problem — two-step)

A charity set a goal of raising $50,000. In the first month, they raised $18,475. In the second month, they raised $23,840. How much MORE do they need to reach their goal?

---

**Problem 5** (Word problem — three-step with extra information)

A bookstore chain has 3 locations. Location A sold 15,847 books last year. Location B sold 12,396 books. Location C, which has 8 employees, sold 18,230 books. The chain spent $22,500 on advertising. How many books did the chain sell in total? How many more books did Location C sell than Location B?

---

### Answer Key

**Problem 1:** 47,683 + 35,849 = **83,532**
Ones: 3+9=12, carry 1. Tens: 8+4+1=13, carry 1. Hundreds: 6+8+1=15, carry 1. Thousands: 7+5+1=13, carry 1. Ten-thousands: 4+3+1=8.

**Problem 2:** 60,004 - 27,358 = **32,646**
This is a chain-borrow problem. Ones: 4-8, borrow. Tens is 0, hundreds is 0, thousands is 0 — chain borrow from ten-thousands. 6→5, thousands 0→10→9, hundreds 0→10→9, tens 0→10→9, ones 4→14.
Ones: 14-8=6. Tens: 9-5=4. Hundreds: 9-3=6. Thousands: 9-7=2. Ten-thousands: 5-2=3.

**Problem 3:** 306,418 - 127,645 = **178,773** acres in the Lower Peninsula.
(The 103 parks detail is extra context, not needed for the calculation.)

**Problem 4:** Step 1: 18,475 + 23,840 = **42,315** raised so far. Step 2: 50,000 - 42,315 = **$7,685** more needed.

**Problem 5:** Part 1: 15,847 + 12,396 + 18,230 = **46,473** total books. (8 employees and $22,500 advertising are irrelevant.) Part 2: 18,230 - 12,396 = **5,834** more books at Location C.

---

### Beast Academy Challenge (10 min)

> **Say this:** "One last puzzle for the unit."

**The Puzzle:**

A number is called a "palindrome" if it reads the same forward and backward (like 12321 or 45654).

Find the SMALLEST 5-digit palindrome where the digit sum equals 10.

**Solution:**

A 5-digit palindrome has the form ABCBA. The digit sum is A + B + C + B + A = 2A + 2B + C = 10.

For the smallest number, we want the smallest possible first digit. The smallest first digit for a 5-digit number is 1.

If A = 1: 2(1) + 2B + C = 10 → 2B + C = 8.
For the smallest number, we want B as small as possible. B = 0: C = 8. Number: **10801**.
Check: 1+0+8+0+1 = 10. Reads same forwards and backwards. Is a 5-digit number.

**Answer:** **10801**.

> **Say this:** "Palindromes are numbers (or words) that read the same forward and backward. You combined that idea with digit sums to find the answer. Pattern recognition, constraint satisfaction, and number sense — all in one problem."

---

### Bug Check

- **Error 404**: If the student cannot solve the end-of-unit problems, they need more practice with the algorithm itself before continuing to word problems. Go back to Wednesday of Week 3 and rework the guided problems. Do not move on until 4-digit addition and subtraction with regrouping is solid.

- **Error 500**: Student computes correctly but writes incomplete answers. "178,773" is not a complete answer — "178,773 acres are in the Lower Peninsula" is. Push for contextual answers every time.

- **Syntax Error**: Student makes arithmetic errors under time pressure. Have them slow down. Speed will come with practice. Accuracy matters more than speed at this stage.

---

## Block 2: Social Studies (45 min) — The Three Fires Confederacy: European Contact

**Standards:** 4-H3.0.2, 4.W.2, 4.W.4, 4.SL.1

---

### Hook (5 min)

> **Say this:** "Yesterday, you learned about the Three Fires Confederacy — how the Ojibwe, Odawa, and Potawatomi governed together through consensus, used diplomatic tools like wampum and gift exchange, and maintained relationships with nations across the region. Today, we learn about what happened when a NEW set of people arrived: Europeans. Specifically, the French."

> **Ask:** "If strangers showed up in your neighborhood and wanted to trade with you — they have things you've never seen before, and you have things they want — how would you handle it? Would you trust them right away?"

*(Let them discuss.)*

> **Say this:** "The Anishinaabe faced exactly this situation in the early 1600s. And they handled it with sophistication."

---

### Lesson (15 min)

> **Say this:** "When French explorers and fur traders arrived in the Great Lakes region in the early 1600s, they did not enter an empty wilderness. They entered a political landscape — a place with existing nations, existing trade routes, existing alliances, and existing rules."

> **Say this:** "The Anishinaabe — especially the Odawa, who were already master traders — did not simply accept whatever the French offered. They NEGOTIATED. They set terms. They decided who could trade and where. The French needed the Anishinaabe far more than the Anishinaabe needed the French, at least in the beginning."

**[PAUSE]**

> **Say this:** "Here's what the French wanted: FURS. Beaver fur in particular was extremely valuable in Europe — it was used to make hats and clothing that wealthy Europeans demanded. The Great Lakes region had vast numbers of beavers. The French did not have the knowledge, the skills, or the relationships to trap and process beaver furs on their own. They needed Indigenous hunters and traders."

> **Say this:** "And here's what the Anishinaabe wanted: METAL TOOLS. Iron knives, steel axes, copper kettles — these were stronger and more durable than stone tools. The French also brought cloth, beads, and eventually firearms. These were desirable trade goods."

Write on the board:

| What the French Wanted | What the Anishinaabe Wanted |
|----------------------|---------------------------|
| Beaver furs | Iron knives, steel axes |
| Other animal furs | Copper kettles |
| Access to trade networks | Cloth and woven blankets |
| Guides and interpreters | Glass beads |
| Military alliances | Firearms (later) |

> **Say this:** "Notice: this was a TWO-WAY exchange. Both sides had something the other wanted. The Anishinaabe were not victims of trade — they were PARTNERS in trade. The Odawa in particular leveraged their existing trade networks. They became intermediaries — middle traders who connected French goods to nations farther west."

**[PAUSE]**

> **Say this:** "But there is a harder part of this story. Along with trade goods, Europeans brought DISEASES — smallpox, measles, influenza — that were completely new to Indigenous peoples. Because these diseases had never existed in the Americas before, people had no natural immunity. The results were devastating. Entire communities were decimated. Some historians estimate that disease killed 50% to 90% of some Indigenous populations."

> **Say this:** "This was not because Indigenous people were weak. It was because these were brand-new diseases. When a disease arrives in a population that has never been exposed to it, the results are catastrophic. The same thing would have happened to Europeans if Indigenous peoples had carried diseases unknown in Europe."

> **Say this:** "The loss of so many people disrupted everything — families, governance, knowledge systems, trade networks. It changed the balance of power in the Great Lakes region. And it happened not because of war or conquest, but because of biology."

**[PAUSE]**

> **Say this:** "One more crucial point. Despite the devastation of disease and the disruptions of European contact, the Anishinaabe nations survived. They adapted. They negotiated treaties. They maintained their governance systems, their cultural practices, and their identity. The 12 federally recognized tribes in Michigan today are the direct descendants of these nations. Their sovereignty — their right to govern themselves — is legally recognized and actively exercised. This story does not end in the past."

---

### Activity (20 min)

**Part 1: Trade Comparison Chart (10 min)**

> **Say this:** "Create a two-column chart. On one side, write 'Anishinaabe Trade BEFORE European Contact' — the trade networks we studied last week. On the other side, write 'Anishinaabe Trade AFTER European Contact.' For each side, list:"

1. What goods were traded
2. How they were transported
3. Who the trading partners were
4. How trade was connected to diplomacy

**This chart should show that trade existed BEFORE Europeans arrived and was CHANGED, not created, by contact.**

**Part 2: Reflection Writing (10 min)**

> **Say this:** "Write a paragraph — 5-7 sentences — answering this question: How did European contact change life for the Anishinaabe? Your paragraph must include:"

1. At least one thing the Anishinaabe gained from trade with the French
2. At least one thing the Anishinaabe lost due to European contact
3. Evidence that the Anishinaabe were active negotiators, not passive victims
4. A statement about Anishinaabe nations today

Use the vocabulary words: **sovereignty, treaty, diplomacy**.

---

### Historical Context — A Note for the Parent

This lesson requires balance. The student needs to understand the real devastation caused by disease and colonization without being left with the impression that Indigenous peoples are defined by suffering. The Anishinaabe response to European contact was characterized by agency, adaptation, and resilience — not passivity.

Do not sugarcoat the impact of disease. But do not reduce the Anishinaabe to victims. They negotiated. They adapted. They survived. They are here.

If your student asks hard questions — "Why did Europeans bring diseases?" or "Was it fair?" — engage honestly. History is not always comfortable. The goal is understanding, not comfort.

---

### Discussion (5 min)

> **Ask:** "The Anishinaabe had sophisticated trade networks before Europeans arrived. The French plugged INTO those networks — they used systems the Odawa had already built. What does that tell you about who was really in charge of trade in the Great Lakes?"

**Listen for:** Understanding that the Anishinaabe controlled the trade infrastructure and the French depended on them. Recognition that the narrative of Europeans "bringing trade" to Indigenous peoples is incomplete — trade existed long before contact.

> **If student struggles:** "Think about it this way: if you built a lemonade stand and a new kid moved to the neighborhood and wanted to sell lemonade too, would they build their own stand or try to use yours? Who has the advantage?"

---

## Block 3: Coding (30 min) — Scratch: Conditionals (If/Then)

### Today's Project: Build a Scoring Game with Conditions

Last week, your student learned variables and built a click counter. This week, they add LOGIC — the program makes decisions using if/then blocks.

### Setup
- Open **scratch.mit.edu** and log in
- Start a new project (or build on last week's click counter)

### Instructions

> **Say this:** "Last week, your Scratch program could REMEMBER things — using variables. But it couldn't DECIDE things. It couldn't say 'if the score reaches 10, you win.' Today, you teach the program to make decisions. That's called a conditional — an IF/THEN statement."

**Step 1: Set Up the Game (5 min)**

1. Create a variable called **"Score"** (or use the one from last week).
2. Add the click-counter code from last week: **when this sprite clicked → change Score by 1**.
3. Add the random movement from last week's challenge: **go to x: (pick random -200 to 200) y: (pick random -150 to 150)**.
4. Add **when green flag clicked → set Score to 0**.

> **Say this:** "This is your game from last week — click the cat, score goes up, cat moves. Now we add a WIN condition."

**Step 2: Add a Conditional — Win at 10 (10 min)**

1. From **Control**, drag **"if < > then"** block into the scripting area.
2. From **Operators**, drag **"[ ] = [ ]"** into the diamond-shaped slot.
3. From **Variables**, drag **"Score"** into the first slot. Type **10** in the second slot.
4. This reads: "If Score = 10, then..."
5. Inside the if-block, add from **Looks**: **"say [You win! 10 clicks!] for 2 secs"**.
6. Add from **Control**: **"stop [all]"** — this ends the game.

Now put the **if** block INSIDE the "when this sprite clicked" stack, AFTER the change and go-to blocks.

The full script should be:
```
when this sprite clicked
  change [Score] by 1
  go to x: (pick random -200 to 200) y: (pick random -150 to 150)
  if <(Score) = (10)> then
    say [You win! 10 clicks!] for (2) secs
    stop [all]
  end
```

> **Say this:** "Test it. Click the cat 10 times. When the score hits 10, the cat says 'You win!' and the game stops. That 'if' block is the program making a DECISION. It checks the score after every click. If the score is 10, it runs the win code. If the score is NOT 10, it does nothing and waits for the next click."

**Step 3: Add a Lose Condition — Timer (10 min)**

1. Create a second variable called **"Timer"**.
2. Add a new script starting with **"when green flag clicked"**:
   - **set [Timer] to 15** (15 seconds to reach 10 clicks)
   - **repeat (15)**: inside the repeat, add **"wait 1 seconds"** then **"change [Timer] by -1"**
   - After the repeat loop, add: **if <(Score) < (10)> then → say [Time's up! You scored (Score)] for 2 secs → stop [all]**

> **Say this:** "Now you have two conditions: if the score reaches 10, you win. If the timer reaches 0 and you haven't scored 10, you lose. The program is making TWO decisions — one about the score, one about the timer. That is conditional logic."

**Step 4: Test and Play (5 min)**

Play the game three or four times. Try to win. Try to lose.

> **Say this:** "You just built a complete game with a win condition, a lose condition, a score, and a timer. The key new concept is the IF block — it lets your program make decisions. Without IF blocks, programs can only follow instructions in order. WITH IF blocks, programs can respond to what's happening. That is what makes software smart."

### Coding Vocabulary Introduced Today
- **Conditional**: A decision point — IF something is true, THEN do something
- **Boolean**: A value that is either TRUE or FALSE (like "Score = 10" — either it is or it is not)
- **Condition**: The test inside an IF block (the thing being checked)

### Extension
- Change the win score to 15 and the timer to 20. Is the game harder or easier?
- Add a **"say [Miss!] for 0.3 secs"** if the player clicks the stage (background) instead of the cat. (Hint: add a script to the Stage.)
- Add a second sprite that takes AWAY a point when clicked (change Score by -1). Now the player must click the right sprite.

---

## Discussion Lunch

> **"The Anishinaabe adapted when Europeans arrived — they incorporated new tools into their existing systems without abandoning their culture. Can you think of an example of something new entering YOUR life that you adapted to without giving up the things that were already important to you? Maybe new technology, a new school, a new neighborhood?"**

---

## End-of-Week Wrap-Up (5 min)

> **Say this:** "Week 4 is done. You just finished your first full month of Root Access. Let me tell you what you can do now."

> **Say this:** "In math: you understand place value. You can compare and round numbers. You can add and subtract multi-digit numbers with regrouping — including the hard ones with zeros. And this week, you solved word problems that required you to READ, PLAN, and CALCULATE. That is real mathematical thinking."

> **Say this:** "In science: you know what energy is. You know it can transfer between objects. You know it can convert between forms. And you BUILT a device that converts energy. You are thinking like an engineer."

> **Say this:** "In social studies: you know about the Anishinaabe — the Ojibwe, Odawa, and Potawatomi. You learned about the Seasonal Round, the Three Fires Confederacy, consensus governance, diplomatic tools, trade networks, and European contact. You know more about Michigan's Indigenous history than most adults. That matters."

> **Say this:** "In coding: you can make things move, respond to events, use variables, and now — make decisions with IF/THEN blocks. Your programs are getting smarter every week."

> **Say this:** "Four weeks in. You're not just getting started anymore. You are IN IT. See you next week."

---

## Homework

See homework.md for this week's assignments.

---

## Materials Checklist

- [ ] Math journal, grid paper, pencil
- [ ] Dry-erase board or scratch paper
- [ ] Lined paper for writing
- [ ] Student's Three Fires Confederacy diagram from Thursday
- [ ] Colored pencils and markers
- [ ] Computer or tablet with internet (for Scratch)
- [ ] Rubber band, small box, and additional craft materials (for sound amplifier — if doing the science extension)

---

*Root Access Learning OS — Week 04 of 36*

© 2026 Root Access Learning OS. All rights reserved.
