# Week 04 — Homework

*All homework reinforces what was learned during the day's lesson — never introduces new concepts. If your student is struggling with an assignment, that is a signal to revisit the topic during the next lesson. Homework should take roughly 30 minutes per night (15 min math + 15 min reading/writing). The weekend project is flexible — 30 minutes total, done whenever it fits your family's schedule.*

---

## Wednesday Homework

### Math Practice (15 min)

**Directions:** Complete these four word problems in your math notebook. For EACH problem, write: (1) What do I know? (2) What am I looking for? (3) What operation(s) do I need? Then solve and check with estimation.

**1.** A farmer harvested 8,347 ears of corn from one field and 6,258 ears from another field. How many ears of corn did the farmer harvest in total?

**2.** A store had 15,200 items in stock. They sold 4,836 items during a sale. How many items are left?

**3.** A family drove 347 miles on Saturday and 289 miles on Sunday. Their car gets 28 miles per gallon. How many total miles did they drive over the weekend?

**4.** A school library has 12,485 books. They received a donation of 3,750 books and then removed 1,230 old books. How many books does the library have now?

---

### Reading/Writing (15 min)

**Journal Prompt:** *You built a solar oven (light-to-heat concentrator) in science today. Write a paragraph (at least 5 sentences) explaining how your device works. Your paragraph must include:*
- *The words "energy conversion" and "prototype"*
- *What form of energy goes IN and what form comes OUT*
- *What the aluminum foil does and why*
- *One thing you would change if you rebuilt the device*

This is informative writing — you are explaining a design to someone who has never seen it. Be specific about how the device works, not just what it looks like.

---

## Thursday Homework

### Math Practice (15 min)

**Directions:** Complete these four problems. At least two are multi-step. Watch for extra information.

**1.** The Grand Traverse Band of Ottawa and Chippewa Indians operates a cultural center that welcomed 24,580 visitors last year. This year, they welcomed 31,247 visitors. The cultural center has been open for 18 years. How many MORE visitors came this year than last year?

**2.** A bakery made 4,500 cookies for a festival. They sold 2,875 on Saturday and 1,340 on Sunday. How many cookies are left?

**3.** Three Michigan cities have these populations: Lansing — 112,644. Ann Arbor — 123,851. Flint — 87,092. What is the combined population of all three cities? Which city has the smallest population?

**4.** A student read 1,245 pages in October, 1,870 pages in November, and 985 pages in December. The student owns 47 books. How many total pages did the student read? How many MORE pages did they read in November than December?

---

### Reading/Writing (15 min)

**Writing Prompt:** *Write a paragraph (5-7 sentences) explaining how the Three Fires Confederacy made decisions. Your paragraph must answer these questions:*
- *What is consensus, and how is it different from voting?*
- *What role did each of the three nations play in council meetings?*
- *What is one advantage of consensus decision-making?*
- *What is one disadvantage?*

Use the vocabulary words: **consensus, confederacy, sovereignty, diplomacy**. (You do not have to use all four, but try to use at least three.)

---

## Friday Homework

### Weekend Project: Four-Week Reflection Journal (30 min total, flexible)

**The Assignment:** You have now completed four weeks of Root Access. This weekend, create a reflection journal entry that looks back at everything you have learned.

**Your reflection should have three sections:**

**Section 1: What I Learned (10 min)**
Write at least 3 paragraphs — one about math, one about science, and one about social studies. In each paragraph, explain:
- What is the MOST IMPORTANT thing you learned in that subject over the past four weeks?
- What was the HARDEST thing to learn?
- What are you most PROUD of?

**Section 2: Connections (10 min)**
Write 1 paragraph about connections between subjects. Did anything you learned in science help you understand social studies? Did math show up in unexpected places? Did the Anishinaabe Seasonal Round connect to what you learned about energy? Look for at least 2 connections.

**Section 3: Questions I Still Have (10 min)**
Write at least 3 questions you still have — things you want to learn more about. These can be about ANY subject. There are no wrong questions. Write them as full, specific questions, not just topics.

**Format:** Use lined paper. Write in complete sentences. This is formal writing — check your grammar, spelling, and punctuation.

---

## Answer Keys

### Wednesday Math

**1.** 8,347 + 6,258 = **14,605** ears of corn.
Ones: 7+8=15, carry 1. Tens: 4+5+1=10, carry 1. Hundreds: 3+2+1=6. Thousands: 8+6=14.
Check: 8,000 + 6,000 = 14,000. Answer (14,605) is close.

**2.** 15,200 - 4,836 = **10,364** items left.
Ones: 0-6, borrow, 10-6=4. Tens: 9-3=6 (was 0→borrow from hundreds: 2→1, tens 0→10, then 10→9 for ones borrow). Hundreds: 1-8, borrow, 11-8=3. Thousands: 4-4=0 (was 5, then 4 after borrow). Ten-thousands: 1.
Check: 15,000 - 5,000 = 10,000. Answer (10,364) is close.

**3.** 347 + 289 = **636** miles total. The "28 miles per gallon" is extra information — it is not needed to find the total distance.
Check: 350 + 290 = 640. Answer (636) is close.
*(Common error: student tries to use the 28 miles per gallon. Ask: "What is the question asking? Just how many miles they drove — not how much gas they used.")*

**4.** Step 1: 12,485 + 3,750 = **16,235**. Step 2: 16,235 - 1,230 = **15,005** books.
Check: 12,000 + 4,000 = 16,000. 16,000 - 1,000 = 15,000. Answer (15,005) is close.

---

### Thursday Math

**1.** 31,247 - 24,580 = **6,667** more visitors. The "18 years" is extra information.
Ones: 7-0=7. Tens: 4-8, borrow, 14-8=6. Hundreds: 1-5 (2→1 after borrow), borrow, 11-5=6. Thousands: 0-4 (1→0 after borrow), borrow, 10-4=6. Ten-thousands: 2 (3→2 after borrow).

**2.** Step 1: 2,875 + 1,340 = **4,215** sold total. Step 2: 4,500 - 4,215 = **285** cookies left.

**3.** Part 1: 112,644 + 123,851 + 87,092 = **323,587** combined population.
(112,644 + 123,851 = 236,495. Then 236,495 + 87,092 = 323,587.)
Part 2: Flint (87,092) has the smallest population.

**4.** Part 1: 1,245 + 1,870 + 985 = **4,100** total pages. The "47 books" is extra information.
(1,245 + 1,870 = 3,115. Then 3,115 + 985 = 4,100.)
Part 2: 1,870 - 985 = **885** more pages in November than December.

---

### Friday Weekend Project — Success Criteria

There is no single right answer. Use these criteria to evaluate:

- [ ] **Section 1 — Content:** Three paragraphs covering math, science, and social studies. Each paragraph names something specific learned, identifies the hardest topic, and states what the student is proud of.
- [ ] **Section 2 — Connections:** At least 2 genuine connections between subjects are identified and explained. (Weak: "I used math in science." Strong: "The Anishinaabe followed the Seasonal Round based on careful observation of nature, which is similar to how scientists observe energy patterns — both are about noticing what happens and making plans based on evidence.")
- [ ] **Section 3 — Questions:** At least 3 specific, well-formed questions. (Weak: "I want to know more about math." Strong: "How did the Anishinaabe decide where to place their sugar camps each spring? Did the locations change from year to year?")
- [ ] **Writing quality:** Complete sentences, checked grammar and spelling, organized with clear sections
- [ ] **Effort:** The reflection shows genuine thought — not just surface-level summaries, but real engagement with what was learned

**If the student goes above and beyond:** They identify connections between coding and other subjects (e.g., "Variables in Scratch are like place value — they hold a value that can change"), ask questions that connect to future learning, or express genuine curiosity about a topic they want to explore deeper. Celebrate that.

**If the student struggles:** Start with conversation. Ask them: "What do you remember from math in Week 1? What about science?" Write their answers on a whiteboard as they talk. Then say: "Now write that down, but in complete sentences." Some students can articulate ideas orally before they can write them. Meet them where they are.

---

*Root Access Learning OS — Week 04 of 36*

© 2026 Root Access Learning OS. All rights reserved.
