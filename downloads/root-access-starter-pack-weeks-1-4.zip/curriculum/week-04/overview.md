# Week 04 — Open Source

*Sharing knowledge. Building on what others built. Connected systems.*

## Week Summary

Your student has spent three weeks building skills: place value, comparing, rounding, addition, subtraction, energy basics, energy conversion, Michigan geography, and an introduction to the Anishinaabe. This week, everything connects. In math, they apply addition and subtraction to multi-step word problems — the kind that require reading, reasoning, and choosing the right operations. In science, they design solutions to energy transfer problems, moving from observation to engineering. In social studies, they go deeper into the Three Fires Confederacy — its political structures, diplomatic practices, and the sophisticated systems that governed life in the Great Lakes region before European contact. The theme is Open Source: the idea that knowledge is meant to be shared, that systems work best when they are connected, and that building on what others built is not cheating — it is how civilizations advance.

## Standards Covered This Week

| Subject | Standard Code | Standard Description | Day(s) |
|---------|--------------|----------------------|--------|
| Math | 4.NBT.4 | Fluently add and subtract multi-digit whole numbers using the standard algorithm | W, Th, F |
| Math | 4.OA.3 | Solve multistep word problems posed with whole numbers using the four operations | W, Th, F |
| Science | 4-PS3-4 | Apply scientific ideas to design, test, and refine a device that converts energy from one form to another | W, F |
| Social Studies | 4-H3.0.2 | Use primary and secondary sources to explain how life in Michigan changed from the era of the Three Fires Confederacy through early European contact | Th, F |
| ELA | 4.RI.1 | Refer to details and examples in a text when explaining what the text says explicitly and when drawing inferences | Th |
| ELA | 4.RI.3 | Explain events, procedures, ideas, or concepts in a historical, scientific, or technical text | W, Th |
| ELA | 4.W.2 | Write informative/explanatory texts to examine a topic and convey ideas and information clearly | W, Th |
| ELA | 4.W.4 | Produce clear and coherent writing appropriate to task, purpose, and audience | W, Th, F |
| ELA | 4.SL.1 | Engage effectively in a range of collaborative discussions | W, Th, F |
| ELA | 4.L.1-3 | Demonstrate command of conventions of standard English | W, Th, F |

## Materials Needed

### Math (all three days)
- [ ] Math journal (continuing from Weeks 1-3)
- [ ] Pencil and eraser
- [ ] Grid paper or lined paper with wide spacing
- [ ] Dry-erase board or scratch paper
- [ ] Base-ten blocks (for backup — most students should be working abstractly by now)

### Science (Wednesday and Friday)
- [ ] Cardboard (a cereal box or shipping box)
- [ ] Aluminum foil
- [ ] Tape and scissors
- [ ] A small lamp or flashlight
- [ ] A thermometer (any kind — cooking, medical, or weather)
- [ ] Dark paper and light paper (from Week 3 — reuse)
- [ ] Rubber band and small box (from Week 3 — reuse)
- [ ] Science journal or notebook

### Social Studies (Thursday and Friday)
- [ ] Lined paper for writing
- [ ] Colored pencils or markers
- [ ] Student's Anishinaabe Life poster from Week 3 (for reference)
- [ ] Student's Michigan map from previous weeks
- [ ] Large blank paper (for Three Fires Confederacy diagram)

### General
- [ ] Timer or phone with timer
- [ ] Snack for Discussion Lunch

## Schedule at a Glance

| | Wednesday | Thursday | Friday |
|---|-----------|----------|--------|
| **Block 1** | Math: Word Problems (Addition & Subtraction) | Math: Multi-Step Word Problems | Math: Complex Word Problems + Assessment |
| **Block 2** | Science: Designing Energy Solutions | Social Studies: Three Fires Confederacy — Political Systems | Social Studies: Three Fires Confederacy — Diplomacy & Contact |
| **Block 3** | — | — | Coding: Scratch — Conditionals (If/Then) |
| **Notes** | Engineering design process introduced. | Deep dive into Anishinaabe governance. | End-of-unit math check. Coding adds logic. |

## Parent Notes

**This is the week where thinking matters more than calculating.**

The math this week is word problems — which means reading comprehension, logical reasoning, and operation selection are just as important as the arithmetic itself. Many students who can add and subtract fluently on paper stumble when they have to figure out WHAT to add or subtract. That is normal. The skill here is not just computation — it is problem-solving.

- **Word problems require a different kind of thinking.** The student must read the problem, identify what is being asked, decide which operation(s) to use, set up the problem, solve it, and check whether the answer makes sense. That is a multi-step cognitive process. Be patient with it.

- **Multi-step problems are new this week.** Problems that require two or more operations — like "Marcus earned $3,500 in June and $4,200 in July. He spent $2,850 on rent. How much does he have left?" — are significantly harder because the student must plan their approach before calculating.

- **The social studies this week continues the Anishinaabe deep dive.** This week focuses on the political structures of the Three Fires Confederacy — how decisions were made between nations, how diplomacy worked, and what happened when European contact began to change the balance. Present this as political science, not mythology. These were designed systems of governance.

- **Science shifts to engineering this week.** Instead of just observing energy conversions, your student will DESIGN a device that converts energy. This is the engineering design process: identify the problem, brainstorm solutions, build a prototype, test it, and refine. It does not have to be perfect — it has to show thinking.

---

*Root Access Learning OS — Week 04 of 36*

© 2026 Root Access Learning OS. All rights reserved.
