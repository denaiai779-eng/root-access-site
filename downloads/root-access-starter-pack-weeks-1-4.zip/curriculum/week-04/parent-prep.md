# Week 04 — Parent Prep

Read this before Wednesday. Budget 30 minutes. The social studies section requires careful reading — this week covers political systems and early European contact, both of which need nuance.

---

## Math Focus: Word Problems with Addition & Subtraction (4.NBT.4, 4.OA.3)

### What You're Teaching

Your student can now add and subtract multi-digit numbers with the standard algorithm. This week, they apply that skill to word problems — situations described in words where the student must figure out what to do, not just how to do it. This is where computation meets comprehension.

### The Progression Across Three Days

- **Wednesday**: One-step and two-step word problems using addition and subtraction. The focus is on reading the problem carefully, identifying what is being asked, choosing the operation, solving, and checking with estimation.
- **Thursday**: Multi-step word problems — problems that require three or more steps, or that combine addition and subtraction in the same problem. The student must plan their approach before calculating.
- **Friday**: Complex word problems with extra information (distractors), missing information, and problems where the student writes their own word problem. This is also the informal end-of-unit check for 4.NBT.4.

### The Misconception You Need to Watch For

**Keyword hunting without thinking**: Students learn that "total" means add and "remaining" means subtract. Then they encounter a problem like: "Marcus had 5,230 baseball cards. He gave 1,475 to his sister and then bought 890 more at a yard sale. How many does he have now?" The word "total" does not appear, but the student needs to both subtract and add. If they are hunting for a single keyword, they will be stuck. Teach them to READ THE WHOLE PROBLEM first, then ask: "What do I know? What am I looking for? What happens first, and what happens next?"

**Ignoring whether the answer makes sense**: A student subtracts when they should add and gets an answer that is smaller than either number in the problem. They write it down and move on. Teach them to check: "Does this answer make sense given the situation?" If you started with 5,230 cards, can you end up with 7,000? Only if you gained more. Can you end up with 2,000? Only if you gave a lot away.

### If Your Student Is Ahead

Give them problems with three or more steps, or problems that require deciding between multiple valid approaches. Example: "A school has three grades. Grade 3 has 127 students, Grade 4 has 143 students, and Grade 5 has 118 students. The cafeteria can seat 250 students at a time. Can all three grades eat lunch at the same time? If not, suggest a schedule that works." This requires addition, comparison, and reasoning.

### If Your Student Is Behind

Drop back to one-step word problems with clear signal words. "A bakery made 2,345 muffins. They sold 1,287. How many are left?" Make the operation obvious. Then gradually remove the signal word: "A bakery made 2,345 muffins in the morning and 1,287 in the afternoon. How many muffins did they make that day?" Same numbers, different operation, different signal. Build the reading-to-operation connection slowly.

---

## Science Focus: Designing Energy Solutions (4-PS3-4)

### What You're Teaching

In Weeks 2 and 3, your student observed energy transfer and energy conversion. This week, they DESIGN something. The standard asks them to "apply scientific ideas to design, test, and refine a device that converts energy from one form to another." This is the engineering design process — a structured approach to solving problems through building and testing.

### Background You Need

The engineering design process has four steps at this level:

1. **Identify the problem**: What do you need the device to do?
2. **Design a solution**: Sketch a plan. What materials will you use? How will it work?
3. **Build and test**: Construct a prototype and see if it works.
4. **Refine**: What worked? What did not? How can you improve it?

Your student will design two devices this week:
- **Wednesday**: A solar oven (or light-to-heat concentrator) using cardboard and aluminum foil. The device should convert light energy to heat energy efficiently enough to warm a piece of dark paper noticeably more than leaving the paper exposed without the device.
- **Friday**: A sound amplifier — a device that makes a rubber band instrument louder. Building on the Week 3 rubber band box, the student modifies or redesigns the instrument to increase the volume of the sound.

These are simple devices. The learning is not in the product — it is in the process: planning, testing, observing, and refining based on evidence.

### Key Vocabulary

| Term | Student-Friendly Definition |
|------|---------------------------|
| **Engineering design process** | A step-by-step method for solving problems by designing, building, testing, and improving |
| **Prototype** | A first version of something you build to test your idea |
| **Refine** | To make something better based on what you learned from testing |
| **Efficiency** | How well a device does what it is supposed to do — a more efficient device wastes less energy |

---

## Social Studies Focus: The Three Fires Confederacy — Political Systems and Diplomacy (4-H3.0.2)

### What You're Teaching

This is the second week of the Anishinaabe deep study. Last week covered daily life, the Seasonal Round, and an introduction to governance. This week goes deeper: the political structures of the Three Fires Confederacy, how nations made decisions together, how diplomacy worked between the Anishinaabe and other nations, and what began to change when Europeans arrived in the Great Lakes region.

### Background You Need — Please Read Carefully

**The Three Fires Confederacy as a political system:**

The Council of Three Fires was not an informal friendship between three groups. It was a structured political alliance with specific roles, responsibilities, and protocols. When the three nations met in council:

- The **Potawatomi** (Keepers of the Sacred Fire) hosted and managed the council fire. They set the tone — literally and metaphorically. The fire was the center of all proceedings.
- The **Ojibwe** (Keepers of the Faith) opened councils with prayers and ceremonies. They ensured that spiritual protocols were observed — decisions were not purely secular. Spiritual and political life were integrated.
- The **Odawa** (Keepers of the Trade) often served as diplomats and negotiators, particularly in dealings with external nations. Their trade expertise gave them broad networks and relationships.

Decisions were made by **consensus**, not majority rule. This meant that discussions continued until all parties could agree on a course of action — or until it was clear that action should be deferred. This process could be slow by modern standards, but it ensured that decisions had broad support and that no nation felt overridden.

**Diplomacy beyond the Three Fires:**

The Anishinaabe did not exist in isolation. They maintained diplomatic relationships with neighboring nations: the Haudenosaunee (Iroquois Confederacy) to the east, the Menominee and Ho-Chunk to the west, the Dakota and Lakota further west, and many others. These relationships involved:

- **Treaty councils**: Formal meetings between nations to establish agreements about territory, trade, and peace.
- **Gift exchange**: Gifts were not bribes — they were diplomatic currency. Giving a gift established obligation and relationship. Receiving a gift meant accepting a relationship.
- **Wampum belts**: Belts made of shell beads that recorded agreements, treaties, and important events. Wampum was not money — it was a record-keeping and communication system. Each belt told a story.
- **Kinship diplomacy**: Nations established family connections through marriage and adoption, creating bonds that made conflict less likely.

**European contact — an honest framing:**

When French explorers and traders arrived in the Great Lakes region in the early 1600s, they entered an existing political landscape. The Anishinaabe did not "discover" the French any more than the French "discovered" the Anishinaabe. Both had existing civilizations. What changed was the introduction of European trade goods (metal tools, firearms, cloth) and diseases (smallpox, measles) into an existing system.

Important framing notes:
- The Anishinaabe were not passive recipients of European contact. They were active negotiators who shaped the terms of trade and alliance.
- The fur trade, which became central to French-Indigenous relationships, was built on existing Anishinaabe trade networks — the French plugged into systems the Odawa had already built.
- Disease devastated Indigenous populations not because of any inherent weakness, but because these diseases were new to the Americas and populations had no prior exposure or immunity. This was a biological catastrophe, not an inevitability of "progress."
- Do not frame European arrival as the beginning of "real" history. Thousands of years of Anishinaabe civilization preceded it. European contact was a disruption of existing systems, not the start of something.

### Key Vocabulary

| Term | Student-Friendly Definition |
|------|---------------------------|
| **Confederacy** | An alliance of nations that agree to work together while keeping their own governments |
| **Consensus** | A decision that everyone can agree to support — not just a majority vote |
| **Diplomacy** | The practice of managing relationships between nations through talking, negotiating, and making agreements |
| **Wampum** | Belts or strings of shell beads used to record agreements, treaties, and important messages |
| **Treaty** | A formal agreement between nations |
| **Sovereignty** | A nation's right to govern itself and make its own decisions |

---

## ELA Integration Points

### Reading (4.RI.1, 4.RI.3)
- **Thursday, Social Studies**: The oral lecture about Three Fires political systems functions as an informational text. Ask the student to refer to specific details (4.RI.1) and explain how the consensus process worked (4.RI.3).
- **Wednesday, Science**: The engineering design process is a procedure — explaining it practices 4.RI.3.

### Writing (4.W.2, 4.W.4)
- **Wednesday, Science**: Writing a design plan for the solar oven — informative/explanatory writing (4.W.2).
- **Thursday, Social Studies**: Explanatory writing comparing Anishinaabe and U.S. governance (4.W.2, 4.W.4).

### Speaking and Listening (4.SL.1)
- **Every day**: Discussions about problem-solving strategies (math), design choices (science), and governance systems (social studies) all build 4.SL.1.

### Language Conventions (4.L.1-3)
- **Every day**: Same standard as previous weeks. Hold the line on grammar, spelling, and punctuation in all written work.

---

## Materials Checklist

### Must Have
- [ ] **Grid paper** — for keeping word problems organized. Students should write each step on a separate line.
- [ ] **Math journal** — continuing from Weeks 1-3
- [ ] **Cardboard and aluminum foil** — for the solar oven. A cereal box or small shipping box works well. You need enough foil to line the inside.
- [ ] **Flashlight or small lamp** — for testing the solar oven
- [ ] **Thermometer** — any kind. To measure whether the solar oven actually increases temperature.
- [ ] **Rubber band and box** — reuse from Week 3 for the sound amplifier redesign
- [ ] **Large blank paper** — for the Three Fires Confederacy diagram
- [ ] **Colored pencils and markers**
- [ ] **Pencils, eraser, sharpener**

### Nice to Have
- [ ] **Whiteboard** — for sketching word problem strategies
- [ ] **Additional craft materials** (paper cups, string, extra cardboard) — for creative sound amplifier designs

---

## Your Mindset This Week

Two things:

First, word problems are where the rubber meets the road. A student who can compute 34,582 + 27,649 but cannot figure out when to use that skill in a real situation has only half the picture. This week builds the other half. Be patient with the reading and reasoning — that is the actual learning happening. The computation is the easy part now.

Second, the social studies this week gets into more complex territory. European contact is a topic loaded with narratives — narratives of "discovery," "progress," and "civilization" that erase Indigenous agency and sophistication. Your job is to present the Anishinaabe as they were: sovereign nations with political systems, diplomatic protocols, and civilizational achievements that rivaled anything in Europe at the time. European contact was not the arrival of civilization — it was the collision of civilizations. Present it with that complexity.

---

*Root Access Learning OS — Week 04 of 36*

© 2026 Root Access Learning OS. All rights reserved.
