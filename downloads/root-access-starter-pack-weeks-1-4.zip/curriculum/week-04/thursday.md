# Week 4 — Thursday

## Open Source: Day 2

**Grade:** 4 | **Standards:** 4.NBT.4, 4.OA.3, 4-H3.0.2, 4.RI.1, 4.RI.3, 4.W.2, 4.W.4, 4.SL.1
**Theme:** Open Source — connected systems, shared governance
**Math Mode:** Abstract — multi-step word problems

---

## Materials Checklist

- [ ] Math journal and pencil
- [ ] Grid paper
- [ ] Dry-erase board or scratch paper
- [ ] Large blank paper (for Three Fires Confederacy diagram)
- [ ] Colored pencils and markers
- [ ] Lined paper for social studies writing
- [ ] Student's Anishinaabe Life poster from Week 3 (for reference)
- [ ] Student's Michigan map from previous weeks
- [ ] Timer
- [ ] Snack for Discussion Lunch

---

## Morning Work (15 min)

> **Say this:** "Two word problems and a journal. Use the strategy from yesterday: Read, Plan, Solve, Check."

### Quick Review (8 min)

**1.** A pet shelter had 1,245 animals at the start of the month. They adopted out 387 and took in 152 new animals. How many animals does the shelter have now?

**2.** Round each number in Problem 1 to the nearest hundred and estimate the answer. How close was your estimate to the actual answer?

#### Answers

| # | Answer | Notes |
|---|--------|-------|
| 1 | 1,245 - 387 = 858. Then 858 + 152 = **1,010** animals. |
| 2 | 1,200 - 400 = 800. 800 + 200 = 1,000. Estimate: 1,000. Actual: 1,010. Off by 10. Very close. |

### Journal Prompt (7 min)

**Prompt:** *"Last week you learned that Anishinaabe leaders — ogimaa — earned their position through wisdom and service, not inheritance. Today we go deeper into how the Three Fires Confederacy made decisions together. Before we start: what do you think is the HARDEST part about three separate groups trying to make a decision together?"*

This connects directly to today's social studies lesson about confederate governance.

---

## Block 1: Math (60 min) — Multi-Step Word Problems

**Standards:** 4.NBT.4, 4.OA.3
**Approach:** Read → Plan → Solve → Check (same strategy, harder problems)

---

### Launch (10 min)

> **Say this:** "Yesterday you solved word problems with one and two steps. Today, the problems get more complex. Some have three steps. Some give you EXTRA information you don't need. Some require you to figure out what's missing. The strategy is the same — Read, Plan, Solve, Check — but you'll need to think more carefully about your plan."

Write on the board:

**Watch Out For:**
- **Extra information** — not every number in the problem matters
- **Hidden steps** — sometimes you need to calculate something that is not directly asked
- **Multiple operations** — you might add AND subtract in the same problem

> **Say this:** "Here's an example of a problem with extra information."

Read aloud: "A store sold 3,450 blue shirts, 2,870 red shirts, and 1,520 green shirts this month. The store has 47 employees. How many shirts were sold in total?"

> **Say this:** "Did you notice that the number of employees — 47 — has nothing to do with the question? That number is a distractor. Your job is to figure out which numbers matter and which ones don't."

**Answer:** 3,450 + 2,870 + 1,520 = **7,840** shirts. The 47 employees is irrelevant.

---

### Guided Practice (20 min)

#### Problem 1: Multi-Step with Mixed Operations

**Problem:** The Detroit Institute of Arts had 28,456 visitors in March and 34,821 visitors in April. In May, attendance dropped by 5,347 compared to April. How many total visitors did the museum have across all three months?

> **Say this:** "Before you calculate, PLAN. How many steps do you see?"

**Step 1 — Find May's visitors.** April was 34,821. May dropped by 5,347. So May = 34,821 - 5,347 = **29,474**.
Ones: 1-7, borrow, 11-7=4. Tens: 1-4 (2→1 after borrow), borrow, 11-4=7. Hundreds: 7-3 (8→7 after borrow)=4. Thousands: 4-5, borrow, 14-5=9. Ten-thousands: 2 (3→2 after borrow).

**Step 2 — Add all three months.** 28,456 + 34,821 + 29,474.
First: 28,456 + 34,821 = **63,277**.
Then: 63,277 + 29,474 = **92,751**.

**Check:** About 28,000 + 35,000 + 29,000 = 92,000. Answer (92,751) is close. Reasonable.

**Answer:** The museum had **92,751** visitors across the three months.

---

#### Problem 2: Extra Information

**Problem:** A farmer has 3 fields. Field A produced 12,450 bushels of wheat. Field B produced 8,375 bushels. Field C has an area of 240 acres and produced 15,820 bushels. The farmer sold all the wheat from Field A and Field B but kept all of Field C's harvest. How many bushels did the farmer sell?

> **Say this:** "Read it again. What information do you actually need to answer the question?"

**Key insight:** The area of Field C (240 acres) is irrelevant. And we do NOT need Field C's harvest for this question — the farmer kept all of it. We only need Fields A and B.

**Solution:** 12,450 + 8,375 = **20,825** bushels sold.
Ones: 0+5=5. Tens: 5+7=12, carry 1. Hundreds: 4+3+1=8. Thousands: 2+8=10, carry 1. Ten-thousands: 1+0+1=2.

**Check:** 12,000 + 8,000 = 20,000. Answer (20,825) is close. Reasonable.

**Answer:** The farmer sold **20,825** bushels.

> **Say this:** "See how that problem tried to distract you with the 240 acres and the 15,820 bushels from Field C? If you read carefully and focus on WHAT THE QUESTION ASKS, you can ignore the extra information."

---

#### Problem 3: Three-Step

**Problem:** A family is driving from Detroit to Mackinaw City and back. The distance one way is 282 miles. They fill up with gas at the start (cost: $52). They stop for lunch on the way up (cost: $34) and dinner on the way back (cost: $47). They started the trip with $250. How much money do they have when they get home?

> **Say this:** "Count the steps. There are more than you think."

**Step 1 — Total expenses.** $52 + $34 + $47 = **$133**.
(52 + 34 = 86. 86 + 47 = 133.)

**Step 2 — Money remaining.** $250 - $133 = **$117**.

**Note:** The distance (282 miles) is extra information — the question asks about money, not miles.

**Check:** About $50 + $35 + $50 = $135. $250 - $135 = $115. Answer ($117) is close. Reasonable.

**Answer:** They have **$117** when they get home.

---

### Independent Practice (20 min)

> **Say this:** "Five problems. Each one has at least two steps. Watch for extra information — not every number matters. Plan before you calculate."

**Problem 1** (Medium — two-step)

A school ordered 5,400 pencils at the start of the year. By December, teachers had given out 3,875 pencils. In January, the school ordered 2,500 more. How many pencils does the school have now?

---

**Problem 2** (Medium — extra information)

A zoo has 342 mammals, 187 reptiles, and 456 birds. The zoo covers 125 acres. The zoo's gift shop sold 8,234 stuffed animals last year. How many LIVING animals does the zoo have?

---

**Problem 3** (Hard — three-step)

A lemonade stand earned $1,847 in June, $2,453 in July, and $1,265 in August. The stand's total expenses for the summer were $2,780. How much profit did the lemonade stand make?

---

**Problem 4** (Hard — comparison with multiple steps)

Town A has a population of 45,872. Town B has a population of 38,645. Town C has a population that is 3,500 more than Town B. Which town has the largest population, and by how much more than the smallest town?

---

**Problem 5** (Challenge — four-step)

A factory produced 18,340 toys in Week 1, 22,475 in Week 2, and 15,830 in Week 3. They shipped 35,000 toys to stores after Week 2. How many toys does the factory have after Week 3?

---

### Answer Key

**Problem 1:** 5,400 - 3,875 = 1,525. Then 1,525 + 2,500 = **4,025** pencils.

**Problem 2:** 342 + 187 + 456 = **985** living animals. The 125 acres and 8,234 stuffed animals are irrelevant.

**Problem 3:** Step 1: Total earnings: 1,847 + 2,453 + 1,265 = **5,565**. Step 2: Profit: 5,565 - 2,780 = **$2,785** profit.
(1,847 + 2,453 = 4,300. 4,300 + 1,265 = 5,565. 5,565 - 2,780 = 2,785.)

**Problem 4:** Step 1: Town C = 38,645 + 3,500 = **42,145**. Step 2: Populations are A=45,872, B=38,645, C=42,145. Largest: Town A. Smallest: Town B. Step 3: 45,872 - 38,645 = **7,227** more.

**Problem 5:** Step 1: After Week 1: 18,340. Step 2: After Week 2: 18,340 + 22,475 = 40,815. Step 3: After shipping: 40,815 - 35,000 = 5,815. Step 4: After Week 3: 5,815 + 15,830 = **21,645** toys.

---

### Beast Academy Challenge (10 min)

> **Say this:** "Here's a logic puzzle that uses addition and subtraction."

**The Puzzle:**

Three friends — Aiden, Brianna, and Carlos — each have a different number of marbles. Together they have 1,000 marbles total. Aiden has 150 more marbles than Brianna. Carlos has 50 fewer marbles than Brianna. How many marbles does each person have?

**Solution:**

Let Brianna = B. Then Aiden = B + 150. Carlos = B - 50.

Together: B + (B + 150) + (B - 50) = 1,000.
3B + 100 = 1,000.
3B = 900.
B = 300.

- Brianna: **300**
- Aiden: 300 + 150 = **450**
- Carlos: 300 - 50 = **250**

Check: 300 + 450 + 250 = 1,000. Confirmed.

> **Say this:** "You might not know algebra yet, but here's how to think about it: if all three had the same amount, each would have about 333. But Aiden has 150 MORE than Brianna, and Carlos has 50 FEWER. That means Aiden has 200 more than Carlos. The extra 150 and the missing 50 are a net +100 marbles accounted for, so the 'base' amount is (1,000 - 100) ÷ 3 = 300. That's Brianna."

---

### Bug Check

#### Error 404: Student cannot identify the steps in a multi-step problem.
Have them read the problem sentence by sentence. After each sentence, ask: "Is this giving you a number? Is it telling you to do something? What action is happening?" Build a numbered list of events before doing any math. Example: "Event 1: School had 5,400 pencils. Event 2: Gave out 3,875. Event 3: Got 2,500 more." Then convert each event to a math operation.

#### Error 500: Student uses extra information in their calculation.
After reading the problem, have them CROSS OUT any sentence that does not help answer the question. Physically crossing it out removes the distraction. Then work with only the remaining sentences.

#### Syntax Error: Student's computation is correct but their answer does not match the question.
Example: the problem asks "how much profit" and the student gives the total earnings, not the profit. Have them re-read the question AFTER solving and ask: "Did I answer what was asked?" This is a reading comprehension issue, not a math issue.

---

## Block 2: Social Studies (45 min) — The Three Fires Confederacy: Political Systems

**Standards:** 4-H3.0.2, 4.RI.1, 4.RI.3, 4.W.2, 4.SL.1

---

### Hook (5 min)

> **Say this:** "Last week, you learned about the Anishinaabe — the Ojibwe, Odawa, and Potawatomi — and how they lived through the Seasonal Round. You learned that their leaders were chosen by wisdom, not inheritance. Today, we zoom in on HOW these three nations worked together. How do you make decisions when you're not one group, but THREE separate nations with your own leaders, your own territory, and your own traditions?"

> **Ask:** "If you and two friends had to agree on where to eat lunch, how would you decide? What if you all wanted something different?"

*(Let them talk through it. Most will say vote, compromise, take turns.)*

> **Say this:** "The Three Fires Confederacy faced that same question — but the stakes were much higher. Not lunch, but war and peace. Trade routes. Territory. Alliances with other nations. And their answer was remarkable."

---

### Lesson (20 min)

Read this aloud. Pause at **[PAUSE]** marks.

> **Say this:** "The Council of Three Fires — Niswi-mishkodewin — was one of the oldest political alliances in North America. The Ojibwe, Odawa, and Potawatomi agreed to work together while keeping their own separate governments. That is what a confederacy means: an alliance where each member governs itself but cooperates on shared concerns."

> **Say this:** "When the three nations met in council, each had a specific role."

Write on the board or have the student copy:

| Nation | Role in Council | What They Did |
|--------|----------------|---------------|
| **Potawatomi** | Keepers of the Sacred Fire | Hosted the council. Managed the fire — the center of all proceedings. Set the tone. |
| **Ojibwe** | Keepers of the Faith | Opened with prayers and ceremonies. Ensured spiritual protocols were followed. |
| **Odawa** | Keepers of the Trade | Served as diplomats and negotiators. Used their trade relationships to build alliances. |

> **Say this:** "Notice something important: no single nation was 'in charge.' Each had a role that the others respected. The Potawatomi hosted. The Ojibwe opened with ceremony. The Odawa negotiated. They were partners, not boss and employees."

**[PAUSE]**

> **Say this:** "Decisions were made by CONSENSUS. That word means everyone agrees — or at least, everyone can live with the decision. It is not a vote where 51% wins and 49% loses. In a consensus system, you keep discussing until everyone is satisfied. If you cannot reach consensus, the decision is delayed. This takes longer than voting, but it means no nation feels ignored or overruled."

> **Ask:** "Why do you think the Anishinaabe used consensus instead of voting?"

*(Listen for: fairness, preventing one group from dominating, making sure everyone's voice counts, building unity.)*

> **Say this:** "Think about that. In the United States, elections are decided by majority rule — the side with more votes wins. That means the losing side might feel unheard. The Anishinaabe designed a system that avoided that entirely. No nation could be outvoted. Every nation had to be satisfied."

**[PAUSE]**

> **Say this:** "The Three Fires did not exist in a bubble. They had diplomatic relationships with many other nations."

Write:

**Neighbors and Allies:**
- **Haudenosaunee (Iroquois Confederacy)** — a powerful confederacy to the east, made up of six nations. The Haudenosaunee and the Anishinaabe sometimes cooperated and sometimes competed. Both had sophisticated governance systems.
- **Menominee** — neighbors to the west, in present-day Wisconsin. Trading partners.
- **Ho-Chunk (Winnebago)** — also in the western Great Lakes region. Part of the broader diplomatic network.
- **Dakota and Lakota** — further west, on the Great Plains. The boundary between Anishinaabe and Dakota territory was an important diplomatic line.

> **Say this:** "Diplomacy between nations used several tools."

Write:

| Diplomatic Tool | How It Worked |
|----------------|---------------|
| **Treaty councils** | Formal meetings to negotiate agreements about territory, trade, and peace |
| **Gift exchange** | Gifts were diplomatic currency — giving a gift created an obligation and a relationship |
| **Wampum belts** | Shell bead belts that recorded agreements and treaties — like a written contract |
| **Kinship** | Nations built family connections through marriage and adoption to strengthen alliances |

> **Say this:** "Wampum belts are especially interesting. They were not money — they were records. A specific pattern of shell beads told a specific story or recorded a specific agreement. When nations made a treaty, a wampum belt was created to record it. The belt was a physical object that both sides could point to and say, 'This is what we agreed.'"

**[PAUSE]**

> **Say this:** "Some historians believe that the governance systems of the Haudenosaunee and the Anishinaabe confederacies influenced the founders of the United States. Benjamin Franklin studied the Haudenosaunee Confederacy. The idea of separate states joining together in a union while keeping their own governments — that is essentially what a confederacy is. The Anishinaabe and Haudenosaunee had been doing it for centuries before the U.S. Constitution was written."

---

### Activity (15 min)

**Part 1: Three Fires Confederacy Diagram (10 min)**

> **Say this:** "Create a visual diagram of the Three Fires Confederacy. Use the large paper."

**The diagram should include:**
1. Three sections — one for each nation (Ojibwe, Odawa, Potawatomi)
2. In each section: the nation's name, their role (Keepers of the Faith/Trade/Sacred Fire), and their region on the map
3. A central area showing what connected them: the council fire, consensus decision-making, shared language family
4. At least two diplomatic tools labeled around the outside (wampum, gift exchange, treaty councils, kinship)

This is not just an art project. The writing in each section should show understanding.

**Part 2: Comparison Paragraph (5 min)**

> **Say this:** "Write a short paragraph — 4-5 sentences — comparing the Three Fires Confederacy to the United States government. How are they similar? How are they different? Use the words 'consensus,' 'confederacy,' and 'sovereignty.'"

---

### Historical Context — A Note for the Parent

Present the Three Fires Confederacy as a DESIGNED political system, not an accident of culture. These were intentional structures built on centuries of experience. The roles were not arbitrary — they reflected each nation's strengths and contributions. The consensus model was not inefficient — it was deliberately chosen to prevent domination.

When discussing influence on the U.S. Constitution, be honest about what is documented and what is debated. The influence of Indigenous governance on American democracy is a serious scholarly topic, but not all historians agree on its extent. What is clear: the founders were aware of Indigenous confederacies, and the structural similarities are real.

Avoid framing this as: "They had government too!" as if European-style government is the standard. The Anishinaabe governance system was complete and functional on its own terms. It does not need validation by comparison to European systems.

---

### Discussion (5 min)

> **Ask:** "The Three Fires Confederacy used consensus — everyone had to agree. The United States uses majority rule — more votes wins. Which system do you think is better? What are the advantages and disadvantages of each?"

**Listen for:** Understanding of trade-offs. Consensus is fairer but slower. Majority rule is faster but can leave the minority feeling unheard. Both systems try to make decisions that serve the group. Neither is perfect.

> **If student struggles:** "Think about your family. When your family decides where to go for dinner, do you vote, or do you talk about it until everyone agrees? What are the problems with each approach?"

---

## Discussion Lunch

> **"Wampum belts recorded agreements without using writing — the patterns in the beads told the story. What other ways do people record important agreements or memories WITHOUT writing? Think about art, music, objects, places, or traditions."**

---

## End-of-Day Check

- [ ] **Math:** Student can solve two-step word problems with mixed operations
- [ ] **Math:** Student can identify and ignore extra information in a word problem
- [ ] **Social Studies:** Student can explain how the Three Fires Confederacy made decisions
- [ ] **Social Studies:** Student can name at least two diplomatic tools used by the Anishinaabe
- [ ] **Diagram:** Three Fires Confederacy diagram completed with labels and writing

---

*Root Access Learning OS — Week 04, Thursday*

© 2026 Root Access Learning OS. All rights reserved.
