# Week 4 — Wednesday

## Open Source: Day 1

**Grade:** 4 | **Standards:** 4.NBT.4, 4.OA.3, 4-PS3-4, 4.RI.3, 4.W.2, 4.SL.1
**Total instructional time:** ~2 hours 15 minutes

---

## Materials Checklist

### Math
- [ ] Math journal and pencil
- [ ] Grid paper
- [ ] Dry-erase board or scratch paper

### Science
- [ ] Cardboard (cereal box or small shipping box)
- [ ] Aluminum foil
- [ ] Tape and scissors
- [ ] Flashlight or small lamp
- [ ] Thermometer
- [ ] Dark-colored paper (black or navy)
- [ ] Light-colored paper (white) — for comparison
- [ ] Science journal and pencil

### General
- [ ] Timer
- [ ] Snack for Discussion Lunch

---

## Morning Work (15 min)

> **Say this:** "Quick math warm-up, then a journal."

### Quick Review (8 min)

**1.** 6,205 - 3,478 = _____

**2.** 15,834 + 7,689 = _____

**3.** Estimate the answer to Problem 2 by rounding each number to the nearest thousand. How close was your estimate?

#### Answers

| # | Answer | Notes |
|---|--------|-------|
| 1 | 2,727 | Ones: 5-8, borrow, 15-8=7. Tens: 9-7=2 (chain borrow through 0: hundreds 2→1, tens 0→10, then 10→9 for ones borrow). Hundreds: 1-4, borrow, 11-4=7. Thousands: 5-3=2. |
| 2 | 23,523 | Ones: 4+9=13, carry 1. Tens: 3+8+1=12, carry 1. Hundreds: 8+6+1=15, carry 1. Thousands: 5+7+1=13, carry 1. Ten-thousands: 1+0+1=2. |
| 3 | 16,000 + 8,000 = 24,000. Actual: 23,523. Difference: 477. Estimate was close — within 500. |

### Journal Prompt (7 min)

**Prompt:** *"Think about a time you had to solve a problem in real life — not a math problem on paper, but a real situation. Maybe you needed to figure out how much something cost, or how to split something fairly, or how long something would take. What did you do? Did you use math without realizing it?"*

---

## Block 1: Math (60 min) — Word Problems with Addition and Subtraction

**Standards:** 4.NBT.4, 4.OA.3
**Approach:** Read → Plan → Solve → Check

---

### Launch (10 min)

> **Say this:** "For the past two weeks, you've been adding and subtracting big numbers. You're good at it. But here's the thing — in real life, nobody hands you a problem that says '34,582 + 27,649.' In real life, the problem sounds like THIS:"

Read aloud:

> "The Grand Rapids Public Library has 42,350 books in its main branch. They received a donation of 8,475 new books. Then they removed 3,210 damaged books from the shelves. How many books does the library have now?"

> **Say this:** "THAT is a word problem. The math is the same — addition and subtraction. But YOU have to figure out what to add and what to subtract. Nobody is going to tell you. You have to READ, THINK, and then CALCULATE."

Write on the board — **The Word Problem Strategy:**

1. **READ** the whole problem. Twice.
2. **WHAT do I know?** (List the numbers and what they represent.)
3. **WHAT am I looking for?** (What is the question asking?)
4. **WHAT operations do I need?** (Add? Subtract? Both?)
5. **SOLVE** — show your work.
6. **CHECK** — Does the answer make sense? Use estimation.

> **Say this:** "Let's try it with the library problem."

Work through it together:
- What do I know? 42,350 books. Got 8,475 more. Removed 3,210.
- What am I looking for? How many books now.
- What operations? Add the donation, subtract the damaged books.
- Solve: 42,350 + 8,475 = 50,825. Then 50,825 - 3,210 = 47,615.
- Check: Started with about 42,000. Added about 8,000 = 50,000. Subtracted about 3,000 = 47,000. Our answer (47,615) is close. Makes sense.

**Answer:** The library has **47,615** books.

---

### Guided Practice (20 min)

#### Problem 1: One-Step — Addition

> **Say this:** "Read this problem carefully. Then tell me: what do you know, what are you looking for, and what operation do you need?"

**Problem:** Lake Huron's shoreline in Michigan is 3,288 miles long. Lake Michigan's shoreline in Michigan is 1,638 miles long. How many miles of Great Lakes shoreline does Michigan have along these two lakes?

**Step 1 — Read and plan.**
- Know: Lake Huron = 3,288 miles. Lake Michigan = 1,638 miles.
- Looking for: total shoreline along both lakes.
- Operation: addition.

**Step 2 — Solve.**
```
  3,288
+ 1,638
-------
  4,926
```
Ones: 8+8=16, carry 1. Tens: 8+3+1=12, carry 1. Hundreds: 2+6+1=9. Thousands: 3+1=4.

**Step 3 — Check.** 3,000 + 2,000 = 5,000. Answer (4,926) is close. Reasonable.

**Answer:** Michigan has **4,926** miles of Great Lakes shoreline along Huron and Michigan.

---

#### Problem 2: One-Step — Subtraction

**Problem:** A bakery in Traverse City made 12,480 cherry pies this season. They sold 9,735. How many pies are left?

**Step 1 — Read and plan.**
- Know: Made 12,480. Sold 9,735.
- Looking for: how many left.
- Operation: subtraction.

**Step 2 — Solve.**
```
  12,480
-  9,735
--------
   2,745
```
Ones: 0-5, borrow, 10-5=5. Tens: 7-3=4 (after borrow: 8→7). Hundreds: 3-7 (4→3 after borrow), borrow, 13-7=6. Wait — let me redo carefully. 12,480 - 9,735.

Ones: 0-5, borrow from tens. Tens: 8→7, ones 0→10. 10-5=5.
Tens: 7-3=4.
Hundreds: 4-7, borrow from thousands. Thousands: 2→1, hundreds 4→14. 14-7=7.
Thousands: 1-9, borrow from ten-thousands. Ten-thousands: 1→0, thousands 1→11. 11-9=2.
Ten-thousands: 0.

**Answer:** 12,480 - 9,735 = **2,745** pies remaining.

**Check:** 12,000 - 10,000 = 2,000. Answer (2,745) is in the right range. Reasonable.

---

#### Problem 3: Two-Step

**Problem:** A school fundraiser collected $5,847 from a bake sale and $3,628 from a car wash. They spent $2,195 on supplies. How much money did they raise after expenses?

> **Say this:** "This problem has TWO steps. First you need to find the total raised, THEN subtract the expenses. Read it again and make sure you see both steps."

**Step 1 — Add the income.** 5,847 + 3,628 = **9,475**
Ones: 7+8=15, carry 1. Tens: 4+2+1=7. Hundreds: 8+6=14, carry 1. Thousands: 5+3+1=9.

**Step 2 — Subtract expenses.** 9,475 - 2,195 = **7,280**
Ones: 5-5=0. Tens: 7-9, borrow, 17-9=8. Hundreds: 3-1 (4→3 after borrow)=2. Thousands: 9-2=7.

**Check:** About 6,000 + 4,000 = 10,000. 10,000 - 2,000 = 8,000. Answer (7,280) is close. Reasonable.

**Answer:** They raised **$7,280** after expenses.

---

### Independent Practice (20 min)

> **Say this:** "Five word problems. For each one, use the strategy: Read, Plan, Solve, Check. Write out what you know, what you're looking for, and what operation you need BEFORE you start calculating."

**Problem 1** (Easy — one-step addition)

A factory in Kalamazoo produced 14,563 cereal boxes on Monday and 12,847 on Tuesday. How many boxes were produced in those two days?

---

**Problem 2** (Easy — one-step subtraction)

The Upper Peninsula has a population of about 311,361 people. The city of Marquette has a population of about 20,629. How many people in the Upper Peninsula live OUTSIDE of Marquette?

---

**Problem 3** (Medium — two-step)

A family saved $8,450 for a vacation. They spent $3,275 on plane tickets and $2,180 on the hotel. How much of their savings is left?

---

**Problem 4** (Medium — two-step with comparison)

School A collected 15,230 cans for a food drive. School B collected 12,485 cans. How many more cans did School A collect than School B? If School B collects 4,000 more cans, will they have more than School A's total?

---

**Problem 5** (Hard — three-step)

A bookstore had 24,500 books at the start of the year. In January, they sold 3,847 books. In February, they received a shipment of 5,230 new books. In March, they sold 4,112 books. How many books does the bookstore have now?

---

### Answer Key

**Problem 1:** 14,563 + 12,847 = **27,410** boxes.
Ones: 3+7=10, carry 1. Tens: 6+4+1=11, carry 1. Hundreds: 5+8+1=14, carry 1. Thousands: 4+2+1=7. Ten-thousands: 1+1=2.

**Problem 2:** 311,361 - 20,629 = **290,732** people.
Ones: 1-9, borrow, 11-9=2. Tens: 5-2=3 (6→5 after borrow). Hundreds: 3-6, borrow, 13-6=7. Thousands: 0-0=0 (1→0 after borrow). Ten-thousands: 1-2, borrow, 11-2=9. Hundred-thousands: 2 (3→2 after borrow).

**Problem 3:** Step 1: 3,275 + 2,180 = **5,455** total spent. Step 2: 8,450 - 5,455 = **$2,995** left.
(Alternative valid approach: 8,450 - 3,275 = 5,175. Then 5,175 - 2,180 = 2,995. Same answer.)

**Problem 4:** Step 1: 15,230 - 12,485 = **2,745** more cans. Step 2: 12,485 + 4,000 = **16,485**. Yes, 16,485 > 15,230, so School B would have more.

**Problem 5:** Start: 24,500. After January: 24,500 - 3,847 = **20,653**. After February: 20,653 + 5,230 = **25,883**. After March: 25,883 - 4,112 = **21,771** books.
Check: Started about 25,000. Lost about 4,000 = 21,000. Gained about 5,000 = 26,000. Lost about 4,000 = 22,000. Answer (21,771) is close.

---

### Beast Academy Challenge (10 min)

> **Say this:** "This one is tricky. Read it twice before you start."

**The Puzzle:**

I'm thinking of two numbers. Their sum is 10,000. Their difference is 2,468. What are the two numbers?

**Solution:**

If the sum is 10,000 and the difference is 2,468:
- The larger number is (10,000 + 2,468) ÷ 2 = 12,468 ÷ 2 = **6,234**
- The smaller number is (10,000 - 2,468) ÷ 2 = 7,532 ÷ 2 = **3,766**

Check: 6,234 + 3,766 = 10,000. 6,234 - 3,766 = 2,468. Both confirmed.

> **Say this:** "You don't know division yet — that is coming later this year. But think about it this way: if two numbers add to 10,000 and are 2,468 apart, the bigger one is 'half of 10,000 plus half of 2,468' and the smaller one is 'half of 10,000 minus half of 2,468.' Half of 10,000 is 5,000. Half of 2,468 is 1,234. So the numbers are 5,000 + 1,234 = 6,234 and 5,000 - 1,234 = 3,766."

*(If the student cannot solve this, that is fine — this is a stretch problem. The exposure to the reasoning matters more than getting the answer.)*

---

### Bug Check

#### Error 404: Student cannot set up word problems at all.
They read the problem and immediately start computing random numbers. Go back to acting it out. Use physical objects: "Here are 15 blocks. I take away 7. How many are left?" Then: "Here are 8 blocks. I add 6 more. How many now?" Then read the word problem and act it out with objects before writing any numbers. Build the bridge between the story and the math.

#### Error 500: Student chooses the wrong operation.
They add when they should subtract, or vice versa. Have them draw a picture of the situation. "Draw the library with 42,350 books. Now draw the truck delivering 8,475 more. Now draw someone removing 3,210 damaged books. Look at your picture — are the books going UP or DOWN?" Visual representation helps them see what is happening before they compute.

#### Syntax Error: Student sets up correctly but makes computation errors.
Have them check every answer with estimation BEFORE moving on. Round each number to the nearest thousand, do the mental math, and compare. If the estimate and the answer are far apart, something went wrong. This builds self-monitoring.

---

## Block 2: Science (45 min) — Designing Energy Solutions

**Standard:** 4-PS3-4 — Apply scientific ideas to design, test, and refine a device that converts energy from one form to another.
**ELA Integration:** 4.RI.3 (explaining a procedure), 4.W.2 (informative writing), 4.SL.1 (discussion)

---

### Hook (5 min)

> **Say this:** "Last week, you learned that energy converts — light becomes heat, motion becomes sound. You OBSERVED conversions. Today, you become an ENGINEER. You are going to DESIGN a device that converts energy. Not just watch it happen — make it happen on purpose."

> **Ask:** "What does an engineer do?"

*(An engineer designs and builds things to solve problems.)*

> **Say this:** "Exactly. And engineers follow a process. They don't just start building. They plan, they test, they improve. Today, you learn that process — and you build your first prototype."

---

### Lesson (15 min)

> **Say this:** "Engineers use something called the Engineering Design Process. It has four steps."

Write on the board:

| Step | What You Do |
|------|------------|
| **1. Identify the Problem** | What do you need your device to do? |
| **2. Design** | Sketch a plan. Choose materials. Predict how it will work. |
| **3. Build and Test** | Build a prototype. Test it. Collect data — does it work? |
| **4. Refine** | What worked? What did not? Make it better. Test again. |

> **Say this:** "Today's problem is this: you need to build a device that converts LIGHT energy into HEAT energy as efficiently as possible. In other words, a device that takes light and makes something get warmer."

> **Say this:** "You already know from last week that dark surfaces absorb more light and convert it to heat. And you know that light can be reflected — a mirror bounces light. So here's the question: can you build a device that CONCENTRATES light onto a dark surface to make it heat up faster?"

**The Device: A Light-to-Heat Concentrator (Mini Solar Oven)**

> **Say this:** "You're going to build a small device using cardboard and aluminum foil that focuses light onto a piece of dark paper. Then we'll test whether your device heats the paper more than just leaving the paper under the light without any device."

---

### Activity: Build and Test (20 min)

#### Step 1: Design (5 min)

> **Say this:** "Before you build, sketch your design in your science journal. Draw what you plan to build. Label the materials: where will the cardboard go? Where will the foil go? Where will the dark paper sit? How will the light get in?"

**Design hints (share only if the student is stuck):**
- Line the inside of the box with aluminum foil (shiny side out). The foil reflects light.
- Place the dark paper at the bottom of the box. The paper absorbs light and converts it to heat.
- Angle the box so the light source shines into the opening.
- The foil reflects light from the sides and concentrates it onto the dark paper.

> **Say this:** "Write a prediction: how much warmer will the paper get inside your device compared to a paper just sitting under the light? Guess a number of degrees."

#### Step 2: Build (7 min)

Let the student build their prototype. They should:
1. Cut and shape the cardboard into an open-topped container (or use the box as-is).
2. Line the interior with aluminum foil, shiny side facing inward. Tape it in place.
3. Place a piece of dark paper at the bottom.
4. Prepare a second piece of dark paper to sit outside the device as a CONTROL (no device, same light).

#### Step 3: Test (5 min)

1. Place the thermometer on the dark paper INSIDE the device.
2. Place the light source (flashlight or lamp) so it shines into the opening of the device.
3. Record the starting temperature.
4. Wait 3 minutes. Record the temperature.
5. Now place the thermometer on the CONTROL paper (outside the device, same distance from light).
6. Wait 3 minutes. Record.

> **Say this:** "Compare the two temperatures. Which paper got warmer? By how much?"

*(The paper inside the device should be warmer because the foil reflects additional light onto the paper, concentrating the energy conversion.)*

#### Step 4: Refine (3 min)

> **Say this:** "If you could rebuild this device, what would you change? Maybe a bigger box? More foil? A different angle? Write one thing you would change and WHY."

---

### Discussion (5 min)

> **Ask:** "Real solar ovens work on this exact same principle — they use reflective surfaces to concentrate sunlight and convert it to heat for cooking. Where in the world do you think solar ovens would be most useful, and why?"

**Listen for:** Understanding that solar ovens work best where there is strong, consistent sunlight. Connections to regions without reliable electricity. Understanding that this technology is practical, not just a classroom experiment.

> **If student struggles:** "Think about where the sun shines the most. Now think about places where people might not have stoves or electricity. How would a solar oven help?"

---

## Discussion Lunch

> **"Engineers design solutions to problems. If you could design a solution to ANY problem — big or small — what would you build? It does not have to be realistic. What problem would you solve, and how would your invention work?"**

---

## End of Day

> **Say this:** "Today you solved word problems — not just computing, but figuring out WHAT to compute. And you designed and built an actual device that converts light to heat. You are thinking like a mathematician and an engineer. Tomorrow, the word problems get harder — multiple steps, more decisions. And we go deep into the Three Fires Confederacy — how three nations governed together. Get ready."

---

© 2026 Root Access Learning OS. All rights reserved.
