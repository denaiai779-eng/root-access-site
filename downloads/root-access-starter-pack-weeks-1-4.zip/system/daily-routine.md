# Root Access — Daily Routine

> Standard schedule for Wednesday, Thursday, and Friday. Adjust timing as needed — this is a framework, not a cage.

---

## Wednesday (Math + Science)

| Time | Block | Duration | Notes |
|------|-------|----------|-------|
| 8:30 | Morning Work | 15 min | Journal prompt, warm-up, or review |
| 8:45 | **Block 1: Math** | 60 min | Singapore Math progression + Beast Academy challenge |
| 9:45 | Break | 15 min | Move around. Snack. No screens. |
| 10:00 | **Block 2: Science** | 45 min | NGSS-aligned, hands-on activity |
| 10:45 | Discussion Lunch | 30 min | Casual conversation connected to the day's learning |
| 11:15 | Homework Review / Wrap-Up | 15 min | Review yesterday's homework, preview tomorrow |

## Thursday (Math + Social Studies)

| Time | Block | Duration | Notes |
|------|-------|----------|-------|
| 8:30 | Morning Work | 15 min | Journal prompt, warm-up, or review |
| 8:45 | **Block 1: Math** | 60 min | Singapore Math progression + Beast Academy challenge |
| 9:45 | Break | 15 min | Move around. Snack. No screens. |
| 10:00 | **Block 2: Social Studies** | 45 min | MI standards, de-colonized framing, primary sources |
| 10:45 | Discussion Lunch | 30 min | Casual conversation connected to the day's learning |
| 11:15 | Homework Review / Wrap-Up | 15 min | Review yesterday's homework, preview tomorrow |

## Friday (Math + Alternating + Coding)

| Time | Block | Duration | Notes |
|------|-------|----------|-------|
| 8:30 | Morning Work | 15 min | Journal prompt, warm-up, or review |
| 8:45 | **Block 1: Math** | 60 min | Singapore Math progression + Beast Academy challenge |
| 9:45 | Break | 15 min | Move around. Snack. No screens. |
| 10:00 | **Block 2: Science or Social Studies** | 45 min | Alternates weekly — extends the week's topic |
| 10:45 | Discussion Lunch | 30 min | Casual conversation connected to the day's learning |
| 11:15 | **Block 3: Coding** | 30 min | Scratch, Python basics, or logic puzzles |
| 11:45 | Week Wrap-Up | 15 min | What did we learn? What's next week? |

---

## Principles

- **Start on time, end on time.** Respect the schedule and it respects you.
- **Morning Work is non-negotiable.** It's the transition from "home mode" to "school mode."
- **Break means break.** Not a shorter version of screen time. Move, eat, decompress.
- **Discussion Lunch is learning.** It just doesn't feel like it. That's the point.
- **If a block runs long, steal from wrap-up, not from break.** Kids need breaks. Wrap-up can flex.
- **If the student is on fire and deeply engaged — let it run.** The schedule serves learning, not the other way around.
