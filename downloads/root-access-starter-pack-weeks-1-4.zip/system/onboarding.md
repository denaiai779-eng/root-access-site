# Root Access — Parent Onboarding Guide

> Everything you need to know before Week 1. Read this once. Refer back as needed.

---

## What Root Access Is

Root Access is a complete 4th-grade homeschool curriculum that runs 3 days a week (Wednesday, Thursday, Friday) across 36 weeks. It covers Math, Science, Social Studies, and ELA — with ELA integrated across all subjects rather than taught in isolation.

Every lesson is fully scripted. You'll see `> **Say this**: "..."` blocks throughout — that's your dialogue. You don't need to prep a lecture or figure out how to explain fractions. It's written for you. Use it verbatim or adapt it to your style, but the scaffold is always there.

## What You Need

### Non-Negotiable
- **This curriculum** (printed or on a screen you can read while teaching)
- **The Go-Bag** (student workbook — print it or have it on a tablet)
- **Basic math manipulatives**: base-ten blocks, fraction tiles, a ruler, graph paper
- **A notebook** for the student (journal, lab notes, writing)
- **A pencil** (revolutionary, we know)

### Nice to Have
- A whiteboard or large paper for working problems together
- A printer (for Go-Bag worksheets and primary source documents)
- Art supplies (colored pencils, markers) for projects
- Internet access (for research activities and coding block)
- A device with Scratch installed (for Friday coding block)

### You Do NOT Need
- Teaching credentials
- A background in math or science
- To understand everything before the student does (you'll learn together — that's fine)
- Expensive curriculum add-ons, workbooks, or subscriptions

## The Schedule

3 days a week. About 3 hours per day. See `daily-routine.md` for the full breakdown.

| Day | Subjects |
|-----|----------|
| Wednesday | Math + Science |
| Thursday | Math + Social Studies |
| Friday | Math + Science or Social Studies (alternates) + Coding |

Monday and Tuesday are unscheduled. Use them for co-ops, field trips, music lessons, free play, or nothing at all. The curriculum is designed to be complete in 3 days.

## How Lessons Work

Each day has the same structure:

1. **Morning Work** (15 min) — journal, warm-up, or review
2. **Block 1: Math** (60 min) — Singapore Math approach: concrete → pictorial → abstract
3. **Break** (15 min)
4. **Block 2: Science or Social Studies** (45 min) — hands-on, discussion-heavy
5. **Discussion Lunch** (30 min) — casual learning conversation over food
6. **Wrap-Up** (15 min) — homework review, preview tomorrow

### The Scripted Dialogue

Every key teaching moment has a script:

> **Say this**: "Today we're going to figure out what happens when you divide something into pieces that aren't equal. Grab your fraction tiles — we're going to break some rules."

You can read it word-for-word. You can paraphrase. The point is you never have to wonder "how do I explain this?" — it's already written.

### The Bug Report System

When your student struggles, the curriculum tells you what kind of struggle it is and what to do:

- **Error 404** — They don't get it at all. Go back to concrete objects. Simplify. Try a different angle.
- **Error 500** — They're trying but their reasoning is off. Find where the logic breaks. Ask them to explain their thinking.
- **Syntax Error** — They understand the concept but make mechanical mistakes. More practice, not more teaching.

See `rubric.md` for the full mastery rubric.

## Assessment

There are no tests. No grades. No report cards.

You'll use a 4-point mastery rubric (see `rubric.md`) to track where your student is on each standard:

| Score | Meaning |
|-------|---------|
| 4 | Mastery — can teach it to someone else |
| 3 | Proficient — meets the standard |
| 2 | Developing — partial understanding |
| 1 | Beginning — needs re-teaching |

Track progress in the standards tracker (see `google/standards-tracker.csv`). The goal is Proficient (3) or above on every standard by the end of the year.

## Standards Coverage

Root Access covers:
- **30 Common Core Math standards** (CCSS.Math.Content.4.*)
- **16 Next Generation Science Standards** (4-PS/LS/ESS/ETS)
- **22 Michigan Social Studies standards** (4th grade GLCEs)
- **21 Common Core ELA standards** (CCSS.ELA-Literacy.4.*)

ELA is integrated — your student reads, writes, speaks, and listens across every subject, every day. There is no standalone "English class" because that's not how literacy works in real life.

## The Philosophy

### On Math
We use Singapore Math methodology — start with physical objects (concrete), move to drawings and models (pictorial), then move to numbers (abstract). This is slower at first and dramatically faster later. Trust the process.

### On Social Studies
History has more than one side. This curriculum centers the people who lived through events — including Indigenous peoples, enslaved people, immigrants, and workers — not just presidents and generals. We don't simplify complexity into hero/villain stories. Your student will learn to hold multiple perspectives at once. That's a feature, not a bug.

### On Science
Hands-on, inquiry-driven, connected to real life. Your student will predict, test, observe, and conclude — not memorize vocabulary lists.

### On Struggle
Struggle is not failure. Struggle is learning happening in real time. The Bug Report system exists so you can identify *what kind* of struggle it is and respond correctly — not to eliminate struggle entirely.

## Before Week 1

- [ ] Read this guide completely
- [ ] Read `daily-routine.md`
- [ ] Read `rubric.md`
- [ ] Read `curriculum/week-01/parent-prep.md`
- [ ] Gather materials listed in `curriculum/week-01/overview.md`
- [ ] Print or load the Week 1 Go-Bag worksheets
- [ ] Set up a student notebook (any notebook works)
- [ ] Pick your teaching spot (kitchen table, desk, wherever works)
- [ ] Take a breath. You've got this. The scripts are there. Just follow them.
