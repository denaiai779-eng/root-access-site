# Root Access — Pacing Guide

> 36-week map of standards to weeks. This is the backbone — it determines what gets taught when.

---

## Overview

| Subject | Total Standards | Weeks Covered | Strategy |
|---------|----------------|---------------|----------|
| Math (CCSS) | 30 | All 36 weeks (3x/week) | Spiral — introduce, practice, assess across multiple weeks |
| Science (NGSS) | 16 | ~24 weeks (Wed + some Fri) | Unit blocks — 3-4 weeks per unit |
| Social Studies (MI) | 22 | ~24 weeks (Thu + some Fri) | Chronological with thematic threads |
| ELA (CCSS) | 21 | All 36 weeks (integrated daily) | Embedded in every subject, every day |

---

## Quarter 1: Weeks 1-9

### Math Focus: Place Value, Operations, Foundations
| Week | Math Standards | Math Topic |
|------|--------------|------------|
| 1 | 4.NBT.1, 4.NBT.2 | Place value understanding, reading/writing multi-digit numbers |
| 2 | 4.NBT.2, 4.NBT.3 | Comparing multi-digit numbers, rounding |
| 3 | 4.NBT.4 | Multi-digit addition and subtraction (fluency) |
| 4 | 4.NBT.4 | Multi-digit addition and subtraction (word problems) |
| 5 | 4.NBT.5 | Multiplication: multiply by 1-digit (area model, partial products) |
| 6 | 4.NBT.5 | Multiplication: multiply by 1-digit (standard algorithm) |
| 7 | 4.NBT.5, 4.NBT.6 | Multiply 2-digit × 2-digit; intro to division |
| 8 | 4.NBT.6 | Division: 4-digit ÷ 1-digit (place value strategy) |
| 9 | 4.NBT.6 | Division: remainders and interpreting them in context |

### Science Focus: Energy (4-PS3) — Weeks 1-4, Waves (4-PS4) — Weeks 5-9
| Week | Science Standards | Science Topic |
|------|-----------------|---------------|
| 1 | 4-PS3-1 | Energy: speed and energy relationship |
| 2 | 4-PS3-2 | Energy: collisions and energy transfer |
| 3 | 4-PS3-3 | Energy: converting between forms (light, sound, heat, motion) |
| 4 | 4-PS3-4 | Energy: designing solutions for energy transfer |
| 5 | 4-PS4-1 | Waves: wave patterns (amplitude, wavelength) |
| 6 | 4-PS4-1 | Waves: wave patterns in water, sound, light |
| 7 | 4-PS4-2 | Waves: reflection and how we see objects |
| 8 | 4-PS4-3 | Waves: digitized information transfer (codes, signals) |
| 9 | — | Science review and integration project |

### Social Studies Focus: Michigan Geography and Indigenous Peoples
| Week | SS Standards | Social Studies Topic |
|------|------------|---------------------|
| 1 | 4-G1.0.1 | Michigan's geography: regions, landforms, Great Lakes |
| 2 | 4-G1.0.2 | How geography shaped where people lived |
| 3 | 4-H3.0.1 | Indigenous peoples of Michigan: Anishinaabe (Ojibwe, Odawa, Potawatomi) — governance, culture, trade |
| 4 | 4-H3.0.2 | Three Fires Confederacy: political systems, diplomacy, and life before European contact |
| 5 | 4-H3.0.3 | European contact: French fur trade — trade relationships, NOT "discovery" |
| 6 | 4-H3.0.4 | Impact of fur trade on Indigenous nations — what changed, what was lost, what survived |
| 7 | 4-H3.0.5 | British period: colonial conflict, Pontiac's resistance |
| 8 | 4-H3.0.6 | American Revolution impact on Michigan and its peoples |
| 9 | — | Q1 Social Studies review: multiple perspectives project |

### ELA Integration (Every Week)
| Standard | How It Shows Up |
|----------|----------------|
| 4.RI.1 | Reading informational text in science and social studies |
| 4.W.1 | Opinion writing in social studies (taking a position with evidence) |
| 4.W.2 | Informative writing in science (lab reports, observations) |
| 4.SL.1 | Discussion Lunch, all class discussions |
| 4.L.1-3 | Writing conventions practiced in all written work |

---

## Quarter 2: Weeks 10-18

### Math Focus: Fractions
| Week | Math Standards | Math Topic |
|------|--------------|------------|
| 10 | 4.NF.1 | Equivalent fractions (visual models) |
| 11 | 4.NF.1, 4.NF.2 | Equivalent fractions, comparing fractions |
| 12 | 4.NF.3a,b | Adding/subtracting fractions: same denominator |
| 13 | 4.NF.3c,d | Mixed numbers, adding/subtracting mixed numbers |
| 14 | 4.NF.4a,b | Multiplying fractions by whole numbers (conceptual) |
| 15 | 4.NF.4c | Multiplying fractions by whole numbers (word problems) |
| 16 | 4.NF.5 | Fractions with denominators of 10 and 100 |
| 17 | 4.NF.6, 4.NF.7 | Decimal notation for fractions, comparing decimals |
| 18 | — | Fractions and decimals review and assessment |

### Science Focus: Structures and Processes (4-LS1) — Weeks 10-13, Earth's Systems (4-ESS2) — Weeks 14-18
| Week | Science Standards | Science Topic |
|------|-----------------|---------------|
| 10 | 4-LS1-1 | Plant and animal structures: internal and external |
| 11 | 4-LS1-1 | How structures support survival, growth, behavior |
| 12 | 4-LS1-2 | Animal senses: processing information from environment |
| 13 | — | Life science integration project |
| 14 | 4-ESS2-1 | Earth's surface: weathering and erosion |
| 15 | 4-ESS2-1 | Erosion patterns and landform formation |
| 16 | 4-ESS2-2 | Maps: topographic patterns and features |
| 17 | 4-ESS2-2 | Mapping Michigan: connecting to local geography |
| 18 | — | Earth science review and integration project |

### Social Studies Focus: Michigan Statehood and Growth
| Week | SS Standards | Social Studies Topic |
|------|------------|---------------------|
| 10 | 4-H3.0.7 | Michigan Territory: path to statehood (1837) |
| 11 | 4-H3.0.8 | Who came to Michigan: immigration patterns (and who was already there) |
| 12 | 4-C1.0.1 | Michigan government: structure, three branches |
| 13 | 4-C1.0.2 | How state government affects daily life |
| 14 | 4-E1.0.1 | Michigan's early economy: lumber, mining, agriculture |
| 15 | 4-E1.0.2 | Who did the work: labor, including child labor and exploitation |
| 16 | 4-E1.0.3 | Trade and transportation: canals, railroads, Great Lakes shipping |
| 17 | 4-H3.0.9 | Civil War era: Michigan's role, Underground Railroad |
| 18 | — | Q2 Social Studies review: "Whose story is missing?" project |

---

## Quarter 3: Weeks 19-27

### Math Focus: Measurement, Data, and Geometry
| Week | Math Standards | Math Topic |
|------|--------------|------------|
| 19 | 4.MD.1 | Measurement: units and conversions (customary) |
| 20 | 4.MD.1, 4.MD.2 | Measurement: metric units, word problems with measurement |
| 21 | 4.MD.3 | Area and perimeter: formulas for rectangles |
| 22 | 4.MD.4 | Line plots with fractions (connecting to Q2 fraction work) |
| 23 | 4.MD.5, 4.MD.6 | Angles: understanding degrees, measuring with protractor |
| 24 | 4.MD.7 | Angle addition: decomposing angles |
| 25 | 4.G.1 | Geometry: points, lines, rays, angles, parallel, perpendicular |
| 26 | 4.G.2 | Classifying 2D figures by properties |
| 27 | 4.G.3 | Line symmetry |

### Science Focus: Earth and Human Activity (4-ESS3) — Weeks 19-22, Engineering Design (4-ETS1) — Weeks 23-27
| Week | Science Standards | Science Topic |
|------|-----------------|---------------|
| 19 | 4-ESS3-1 | Natural hazards: evidence-based solutions |
| 20 | 4-ESS3-2 | Human impact on Earth: resources and environment |
| 21 | 4-ESS3-2 | Mapping local environmental impact (Michigan focus) |
| 22 | — | Earth and human activity integration project |
| 23 | 4-ETS1-1 | Engineering: defining problems with criteria and constraints |
| 24 | 4-ETS1-2 | Engineering: generating and comparing solutions |
| 25 | 4-ETS1-3 | Engineering: testing and improving solutions |
| 26 | — | Design challenge project (multi-day) |
| 27 | — | Q3 science review |

### Social Studies Focus: Michigan in the Modern Era
| Week | SS Standards | Social Studies Topic |
|------|------------|---------------------|
| 19 | 4-H3.0.10 | Industrialization: auto industry, assembly line, who built the cars |
| 20 | 4-E2.0.1 | Labor movement in Michigan: unions, strikes, workers' rights |
| 21 | 4-H3.0.11 | Great Migration: Black Americans moving to Michigan — why, what they found |
| 22 | 4-C3.0.1 | Civil rights in Michigan: activism, legislation, unfinished business |
| 23 | 4-E2.0.2 | Modern Michigan economy: what replaced manufacturing |
| 24 | 4-G2.0.1 | Michigan's environment: water rights, Flint water crisis |
| 25 | 4-C3.0.2 | Civic participation: how citizens create change |
| 26 | 4-C3.0.3 | Current issues in Michigan: students research and present |
| 27 | — | Q3 Social Studies review: "What would you change?" project |

---

## Quarter 4: Weeks 28-36

### Math Focus: Review, Application, and Extension
| Week | Math Standards | Math Topic |
|------|--------------|------------|
| 28 | 4.OA.1, 4.OA.2 | Multiplicative comparison, word problems |
| 29 | 4.OA.3 | Multi-step word problems with all operations |
| 30 | 4.OA.4 | Factors, multiples, prime and composite numbers |
| 31 | 4.OA.5 | Number and shape patterns |
| 32 | Review | Place value and operations spiral review |
| 33 | Review | Fractions and decimals spiral review |
| 34 | Review | Measurement and geometry spiral review |
| 35 | Application | Cross-subject math project |
| 36 | Application | Year-end math portfolio and reflection |

### Science Focus: Review and Capstone
| Week | Science Standards | Science Topic |
|------|-----------------|---------------|
| 28 | Review | Energy and waves revisited |
| 29 | Review | Life science revisited |
| 30 | Review | Earth science revisited |
| 31-34 | Capstone | Student-designed investigation (full scientific method) |
| 35-36 | — | Science portfolio and presentation |

### Social Studies Focus: Michigan Today and Capstone
| Week | SS Standards | Social Studies Topic |
|------|------------|---------------------|
| 28 | 4-G3.0.1 | Michigan in the nation: comparing Michigan to other states |
| 29 | 4-E3.0.1 | Michigan in the global economy: trade, immigration today |
| 30 | 4-C4.0.1 | What makes Michigan unique: culture, identity, pride |
| 31-34 | Capstone | "My Michigan" research project — student chooses topic |
| 35-36 | — | Capstone presentation and year-end reflection |

---

## Notes

- **Spiral math**: Standards introduced in one quarter are revisited in later quarters. This is intentional.
- **Friday alternation**: Friday's second block alternates between science and social studies weekly. The pacing guide accounts for this.
- **ELA is everywhere**: It's not listed week-by-week because it's embedded in every single day. See the ELA standards CSV for the full list.
- **Flexibility built in**: Weeks 9, 18, 27, and 36 are review/project weeks. Use them to catch up if you fall behind.
- **Standards codes in this guide may be simplified**. See the individual CSV files in `system/standards/` for exact standard language.
