# Root Access — Mastery Rubric

> No grades. No percentages. Four levels of understanding, mapped to the Bug Report system.

---

## The 4-Point Scale

| Score | Level | What It Looks Like | Bug Report |
|-------|-------|-------------------|------------|
| **4** | **Mastery** | Can explain the concept to someone else. Applies it to new, unfamiliar problems. Makes connections across subjects. | No bugs detected. |
| **3** | **Proficient** | Meets the standard. Completes work accurately with only minor errors. Understands the concept but may not transfer it independently. | Syntax Error territory — minor fixes only. |
| **2** | **Developing** | Partial understanding. Can start problems but gets stuck. Makes significant errors that reveal gaps in reasoning. | Error 500 — logic needs support. |
| **1** | **Beginning** | Does not yet demonstrate understanding of the concept. Needs re-teaching with a different approach. | Error 404 — concept not found. Re-teach. |

---

## Bug Report Interventions

### Error 404 (Score 1-2) — No Understanding
The concept didn't land. Don't repeat the same explanation louder.
- **Go back to concrete.** Physical objects, manipulatives, drawings.
- **Shrink the problem.** If multi-step, isolate the first step.
- **Change the context.** If the word problem was about trains, make it about something the student cares about.
- **Check prerequisites.** Sometimes Error 404 means a prior concept has gaps.

### Error 500 (Score 2-3) — Bad Logic
The student is trying. The effort is there. The reasoning is wrong.
- **Find the exact point where logic breaks.** Have the student talk through their thinking out loud.
- **Don't just correct — ask.** "Walk me through how you got from here to here."
- **Provide a counter-example.** "If that rule were true, then this would also be true — does that make sense?"
- **Reteach the specific reasoning step**, not the whole concept.

### Syntax Error (Score 3-4) — Mechanical Mistakes
Gets the concept. Makes computational or procedural errors.
- **Don't reteach.** The understanding is there.
- **Build checking habits.** "Does your answer make sense? Is 847 a reasonable answer for how many apples?"
- **Targeted practice.** If they keep messing up regrouping, drill regrouping — not the whole operation.
- **Time is the fix.** More practice, not more instruction.

---

## How to Use This

1. **After each lesson block**, mentally score the student 1-4 on that day's objective.
2. **You don't need to write it down every time.** But if you see a pattern of 1s or 2s in a subject, that's data — act on it.
3. **Share the rubric with the student.** Not as a judgment tool — as a self-awareness tool. "Where do you think you are on this? What would help you move up?"
4. **Mastery (4) is the goal, Proficient (3) is the standard.** Not every topic needs to reach 4. Some topics are stepping stones.
5. **Track standards in the standards tracker.** Each standard should eventually reach Proficient (3) or above.

---

## What This Is NOT

- Not a grade. There's no GPA. No report card. No "you got a 2."
- Not a punishment. A score of 1 means the teaching approach needs to change — not that the student failed.
- Not permanent. A 1 today can be a 4 next month. That's the whole point.
