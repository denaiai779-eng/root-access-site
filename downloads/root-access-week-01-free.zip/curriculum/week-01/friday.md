# Week 01 — Friday Lesson Plan

## Parent Pre-Read (5 min)

Today is the last day of Week 1. The theme is closure and confidence. In math, your student moves to the abstract stage of Singapore Math — working with numbers without relying on blocks or charts. They've built the understanding over Wednesday and Thursday; today they prove it. In science, they return to Wednesday's ramp experiment and do the real scientist work: analyzing data and writing a conclusion using a formal structure called CER (Claim-Evidence-Reasoning). This is their first time writing a scientific conclusion, so it's heavily scaffolded. The coding block is brand new — just getting into Scratch, exploring the interface, making a sprite move. Keep it light and fun. End the day celebrating that they completed their first full week.

---

## Morning Work (15 min)
**Type**: Reflection Journal

**Prompt**: *"This was your first week of Root Access. Think back over the last three days — math with blocks and charts and numbers, the ramp experiment, Michigan geography, all of it. In your journal, answer these three questions:*

1. *What is one thing you learned this week that surprised you?*
2. *What is one thing that felt hard — and how did you push through it?*
3. *What is one thing you want to learn more about?"*

> **Note to parent**: This is not a quiz. There are no wrong answers. If your student writes two sentences, that's fine. If they write a full page, even better. The goal is to build the habit of weekly reflection. Read what they wrote and respond out loud — "Oh, that's interesting, tell me more about that." This is a conversation starter, not a graded assignment.

---

## Block 1: Math (60 min) — Place Value Day 3: Abstract

### Today's Objective
Student can read, write, compare, and order multi-digit whole numbers using standard form, expanded form, and word form — working primarily with numbers rather than physical manipulatives.

### Standards
- **4.NBT.1**: Recognize that in a multi-digit whole number, a digit in one place represents ten times what it represents in the place to its right
- **4.NBT.2**: Read and write multi-digit whole numbers using base-ten numerals, number names, and expanded form; compare two multi-digit numbers using >, =, and <
- **4.SL.1**: Engage effectively in collaborative discussions (math talk during launch and guided practice)

### Launch (10 min)

> **Say this**: "Okay, we're going to play a quick game called Place Value Zap. I'm going to say a number out loud, and then I'm going to point to one of the digits. You tell me the VALUE of that digit — not the digit itself, the value. So if I say sixty-two thousand, and I point to the 6, you don't say 'six.' You say..."

Wait for them to answer. If they say "sixty thousand" — perfect. If they say "six," remind them: "That's the digit. But what is it WORTH in that spot?"

**Play the game** — say each number, write it on paper or a whiteboard, then point to one digit:

| Number | Point to | Answer |
|--------|----------|--------|
| 47,235 | 4 | 40,000 |
| 47,235 | 2 | 200 |
| 91,806 | 8 | 800 |
| 91,806 | 0 | 0 |
| 63,150 | 1 | 100 |
| 63,150 | 5 | 50 |

Go fast. Make it feel like a game, not a test. Celebrate quick answers. If they get one wrong, don't stop — just say "Close! Think about what place that digit is in" and move on.

> **Say this (transition)**: "Nice. You've been building numbers with blocks, drawing them on charts — and now you clearly know this stuff. So here's the deal for today: no blocks, no charts, unless you really need them. You've built the understanding. Now trust your brain. The blocks are still right there if you get stuck, and there's zero shame in grabbing them. But I think you're ready to fly without them."

### Guided Practice (20 min)

> **Say this**: "We're going to work through three problems together. These are real-world problems — they use actual numbers from the real world. I'll read each one out loud, and we'll solve it step by step."

**Problem 1: Population Comparison**

*"The population of Grand Rapids, Michigan, is 198,917. The population of Ann Arbor, Michigan, is 123,851. Which city has more people? How do you know? And what is the value of the 9 in Grand Rapids' population that's in the ten-thousands place?"*

> **Work through it together**:
>
> **Say this**: "Let's write both numbers down, one above the other, and line them up by place value."
>
> ```
> 198,917
> 123,851
> ```
>
> "Now, to compare, we start at the LEFT — the biggest place value. What's the hundred-thousands digit in Grand Rapids' number?"
>
> (Student: 1)
>
> "And in Ann Arbor's?"
>
> (Student: 1)
>
> "Same. So we move right. What's the ten-thousands digit in Grand Rapids?"
>
> (Student: 9)
>
> "And Ann Arbor?"
>
> (Student: 2)
>
> "9 is greater than 2. So we're done — we don't even need to look at the rest. 198,917 > 123,851. Grand Rapids has more people."
>
> "Now — the 9 in 198,917. It's in the ten-thousands place. So its value is 90,000. Not 9. Ninety thousand."

**Answer**: Grand Rapids has more people because 198,917 > 123,851. When you compare from left to right, the ten-thousands digit in Grand Rapids (9) is greater than the ten-thousands digit in Ann Arbor (2). The value of the 9 in 198,917 is 90,000.

---

**Problem 2: Expanded Form and Word Form from a Real Context**

*"The Great Lakes contain about 21,670 cubic kilometers of water. Write 21,670 in expanded form and in word form."*

> **Work through it together**:
>
> **Say this**: "Let's break this number apart, place by place. Start with the biggest digit on the left. What place is the 2 in?"
>
> (Student: ten-thousands)
>
> "So the 2 is worth..."
>
> (Student: 20,000)
>
> "Good. Next — the 1."
>
> (Student: 1,000)
>
> Continue for each digit.

**Answer**:
- **Expanded form**: 20,000 + 1,000 + 600 + 70
- **Word form**: twenty-one thousand, six hundred seventy
- **Note**: The 0 in the ones place means there are zero ones — we don't write "+ 0" in expanded form, and we don't say "zero" in word form.

---

**Problem 3: Ordering Numbers**

*"Here are the heights (in feet) of four Michigan waterfalls: Tahquamenon Falls — 48 feet, Ocqueoc Falls — 27 feet, Agate Falls — 39 feet, Bond Falls — 50 feet. Order these from least to greatest and explain your reasoning."*

> **Work through it together**:
>
> **Say this**: "These are all two-digit numbers, so let's compare the tens digit first. What are the tens digits?"
>
> Write them out:
> - 48 → tens digit 4
> - 27 → tens digit 2
> - 39 → tens digit 3
> - 50 → tens digit 5
>
> "The smallest tens digit is 2, so 27 comes first. Then 3, so 39. Then 4, so 48. Then 5, so 50."

**Answer**: 27, 39, 48, 50 (Ocqueoc Falls, Agate Falls, Tahquamenon Falls, Bond Falls). We compare the tens digit first; since all four numbers have different tens digits, that's enough to determine the order.

### Independent Practice (20 min)

> **Say this**: "Your turn. Five problems. Work through them on your own. Blocks and charts are right there if you need them — but try without first. I'll be right here if you get stuck."

**Problem Set B** (Solo):

**1.** What is the value of the underlined digit?

&nbsp;&nbsp;&nbsp;&nbsp;4**8**,215

---

**2.** Lake Michigan is 22,404 square miles. Lake Huron is 23,007 square miles. Which lake is larger? Use >, <, or = to show your answer, and explain how you know.

---

**3.** The Mackinac Bridge is 26,372 feet long. Write this number in:
- Standard form: ____________
- Expanded form: ____________
- Word form: ____________

---

**4.** Order these Michigan city populations from least to greatest. Explain your reasoning.

| City | Population |
|------|-----------|
| Kalamazoo | 72,368 |
| Lansing | 112,644 |
| Dearborn | 98,153 |
| Flint | 87,092 |

---

**5.** Using the digits **7, 0, 3, 9, 1** (each used exactly once), create:
- The LARGEST possible 5-digit number: ____________
- The SMALLEST possible 5-digit number: ____________
- What is the difference between your two numbers? Show your work.

---

### Answer Key

**1.** The 8 is in the thousands place. Its value is **8,000**.

**2.** Lake Huron is larger. 23,007 > 22,404. When you line up the numbers and compare from left to right: the ten-thousands digits are both 2 (same), but the thousands digit in 23,007 is 3, which is greater than the thousands digit in 22,404, which is 2. So 23,007 > 22,404.

**3.**
- Standard form: 26,372
- Expanded form: 20,000 + 6,000 + 300 + 70 + 2
- Word form: twenty-six thousand, three hundred seventy-two

**4.** Least to greatest: **72,368 < 87,092 < 98,153 < 112,644** (Kalamazoo, Flint, Dearborn, Lansing).

Reasoning: Kalamazoo, Flint, and Dearborn are all 5-digit numbers, while Lansing is a 6-digit number, so Lansing is the greatest. Among the 5-digit numbers, compare ten-thousands digits: 7 < 8 < 9, giving us Kalamazoo < Flint < Dearborn.

**5.**
- Largest: **97,310** (Place the largest digits in the highest place values: 9 in ten-thousands, 7 in thousands, 3 in hundreds, 1 in tens, 0 in ones.)
- Smallest: **10,379** (Place the smallest non-zero digit in the ten-thousands place — you can't put 0 first because then it wouldn't be a 5-digit number. So: 1 in ten-thousands, 0 in thousands, 3 in hundreds, 7 in tens, 9 in ones.)
- Difference: 97,310 - 10,379 = **86,931**

### Beast Academy Challenge (10 min)

> **Say this**: "Okay, one more. This one is a puzzle — it's supposed to be tricky. There's no single right answer, which is what makes it fun. Take your time, try things, cross stuff out. This is the kind of problem real mathematicians play with."

**The Puzzle**: Using the digits 1 through 9 (each digit used exactly once), create three 3-digit numbers that are as CLOSE TOGETHER as possible. What's the smallest difference you can get between the largest and smallest of your three numbers?

*Hint: Think about what makes numbers close together. What place value matters most?*

---

**Solution**:

The key insight is that the hundreds digit matters most. To make three numbers close together, you need to:
1. Use consecutive digits for the hundreds places (like 1, 2, 3) to keep the range as small as possible.
2. Balance the tens and ones digits — give the SMALLEST hundreds-digit number the LARGEST remaining digits (to pull it up), and give the LARGEST hundreds-digit number the SMALLEST remaining digits (to pull it down).

Starting with hundreds digits 1, 2, 3 and the remaining digits 4, 5, 6, 7, 8, 9:
- Give the "1\_\_" number the big digits: **198**
- Give the "2\_\_" number the middle digits: **257**
- Give the "3\_\_" number the small digits: **346**

Check: 346 - 198 = **148**. And all nine digits (1, 9, 8, 2, 5, 7, 3, 4, 6) are used exactly once. Confirmed.

> **Tell the student**: "One great answer is 198, 257, and 346. The difference between the biggest and smallest is only 148. The trick is to put small digits in the hundreds place and then give the smallest number the biggest tens and ones digits to pull it UP, while giving the biggest number the smallest tens and ones digits to pull it DOWN. You're balancing the numbers toward the middle."

Accept any answer where the student uses all nine digits exactly once, forms three 3-digit numbers, and the spread is under 200. If they get under 150, that's exceptional.

### Bug Check
- **Error 404** (No understanding): Go back to blocks. Seriously, it's fine. Have the student build the number with base-ten blocks, then write it. Do 2-3 problems this way. The abstract stage isn't a deadline — it's a destination. If they need another day at the pictorial stage, take it. You'll have more place value practice woven into future weeks.
- **Error 500** (Bad logic — student can write numbers but can't compare them): Teach the "line them up and go left to right" strategy explicitly. Write both numbers vertically, aligned by place value. Draw a box around each column starting from the left. The first column where the digits are different tells you which number is greater. Practice this with 3-4 number pairs until it clicks.
- **Syntax Error** (Mechanics — concept is solid but details slip): Common issues: forgetting commas in numbers over 999, misspelling number words ("fourty" instead of "forty," "ninty" instead of "ninety"), writing expanded form with wrong place values. These just need practice and gentle correction. Keep a personal "tricky words" list in the math notebook.

---

## Block 2: Science (45 min) — Energy and Speed: Data Analysis

### Today's Objective
Student can analyze data from an experiment and write a scientific conclusion using the Claim-Evidence-Reasoning (CER) framework, connecting the speed of an object to the energy it carries.

### Standards
- **4-PS3-1**: Use evidence to construct an explanation relating the speed of an object to the energy of that object
- **4.W.2**: Write informative/explanatory texts to examine a topic and convey ideas and information clearly
- **4.RI.7**: Interpret information presented visually, orally, or quantitatively and explain how the information contributes to an understanding of the text (here: interpreting their own experiment data)
- **4.SL.1**: Engage effectively in collaborative discussions

### Hook (5 min)

> **Say this**: "Remember Wednesday? The ramp, the car, the blocks getting knocked everywhere? Today, you're not doing the experiment again — today you're doing something even more important. You're going to be a real scientist. You're going to look at your data, find the pattern, and explain what it means. That's actually the hardest part of science — not doing the experiment, but figuring out what the experiment TOLD you."

Pull out the student's data from Wednesday's ramp experiment. If they recorded it on paper, have it in front of them. If they didn't record it neatly, take a moment to reconstruct it together from memory.

### Lesson (15 min)

> **Say this**: "Let's look at your data together. You tested the car rolling down the ramp at three different heights, right? And you counted how many blocks the car knocked over each time."

Have the student read their data out loud. If their data looks roughly like this, you're on track:

| Ramp Height | Blocks Knocked Over |
|-------------|-------------------|
| Low (1 book) | 1-3 blocks |
| Medium (2 books) | 3-5 blocks |
| High (3 books) | 5-9 blocks |

> **Say this**: "Look at those numbers. What do you notice? What pattern do you see?"

Wait. Let them think. Don't rush to give the answer. If they need help:

> **If student struggles, say**: "Look at what happens to the number of blocks as the ramp gets higher. Does it go up, down, or stay the same?"

Once they identify the pattern (higher ramp = more blocks knocked over):

> **Say this**: "Exactly. Now let's think about WHY. When the ramp is higher, the car has farther to roll before it hits the blocks. That means it's going FASTER when it reaches the bottom. And when it's going faster, what happens?"

(Student: It knocks over more blocks.)

> **Say this**: "Right. It knocks over more blocks because it has more ENERGY. And here's the vocabulary word for today: the energy that a moving object has is called **kinetic energy**. Kinetic means 'related to motion.' A car sitting still has zero kinetic energy. A car rolling slowly has a little kinetic energy. A car zooming fast has a LOT of kinetic energy. The faster something moves, the more kinetic energy it has."

> **Say this**: "So here's what your experiment proved: objects moving faster have more energy — more kinetic energy — and they can do more things because of it. Knocking over blocks is one thing. But think about a bowling ball. A slow bowling ball might knock over one pin. A fast bowling ball knocks over all ten. Same idea."

### Activity (20 min)

**What the student does**: Write a scientific conclusion using the CER (Claim-Evidence-Reasoning) framework.

> **Say this**: "Scientists don't just say 'I think this happened.' They write conclusions in a specific way so other scientists can check their work. The method is called CER — Claim, Evidence, Reasoning. I'm going to walk you through it, and you're going to write your first one today."

**Provide this template** (write it on a sheet of paper or have it printed):

---

**My Scientific Conclusion**

**CLAIM** (What did you figure out? Write it as one clear sentence.)

"I claim that ________________________________________________________."

**EVIDENCE** (What data from your experiment supports your claim? Use specific numbers.)

"In my experiment, when the ramp was at the lowest height, the car knocked over _____ blocks. When the ramp was at the medium height, the car knocked over _____ blocks. When the ramp was at the highest height, the car knocked over _____ blocks."

**REASONING** (WHY does your evidence support your claim? Connect the dots. Use the vocabulary word "kinetic energy.")

"This data supports my claim because ____________________________________________. The higher ramp made the car go __________, which means it had more __________. Scientists call the energy of a moving object __________. My experiment showed that when an object has more kinetic energy, it can ________________________________________."

---

> **Say this**: "Start with the claim. Here's what you proved in your experiment, in one sentence. I'll give you the start: 'I claim that objects moving faster have more...' Can you finish it?"

Guide them to write: *"I claim that objects moving faster have more energy."* or *"I claim that the faster an object moves, the more energy it has."*

Then move to evidence. They should fill in their actual numbers from Wednesday.

For reasoning, this is the hardest part. Help them connect the evidence to the claim:

> **If they're stuck on reasoning, say**: "You showed that the higher ramp knocked over more blocks. But WHY? What happened to the car's speed when the ramp was higher? And what does speed have to do with energy?"

**Example of a strong completed CER** (for parent reference — the student's will be in their own words):

- **Claim**: "I claim that objects moving faster have more energy."
- **Evidence**: "In my experiment, when the ramp was at the lowest height (1 book), the car knocked over 2 blocks. When the ramp was at medium height (2 books), the car knocked over 4 blocks. When the ramp was at the highest height (3 books), the car knocked over 7 blocks."
- **Reasoning**: "This data supports my claim because the higher ramp made the car roll faster, and the faster car knocked over more blocks. This means it had more energy. Scientists call the energy of a moving object kinetic energy. My experiment showed that when an object has more kinetic energy, it can move other objects more — like knocking over more blocks."

**Materials**: Student's data from Wednesday's ramp experiment, lined paper or science notebook, pencil.

### Discussion (5 min)

> **Ask**: "Where do you see kinetic energy in real life? Think about sports, cars, animals — anything that moves."

> **Listen for**: The student connecting speed to energy in real-world examples. Strong answers: a fast baseball hurts more than a slow one, a car crash at high speed does more damage than a fender bender, a cheetah running fast can knock down prey, a kicked soccer ball goes farther when you kick it harder.

> **If student struggles**: "Think about a bowling ball. What happens when you roll it slowly? What about when you roll it fast? Which one has more kinetic energy? How do you know?"

> **Wrap it up**: "You just did something real scientists do every day — you ran an experiment, collected data, found a pattern, and explained what it means. That's not a worksheet. That's actual science. Nice work this week."

---

## Block 3: Coding (30 min) — Meet Scratch

### Today's Project: Hello, Scratch!

This is the very first coding session of the year. The only goals are: get into Scratch, understand the basic interface, and make something happen on screen. No pressure. Just play.

### Setup
- Computer or tablet with internet access
- Go to **scratch.mit.edu**
- Parent helps create a free account (you'll need an email address)
- Click **"Create"** to open the Scratch editor

### Instructions

> **Say this**: "This is Scratch. It's a programming language made by MIT — one of the best universities in the world — specifically for kids to learn coding. Everything you build here, you build by snapping blocks together, kind of like LEGO. No typing code. Just drag, drop, and connect."

**Step 1: Explore the Interface (5 min)**

Point out the three main areas:
- **The Stage** (top right): This is where your project runs. Right now there's a cat (the Scratch cat) standing in the middle.
- **The Sprite Panel** (bottom right): This shows all your characters. Right now you just have one — the cat.
- **The Block Palette** (left side): These are all the commands you can give your sprite. They're organized by color — blue is Motion, purple is Looks, yellow is Events, orange is Control.

> **Say this**: "Let's start simple. Our goal: make the cat walk across the screen when you click the green flag."

**Step 2: Make the Cat Move (10 min)**

1. Click on the **"Events"** category (yellow blocks) in the block palette.
2. Drag the block **"when green flag clicked"** into the scripting area (the big empty space in the middle).
3. Click on the **"Control"** category (orange blocks).
4. Drag the **"repeat 10"** block and snap it under the "when green flag clicked" block. It should click into place like a puzzle piece.
5. Click on the **"Motion"** category (blue blocks).
6. Drag the **"move 10 steps"** block and place it INSIDE the "repeat 10" block (in the mouth of the C-shape).
7. Click the **green flag** above the stage.

> **Say this**: "What happened? The cat moved to the right! You just wrote your first program. The computer read your instructions — 'when the green flag is clicked, repeat this 10 times: move 10 steps' — and it did exactly what you told it to."

**Step 3: Make the Cat Talk (10 min)**

1. Click on the **"Looks"** category (purple blocks).
2. Drag the **"say 'Hello!' for 2 secs"** block and snap it UNDER the "repeat 10" block (but still inside the "when green flag clicked" block — after the repeat, not inside it).
3. Change the text from "Hello!" to something fun — their name, a joke, "I made it!"
4. Click the green flag again.

> **Say this**: "Now the cat walks across the screen AND says something when it gets there. You gave it two instructions and it followed both, in order. That's what programming is — giving a computer a list of instructions, in the right order, and it does them."

**Step 4: Play and Experiment (5 min)**

Let the student explore freely:
- What happens if you change "move 10 steps" to "move 50 steps"?
- What happens if you change "repeat 10" to "repeat 100"?
- Can you make the cat move AND talk at the same time? (Hint: try a "say" block inside the repeat loop.)

### Extension
If the student finishes early and wants more:
- Change the backdrop: Click the landscape icon at bottom right of the stage, pick a new backdrop.
- Add a second sprite: Click the cat-with-a-plus icon at bottom right of the sprite panel. Choose a new character.
- Challenge: Can you make the second sprite move in the OPPOSITE direction? (Hint: use "move -10 steps" — negative numbers make the sprite go left.)

### Coding Vocabulary Introduced Today
- **Sprite**: A character or object in Scratch
- **Stage**: The area where your project plays out
- **Block**: A single instruction/command
- **Script**: A set of blocks connected together — a program
- **Loop**: A block that repeats instructions (the "repeat" block)

---

## Discussion Lunch
**Topic**: Coding and automation — connected to today's first Scratch session.

**Starter question**: "If you could program a computer to do ONE thing for you every single day — anything at all — what would it be and why?"

Follow-up questions if the conversation flows:
- "What would be easy for a computer to do? What would be hard?"
- "Is there anything a computer could NEVER do, no matter how good the programming is?"
- "What if you could program a robot to help around the house — what job would you give it first?"

---

## End-of-Week Celebration (5 min)

> **Say this**: "That's it. You just finished your first full week of Root Access. Three days. Math, science, geography, coding — you did all of it. How do you feel?"

Let them answer honestly. Then:

> **Say this**: "I want you to know something. The first week is the hardest week. Not because the work is the hardest — it'll get harder. But because everything is new. New routines, new way of learning, new expectations. And you handled it. So here's what we're going to do: pick one thing from this week that you're proud of, and tell me what it is."

This is a real moment. Listen. Acknowledge what they say. Then do something small to mark it — a high five, a favorite snack, ten minutes of free time, whatever feels right for your family.

---

## Homework
See homework.md for this week's assignments. Tonight's assignment is the Weekend Project (Michigan Postcard Project) — a creative, flexible project meant to be completed over the weekend. No rush.

---

## Materials Checklist
- [ ] Math notebook and pencil
- [ ] Base-ten blocks (nearby as backup — may not be needed)
- [ ] Whiteboard or large paper and markers (for Place Value Zap game)
- [ ] Student's ramp experiment data from Wednesday
- [ ] Lined paper or science notebook (for CER conclusion writing)
- [ ] CER template (write out or print the scaffold from the Activity section above)
- [ ] Computer or tablet with internet access (for Scratch)
- [ ] Parent email address (for creating Scratch account)

---

*Root Access Learning OS — Week 01 of 36*

© 2026 Root Access Learning OS. All rights reserved.
