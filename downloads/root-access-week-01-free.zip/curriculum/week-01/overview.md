# Week 01 — Boot Sequence

*Starting up. Getting oriented. Building the foundations everything else runs on.*

## Week Summary

This is Day One of the whole year. Your student will begin building place value understanding in math — the bedrock skill that supports every operation they'll learn from here forward. In science, they'll start exploring energy by investigating what happens when objects move at different speeds. In social studies, they'll orient themselves on the map by learning the physical geography of their home state, Michigan. Every subject this week is about the same idea: before you can do anything interesting, you need to understand the system you're working in.

## Standards Covered This Week

| Subject | Standard Code | Standard Description | Day(s) |
|---------|--------------|----------------------|--------|
| Math | 4.NBT.1 | Recognize that in a multi-digit whole number, a digit in one place represents ten times what it represents in the place to its right | W, Th, F |
| Math | 4.NBT.2 | Read and write multi-digit whole numbers using base-ten numerals, number names, and expanded form; compare two multi-digit numbers using >, =, and < | W, Th, F |
| Science | 4-PS3-1 | Use evidence to construct an explanation relating the speed of an object to the energy of that object | W, F |
| Social Studies | 4-G1.0.1 | Identify and describe the physical features of Michigan including landforms, bodies of water, climate, vegetation, and animal life | Th, F |
| ELA | 4.RI.1 | Refer to details and examples in a text when explaining what the text says explicitly and when drawing inferences from the text | Th |
| ELA | 4.RI.2 | Determine the main idea of a text and explain how it is supported by key details; summarize the text | Th |
| ELA | 4.RI.4 | Determine the meaning of general academic and domain-specific words or phrases in a text | W, Th |
| ELA | 4.W.2 | Write informative/explanatory texts to examine a topic and convey ideas and information clearly | W, Th |
| ELA | 4.W.4 | Produce clear and coherent writing in which the development and organization are appropriate to task, purpose, and audience | W, Th, F |
| ELA | 4.SL.1 | Engage effectively in a range of collaborative discussions, building on others' ideas and expressing their own clearly | W, Th, F |
| ELA | 4.L.1–3 | Demonstrate command of conventions of standard English grammar, usage, capitalization, punctuation, and spelling when writing and speaking | W, Th, F |

## Materials Needed

### Math (all three days)
- [ ] Base-ten blocks — ones (units), tens (rods), hundreds (flats), and at least one thousands cube. If you don't have a physical set, print and cut a paper set (search "printable base-ten blocks PDF") or order a set online; they'll be used heavily through Week 6.
- [ ] A large sheet of paper or whiteboard for building a place value chart
- [ ] Markers or dry-erase markers (4 colors if possible — one per place value)
- [ ] Lined notebook or math journal (this becomes their permanent math notebook for the year)

### Science (Wednesday and Friday)
- [ ] 2–3 toy cars or matchbox cars of similar size
- [ ] A flat board or stiff piece of cardboard (about 2–3 feet long) to use as a ramp
- [ ] Books or blocks to prop up the ramp at different heights
- [ ] A lightweight target object — an empty cereal box or small cardboard box works perfectly
- [ ] Ruler or tape measure
- [ ] Pencil and paper for recording observations

### Social Studies (Thursday and Friday)
- [ ] A printed or on-screen physical map of Michigan (search "Michigan physical map" — you want one showing landforms and water features, not just roads). If you can, print two copies — one clean and one for your student to label and mark up.
- [ ] Colored pencils for map work
- [ ] Optional but great: a road atlas or wall map showing the Great Lakes region

### General
- [ ] A dedicated folder or binder section for each subject — set this up on Day 1
- [ ] A pencil, eraser, and sharpener at the workspace before you start

## Schedule at a Glance

| | Wednesday | Thursday | Friday |
|---|-----------|----------|--------|
| **Block 1** | Math: Place Value Intro | Math: Reading & Writing Numbers | Math: Comparing Numbers |
| **Block 2** | Science: Energy & Speed | Social Studies: Michigan Geography | Science OR Social Studies (alternate weekly — this week: Science wrap-up) |
| **Notes** | First day. Build routines. | ELA integrates with SS reading. | Coding block if time allows. |

## Parent Notes

**This is Week 1. Give yourself grace.**

The first week will feel slower than you expect, and that's fine. You're not just teaching content — you're building every routine from scratch: where do we sit, how do we start, what do we do when we're stuck, how do we transition between subjects. That invisible work is real work.

A few things to keep in mind:

- **Don't rush through place value.** It will feel too easy on Wednesday. It's not. Place value is the foundation that supports multi-digit multiplication, division, decimals, and fractions. If your student can't explain *why* the 4 in 4,000 is worth four thousand (not four), every one of those topics will be harder later. Spend the time now.

- **Expect the science experiment to be messy.** The ramp experiment is designed to be hands-on and a little chaotic. Your student is supposed to be observing and explaining, not getting a perfect result. If the cereal box goes flying across the room, that's data.

- **The ELA standards aren't a separate block.** You'll notice there's no "ELA hour" on the schedule. That's intentional. Reading, writing, vocabulary, and discussion are woven into science and social studies. When your student reads an informational text about Michigan and identifies the main idea, that's 4.RI.2. When they write observations during the ramp experiment, that's 4.W.2. You don't need to teach these separately — just make sure they're happening, which the daily lesson plans will guide you through.

- **Set up the physical space before Wednesday.** Clear a table or desk. Have all materials within reach. Put the math notebook, pencils, and base-ten blocks where your student can see them. A predictable workspace signals that this is real and it matters.

- **You don't need to be an expert.** The parent-prep guide and daily lessons give you everything you need to know. Read through all three days before Wednesday so nothing catches you off guard.

---

*Root Access Learning OS — Week 01 of 36*

© 2026 Root Access Learning OS. All rights reserved.
